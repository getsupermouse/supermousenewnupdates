# TheSuperMouse — Version 1.0 (Active Workspace)

### Overview
This is the active development workspace for **TheSuperMouse Version 1.0**.

### Status
- Initialized from the core suite foundation.
- Ready for Version 1.0 specifications and modifications.

### Launching
Run `run.bat` or execute:
```bash
python runner.py
```

