import 'package:flutter_test/flutter_test.dart';
import 'package:thesupermouse/main.dart';

void main() {
  testWidgets('App smoke test', (WidgetTester tester) async {
    await tester.pumpWidget(const TheSuperMouseApp());
    expect(find.text('THE SUPER MOUSE'), findsOneWidget);
  });
}
