import 'dart:ffi';
import 'dart:io';

// Win32 Constants
const int imageCursor = 2;
const int lrLoadFromFile = 0x0010;
const int lrDefaultSize = 0x0040;
const int ocrNormal = 32512;
const int spiSetCursors = 0x0057;

typedef _LoadImageC = IntPtr Function(
  IntPtr hInst,
  Pointer<Uint16> name,
  Uint32 type,
  Int32 cx,
  Int32 cy,
  Uint32 fuLoad,
);
typedef _LoadImageDart = int Function(
  int hInst,
  Pointer<Uint16> name,
  int type,
  int cx,
  int cy,
  int fuLoad,
);

typedef _SetSystemCursorC = Int32 Function(IntPtr hcur, Uint32 id);
typedef _SetSystemCursorDart = int Function(int hcur, int id);

typedef _SystemParametersInfoWC = Int32 Function(
  Uint32 uiAction,
  Uint32 uiParam,
  Pointer<Void> pvParam,
  Uint32 fWinIni,
);
typedef _SystemParametersInfoWDart = int Function(
  int uiAction,
  int uiParam,
  Pointer<Void> pvParam,
  int fWinIni,
);

class WindowsCursorManager {
  static bool _applied = false;
  static bool get isApplied => _applied;

  static DynamicLibrary? _user32;
  static _LoadImageDart? _loadImage;
  static _SetSystemCursorDart? _setSystemCursor;
  static _SystemParametersInfoWDart? _systemParametersInfo;

  static void _init() {
    if (!Platform.isWindows || _user32 != null) return;
    _user32 = DynamicLibrary.open('user32.dll');
    _loadImage = _user32!.lookupFunction<_LoadImageC, _LoadImageDart>('LoadImageW');
    _setSystemCursor = _user32!.lookupFunction<_SetSystemCursorC, _SetSystemCursorDart>('SetSystemCursor');
    _systemParametersInfo = _user32!.lookupFunction<_SystemParametersInfoWC, _SystemParametersInfoWDart>('SystemParametersInfoW');
  }

  /// Convert string to UTF-16 pointer in native memory
  static Pointer<Uint16> _toUtf16(String str) {
    final units = str.codeUnits;
    final int byteCount = (units.length + 1) * 2;
    final int address = _allocMem(byteCount);
    final ptr = Pointer<Uint16>.fromAddress(address);
    for (int i = 0; i < units.length; i++) {
      ptr[i] = units[i];
    }
    ptr[units.length] = 0;
    return ptr;
  }

  static int _allocMem(int bytes) {
    final kernel32 = DynamicLibrary.open('kernel32.dll');
    final getProcessHeap = kernel32.lookupFunction<IntPtr Function(), int Function()>('GetProcessHeap');
    final heapAlloc = kernel32.lookupFunction<
        IntPtr Function(IntPtr hHeap, Uint32 dwFlags, IntPtr dwBytes),
        int Function(int hHeap, int dwFlags, int dwBytes)>('HeapAlloc');
    return heapAlloc(getProcessHeap(), 0x00000008, bytes);
  }

  static void _freeMem(Pointer ptr) {
    if (ptr.address == 0) return;
    final kernel32 = DynamicLibrary.open('kernel32.dll');
    final getProcessHeap = kernel32.lookupFunction<IntPtr Function(), int Function()>('GetProcessHeap');
    final heapFree = kernel32.lookupFunction<
        Int32 Function(IntPtr hHeap, Uint32 dwFlags, IntPtr lpMem),
        int Function(int hHeap, int dwFlags, int lpMem)>('HeapFree');
    heapFree(getProcessHeap(), 0, ptr.address);
  }

  /// Applies the custom cursor system-wide across Windows
  static bool applySystemCursor(String iconPath) {
    if (!Platform.isWindows) return false;

    try {
      _init();
      final file = File(iconPath);
      if (!file.existsSync()) return false;

      final pPath = _toUtf16(iconPath);
      final hCursor = _loadImage!(
        0,
        pPath,
        imageCursor,
        32,
        32,
        lrLoadFromFile | lrDefaultSize,
      );
      _freeMem(pPath);

      if (hCursor != 0) {
        _setSystemCursor!(hCursor, ocrNormal);
        _applied = true;
        return true;
      }
    } catch (_) {}
    return false;
  }

  /// Restores default Windows system cursors immediately
  static void restoreSystemCursor() {
    if (!Platform.isWindows || !_applied) return;

    try {
      _init();
      _systemParametersInfo!(spiSetCursors, 0, nullptr, 0);
      _applied = false;
    } catch (_) {}
  }
}
