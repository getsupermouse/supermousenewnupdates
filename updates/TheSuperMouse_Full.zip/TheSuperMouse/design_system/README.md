# The SuperMouse Design System & Publishing Specifications (v1.0)

This directory defines the authoritative design tokens, typography specifications, explicit font weights, and obsidian aesthetic rules for TheSuperMouse release bundles.

## Visual Fidelity Rules
1. **Explicit Typography Weights:** Never rely on system OpenType style strings like `"Display Bold"` alone. Always supply an explicit integer weight (`setWeight(700)` or `setWeight(800)`) with a multi-layered fallback font family stack (`Segoe UI Variable Display` -> `Segoe UI Variable Text` -> `Segoe UI` -> `Arial` -> `sans-serif`). This prevents text from collapsing into thin 400-weight dropouts on Windows 10 or bare environments.
2. **Pure Obsidian OLED Canvas:** Baseline canvas background is `#040405` with translucent white overlays (`rgba(255, 255, 255, 0.04)`) and crisp vector hairline borders (`rgba(255, 255, 255, 0.08)`).
3. **Signature Neon Lime Accent:** Signature `#A3E635` cyber-lime provides vibrant, high-contrast visual indicators across active rows, selection themes, and toggles.
4. **Self-Contained Bundled Assets:** All production releases strictly bundle official vector assets and 22 high-resolution avatars directly in `assets/avatars/`. No external or personal developer folders are referenced.
