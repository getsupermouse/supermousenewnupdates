# THE SUPERMOUSE — Official Interactive Uninstaller ('delete supermouse')
$ErrorActionPreference = 'SilentlyContinue'
Write-Host ""
Write-Host "  ======================================================" -ForegroundColor DarkGray
Write-Host "    THE SUPERMOUSE  -  DELETION PROCESS" -ForegroundColor Yellow
Write-Host "  ======================================================" -ForegroundColor DarkGray
Write-Host ""

# Step 1: Verify Email or 15-Digit License Key
$ident = (Read-Host "  > ENTER YOUR MAIL OR LICENSE KEY TO START DELETION PROCESS").Trim()
if ([string]::IsNullOrWhiteSpace($ident)) {
    Write-Host "  Cancelled: Email or License Key is required." -ForegroundColor Red
    exit 1
}

Write-Host "  Verifying account..." -ForegroundColor Cyan
$verified = $false

# Check local license stamp first if present
$installDir = Join-Path $env:LOCALAPPDATA "TheSuperMouse"
$localLic = Join-Path $installDir "license.json"
if (Test-Path $localLic) {
    try {
        $licObj = Get-Content $localLic -Raw | ConvertFrom-Json
        if (($licObj.licenseKey -eq $ident) -or ($licObj.email -and $licObj.email.ToLower() -eq $ident.ToLower())) {
            $verified = $true
        }
    } catch {}
}

# Otherwise verify online via Netlify backend
if (-not $verified) {
    try {
        $payload = @{ identifier = $ident } | ConvertTo-Json
        $resp = Invoke-RestMethod -Uri "https://getsupermouse.netlify.app/api/verify-delete" -Method Post -ContentType "application/json" -Body $payload -TimeoutSec 10
        if ($resp.ok) { $verified = $true }
    } catch {
        $verified = $false
    }
}

if (-not $verified) {
    Write-Host ""
    Write-Host "  ERROR: Email or 15-digit License Key did not match any registered license." -ForegroundColor Red
    exit 1
}

Write-Host "  Verified!" -ForegroundColor Green
Write-Host ""

# Step 2: Locate Stored Photos / Super Share Memory Space Folder
$photosDir = Join-Path ([Environment]::GetFolderPath('MyPictures')) "SuperShare"
$altDataDir = Join-Path $installDir "stored_files"
$displayLoc = if (Test-Path $photosDir) { $photosDir } elseif (Test-Path $altDataDir) { $altDataDir } else { $photosDir }

Write-Host "  > YOUR PHOTOS AND ALL THINGS ARE STORED AT:" -ForegroundColor White
Write-Host "    $displayLoc" -ForegroundColor Yellow
$delPhotos = (Read-Host "  > DO YOU WANNA DELETE THAT? [YES/NO]").Trim().ToUpper()
$deleteDataFolder = ($delPhotos -eq "YES" -or $delPhotos -eq "Y")

Write-Host ""
# Step 3: Final Confirmation
$sure = (Read-Host "  > ARE YOU SURE YOU WANT TO DELETE? [YES/NO]").Trim().ToUpper()
if ($sure -ne "YES" -and $sure -ne "Y") {
    Write-Host ""
    Write-Host "  Deletion cancelled. Nothing was removed." -ForegroundColor Cyan
    exit 0
}

Write-Host ""
Write-Host "  [PROCESS] Stopping THE SUPERMOUSE..." -ForegroundColor Cyan
Get-Process -Name "TheSuperMouse","pythonw","python" -ErrorAction SilentlyContinue | Where-Object {
    $_.ProcessName -eq "TheSuperMouse" -or ($_.Path -and $_.Path -like "*TheSuperMouse*")
} | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Milliseconds 500

Write-Host "  [PROCESS] Removing shortcuts..." -ForegroundColor Cyan
$deskLnk = Join-Path ([Environment]::GetFolderPath('Desktop')) "THE SUPERMOUSE.lnk"
if (Test-Path $deskLnk) { Remove-Item $deskLnk -Force -ErrorAction SilentlyContinue }

if ($deleteDataFolder) {
    Write-Host "  [PROCESS] Deleting photos & stored files..." -ForegroundColor Yellow
    if (Test-Path $photosDir) { Remove-Item $photosDir -Recurse -Force -ErrorAction SilentlyContinue }
    if (Test-Path $altDataDir) { Remove-Item $altDataDir -Recurse -Force -ErrorAction SilentlyContinue }
} else {
    Write-Host "  [PROCESS] Keeping your photos & stored files safe at $displayLoc" -ForegroundColor Green
}

Write-Host "  [PROCESS] Removing software files & CLI command..." -ForegroundColor Cyan
# Clean bin directory from User PATH
$binDir = Join-Path $installDir "bin"
$userPath = [Environment]::GetEnvironmentVariable("Path", "User")
if ($userPath -and $userPath -like "*$binDir*") {
    $newPath = ($userPath.Split(';') | Where-Object { $_ -and $_ -ne $binDir }) -join ';'
    [Environment]::SetEnvironmentVariable("Path", $newPath, "User")
}

# Remove software files cleanly (keeping stored_files if user chose NO)
if (Test-Path $installDir) {
    Get-ChildItem -Path $installDir -Force | ForEach-Object {
        if (-not $deleteDataFolder -and $_.Name -eq "stored_files") { return }
        if ($_.Name -eq "bin") { return }
        Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
    }
    # Schedule self-removal of bin wrapper after PowerShell exits
    Start-Process cmd.exe -ArgumentList "/c timeout /t 2 /nobreak >nul & rmdir /s /q `"$binDir`"" -WindowStyle Hidden
}

Write-Host ""
Write-Host "  [PROCESS] DELETED." -ForegroundColor Green
Write-Host ""
