# -*- coding: utf-8 -*-
"""
THE SUPER MOUSE - UNIFIED ANTIGRAVITY PROCESS HUD
=============================================================================
Combines the third visual design (sleek compact capsule, arc spinner,
dual-tone inside gradient progress bar) with all the second logic and system
(Flash speed rule, stopwatch target timer, live transcript tracking, confetti).
=============================================================================
"""

import os
import sys
import json
import time
import math
import random
import ctypes
from ctypes import wintypes

# ── Attach to interactive Windows desktop ──────────────────────────────────────
user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32
WINSTA_ALL_ACCESS  = 0x37F
DESKTOP_ALL_ACCESS = 0x1FF

# Single Instance Mutex: prevent duplicate processes
ERROR_ALREADY_EXISTS = 183
mutex = kernel32.CreateMutexW(None, False, "AntigravityUnifiedHUD_SingleInstance_Mutex")
if kernel32.GetLastError() == ERROR_ALREADY_EXISTS:
    sys.exit(0)

try:
    hwinsta = user32.OpenWindowStationW("WinSta0", False, WINSTA_ALL_ACCESS)
    if hwinsta:
        user32.SetProcessWindowStation(hwinsta)
    hdesk = user32.OpenDesktopW("default", 0, False, DESKTOP_ALL_ACCESS)
    if hdesk:
        user32.SetThreadDesktop(hdesk)
except Exception:
    pass

from PySide6.QtCore import Qt, QTimer, QRectF, QPoint, QThread, Signal
from PySide6.QtGui import (
    QPainter, QColor, QFont, QPen, QLinearGradient, QPolygonF
)
from PySide6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFrame, QGraphicsDropShadowEffect, QSystemTrayIcon, QMenu
)

BRAIN_DIR = r"C:\Users\mytre\.gemini\antigravity\brain"
HOTKEY_ID = 9001
MOD_ALT = 0x0001
MOD_CONTROL = 0x0002
MOD_SHIFT = 0x0004
MOD_NOREPEAT = 0x4000
VK_A = 0x41
VK_P = 0x50
WM_HOTKEY = 0x0312


# ══════════════════════════════════════════════════════════════════════════════
#  ARC SPINNER (Third Design)
# ══════════════════════════════════════════════════════════════════════════════
class ArcSpinnerWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(18, 18)
        self.angle = 0
        self.anim_timer = QTimer(self)
        self.anim_timer.setInterval(25)
        self.anim_timer.timeout.connect(self._rotate)
        self.anim_timer.start()

    def _rotate(self):
        self.angle = (self.angle + 12) % 360
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        rect = QRectF(2, 2, self.width() - 4, self.height() - 4)

        p.setPen(QPen(QColor(255, 255, 255, 20), 2.2))
        p.drawEllipse(rect)

        pen = QPen(QColor("#CFFF48"), 2.2)
        pen.setCapStyle(Qt.RoundCap)
        p.setPen(pen)
        p.drawArc(rect, int(-self.angle * 16), int(100 * 16))
        p.end()


# ══════════════════════════════════════════════════════════════════════════════
#  HIGH-PRECISION PROGRESS BAR WITH INSIDE DUAL-TONE PERCENTAGE (Third Design)
# ══════════════════════════════════════════════════════════════════════════════
class InsidePercentageProgressBar(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(18)
        self.progress = 0.0
        self.suffix = ""

    def set_progress(self, val, suffix=""):
        self.progress = max(0.0, min(100.0, val))
        self.suffix = suffix
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)

        w, h = float(self.width()), float(self.height())
        radius = h / 2.0
        full_rect = QRectF(0, 0, w, h)

        # Track
        p.setPen(QPen(QColor(255, 255, 255, 18), 1.0))
        p.setBrush(QColor(255, 255, 255, 10))
        p.drawRoundedRect(full_rect, radius, radius)

        # Progress fill
        fill_w = max(h, (w * self.progress) / 100.0) if self.progress > 0.5 else 0.0
        if fill_w > 0:
            fill_rect = QRectF(0, 0, fill_w, h)
            grad = QLinearGradient(0, 0, fill_w, 0)
            grad.setColorAt(0.00, QColor("#FCFF00"))  # Radiant Yellow
            grad.setColorAt(0.50, QColor("#CFFF48"))  # Cyber Lime
            grad.setColorAt(1.00, QColor("#00FF85"))  # Vivid Emerald

            p.setPen(Qt.NoPen)
            p.setBrush(grad)
            p.drawRoundedRect(fill_rect, radius, radius)

        # Dual-tone text inside the pill
        if self.suffix:
            pct_text = f"{int(self.progress)}% • {self.suffix}"
        else:
            pct_text = f"{int(self.progress)}%"
        font = QFont("Segoe UI", 8.5, QFont.Bold)
        p.setFont(font)

        if fill_w > 0:
            p.save()
            p.setClipRect(QRectF(0, 0, fill_w, h))
            p.setPen(QColor("#041006"))
            p.drawText(full_rect, Qt.AlignCenter, pct_text)
            p.restore()

        p.save()
        p.setClipRect(QRectF(fill_w, 0, max(0.0, w - fill_w), h))
        p.setPen(QColor("#FFFFFF"))
        p.drawText(full_rect, Qt.AlignCenter, pct_text)
        p.restore()

        p.end()


# ══════════════════════════════════════════════════════════════════════════════
#  CONFETTI CELEBRATION (Second Logic)
# ══════════════════════════════════════════════════════════════════════════════
class ConfettiParticle:
    def __init__(self, x, y):
        self.x = float(x)
        self.y = float(y)
        angle = random.uniform(math.pi * 0.15, math.pi * 0.85)
        spd = random.uniform(2.5, 6.5)
        self.vx = math.cos(angle) * spd * (1 if random.random() > 0.5 else -1)
        self.vy = -math.sin(angle) * spd
        self.grav = 0.22
        self.life = 1.0
        self.decay = random.uniform(0.02, 0.045)
        self.color = random.choice([
            QColor("#FCFF00"), QColor("#CFFF48"), QColor("#00FF85"),
            QColor("#FFFFFF"), QColor("#38BDF8"), QColor("#F472B6")
        ])
        self.size = random.uniform(3.0, 5.5)

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.vy += self.grav
        self.life -= self.decay
        return self.life > 0


class ConfettiOverlay(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.particles = []
        self.timer = QTimer(self)
        self.timer.setInterval(20)
        self.timer.timeout.connect(self._step)

    def trigger_burst(self):
        cx = self.width() / 2.0
        cy = self.height() / 2.0
        self.particles = [ConfettiParticle(cx + random.uniform(-40, 40), cy) for _ in range(35)]
        self.timer.start()
        self.update()

    def _step(self):
        self.particles = [p for p in self.particles if p.update()]
        if not self.particles:
            self.timer.stop()
        self.update()

    def paintEvent(self, event):
        if not self.particles:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        for pt in self.particles:
            col = QColor(pt.color)
            col.setAlphaF(max(0.0, pt.life))
            p.setPen(Qt.NoPen)
            p.setBrush(col)
            p.drawEllipse(QRectF(pt.x, pt.y, pt.size, pt.size))
        p.end()


# ══════════════════════════════════════════════════════════════════════════════
#  HARDWARE HOTKEY POLLER
# ══════════════════════════════════════════════════════════════════════════════
class HardwareHotkeyPoller(QThread):
    triggered = Signal()

    def run(self):
        while True:
            time.sleep(0.08)
            # Alt + Ctrl + A
            alt = (user32.GetAsyncKeyState(0x12) & 0x8000) != 0
            ctrl = (user32.GetAsyncKeyState(0x11) & 0x8000) != 0
            key_a = (user32.GetAsyncKeyState(0x41) & 0x8000) != 0
            if alt and ctrl and key_a:
                self.triggered.emit()
                time.sleep(0.4)


# ══════════════════════════════════════════════════════════════════════════════
#  UNIFIED ANTIGRAVITY PROCESS HUD (Third Design + Second Logic & System)
# ══════════════════════════════════════════════════════════════════════════════
class UnifiedAntigravityHUD(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setWindowTitle("Antigravity Unified HUD")
        self.resize(390, 84)

        self.hwnd = int(self.winId())
        self.last_prompt_id = None
        self.prompt_time = 0.0
        self.target_time_sec = 30.0
        self.is_flash = False
        self.completed_steps = 0
        self.estimated_total_steps = 6
        self.avg_step_duration = 8.5
        self.last_step_count = -1
        self.step_start_time = 0.0
        self.pct = 0.0
        self.displayed_pct = 0.0
        self.state = "waiting"
        self.confetti_triggered = False
        self.drag_pos = None

        self._build_ui()
        self._position_top_center()
        self._setup_tray()
        self._register_native_hotkey()

        self.poller = HardwareHotkeyPoller()
        self.poller.triggered.connect(self.toggle)
        self.poller.start()

        self.timer = QTimer(self)
        self.timer.setInterval(60)
        self.timer.timeout.connect(self._tick)
        self.timer.start()

    def _register_native_hotkey(self):
        try:
            user32.RegisterHotKey(self.hwnd, HOTKEY_ID, MOD_ALT | MOD_CONTROL, VK_A)
        except Exception:
            pass

    def nativeEvent(self, eventType, message):
        try:
            msg = wintypes.MSG.from_address(int(message))
            if msg.message == WM_HOTKEY and msg.wParam == HOTKEY_ID:
                self.toggle()
                return True, 0
        except Exception:
            pass
        return False, 0

    def _setup_tray(self):
        self.tray = QSystemTrayIcon(self)
        self.tray.setToolTip("Antigravity Unified Process HUD (Ctrl + Alt + A)")
        menu = QMenu()
        act_toggle = menu.addAction("Toggle HUD (Ctrl + Alt + A)")
        act_toggle.triggered.connect(self.toggle)
        menu.addSeparator()
        act_exit = menu.addAction("Exit")
        act_exit.triggered.connect(QApplication.instance().quit)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(lambda r: self.toggle() if r == QSystemTrayIcon.Trigger else None)
        self.tray.show()

    def _build_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(6, 6, 6, 6)

        # Main Glass Panel (Third Design)
        self.panel = QFrame(self)
        self.panel.setObjectName("MainGlassPanel")
        self.panel.setStyleSheet("""
            #MainGlassPanel {
                background: qradialgradient(cx:0.5, cy:0.5, radius:0.85, fx:0.5, fy:0.5,
                    stop:0 rgba(14, 22, 17, 0.98),
                    stop:0.75 rgba(9, 14, 11, 0.99),
                    stop:1.0 rgba(15, 24, 18, 0.98));
                border: 1.2px solid rgba(207, 255, 72, 0.40);
                border-radius: 16px;
            }
            QLabel {
                background: transparent;
                border: none;
            }
        """)
        glow = QGraphicsDropShadowEffect(self)
        glow.setBlurRadius(22)
        glow.setColor(QColor(0, 0, 0, 180))
        glow.setOffset(0, 4)
        self.panel.setGraphicsEffect(glow)

        self.p_lay = QVBoxLayout(self.panel)
        self.p_lay.setContentsMargins(16, 10, 16, 12)
        self.p_lay.setSpacing(8)

        # Top row: [Spinner] [Action / Step text] [Stretch] [Timer / Target] [✕]
        top = QHBoxLayout()
        top.setContentsMargins(0, 0, 0, 0)
        top.setSpacing(8)

        self.spinner = ArcSpinnerWidget(self.panel)
        top.addWidget(self.spinner)

        self.lbl_task = QLabel(self.panel)
        self.lbl_task.setText('<span style="color:#CFFF48; font-size:11px; font-weight:800;">●</span> <span style="color:#FFFFFF; font-size:11px; font-weight:700;">Waiting for next task...</span>')
        self.lbl_task.setStyleSheet("font-family: 'Segoe UI', Arial, sans-serif;")
        top.addWidget(self.lbl_task)
        top.addStretch(1)

        self.lbl_time = QLabel("⏱ 00:00.0s / 00:30s", self.panel)
        self.lbl_time.setStyleSheet("color: #CFFF48; font-size: 11px; font-weight: 700; font-family: 'Consolas', 'Segoe UI', monospace;")
        top.addWidget(self.lbl_time)
        top.addSpacing(6)

        self.btn_close = QPushButton("✕", self.panel)
        self.btn_close.setFixedSize(16, 16)
        self.btn_close.setCursor(Qt.PointingHandCursor)
        self.btn_close.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 12);
                color: #94A3B8;
                border: none;
                border-radius: 8px;
                font-size: 10px;
                font-weight: 700;
            }
            QPushButton:hover {
                background: rgba(239, 68, 68, 50);
                color: #EF4444;
            }
        """)
        self.btn_close.clicked.connect(self.hide)
        top.addWidget(self.btn_close)

        self.p_lay.addLayout(top)

        # Bottom row 1: Active InsidePercentageProgressBar (Third Design)
        self.bar = InsidePercentageProgressBar(self.panel)
        self.bar.hide()
        self.p_lay.addWidget(self.bar)

        # Bottom row 2: Waiting badge (when completed)
        self.lbl_waiting_badge = QLabel("⚡ 100% DONE • READY FOR NEXT TASK", self.panel)
        self.lbl_waiting_badge.setStyleSheet("color: #CFFF48; font-size: 12px; font-weight: 800; letter-spacing: 0.6px; font-family: 'Segoe UI', Arial, sans-serif;")
        self.lbl_waiting_badge.setAlignment(Qt.AlignCenter)
        self.p_lay.addWidget(self.lbl_waiting_badge)

        lay.addWidget(self.panel)

        # Confetti overlay over entire window
        self.confetti = ConfettiOverlay(self)
        self.confetti.setGeometry(0, 0, 390, 84)

    def _position_top_center(self):
        screen = QApplication.primaryScreen()
        if screen:
            geom = screen.availableGeometry()
            self.move(geom.x() + (geom.width() - self.width()) // 2, geom.y() + 32)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        if hasattr(self, 'confetti'):
            self.confetti.setGeometry(0, 0, self.width(), self.height())

    def toggle(self):
        if self.isVisible():
            self.hide()
        else:
            self.show_to_front()

    def show_to_front(self):
        self.show()
        self.setWindowState(self.windowState() & ~Qt.WindowMinimized | Qt.WindowActive)
        self.raise_()
        self.activateWindow()
        try:
            hwnd = int(self.winId())
            user32.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0040)
            user32.SetForegroundWindow(hwnd)
        except Exception:
            pass

    def enforce_topmost(self):
        try:
            user32.SetWindowPos(self.hwnd, -1, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010)
        except Exception:
            pass

    # ══════════════════════════════════════════════════════════════════════════
    #  ALL SECOND LOGIC & SYSTEM
    # ══════════════════════════════════════════════════════════════════════════
    def _estimate_target_time(self, prompt_text):
        """Second logic: Flash speed rule & prompt analysis"""
        p_clean = prompt_text.strip()
        if p_clean.startswith("!!!") or "!!!" in p_clean:
            return 20.0, True
        if p_clean.startswith("!!") or "!!" in p_clean:
            return 20.0, True
        if p_clean.startswith("!"):
            return 30.0, True

        words = len(p_clean.split())
        is_complex = any(k in p_clean for k in [
            "redesign", "implement", "create", "architecture", "build", "refactor",
            "optimize", "pipeline", "component", "complete", "modal"
        ])

        if is_complex or words > 40:
            target = min(60.0, 35.0 + (words * 0.4))
        else:
            target = max(20.0, min(40.0, 15.0 + (words * 0.3)))
        return target, False

    def _tick(self):
        self.enforce_topmost()

        subdirs = [
            os.path.join(BRAIN_DIR, d)
            for d in os.listdir(BRAIN_DIR)
            if os.path.isdir(os.path.join(BRAIN_DIR, d)) and len(d) > 20
        ] if os.path.exists(BRAIN_DIR) else []
        if not subdirs:
            return

        subdirs.sort(key=os.path.getmtime, reverse=True)
        t_file = os.path.join(subdirs[0], ".system_generated", "logs", "transcript.jsonl")
        if not os.path.exists(t_file):
            return

        try:
            with open(t_file, "rb") as f:
                f.seek(0, os.SEEK_END)
                size = f.tell()
                f.seek(max(0, size - 80000))
                chunk = f.read().decode("utf-8", errors="ignore")
            lines = [json.loads(l) for l in chunk.strip().split("\n") if l.strip().startswith("{")]
        except Exception:
            return

        last_u = -1
        for i, item in enumerate(lines):
            if item.get("type") == "USER_INPUT":
                last_u = i
        if last_u < 0:
            return

        u_item = lines[last_u]
        cid = u_item.get("created_at", "")
        raw_prompt = str(u_item.get("content", ""))

        now = time.time()

        # New prompt initialization (Second logic)
        if self.last_prompt_id != cid:
            self.last_prompt_id = cid
            self.prompt_time = now
            self.target_time_sec, self.is_flash = self._estimate_target_time(raw_prompt)
            self.last_step_count = -1
            self.step_start_time = now
            self.completed_steps = 0
            self.estimated_total_steps = 5 if self.is_flash else 7
            self.avg_step_duration = 5.0 if self.is_flash else 8.5
            self.pct = 5.0
            self.displayed_pct = 5.0
            self.confetti_triggered = False
            self.state = "active"
            if not self.isVisible():
                self.show_to_front()

        subs = lines[last_u + 1:]
        tool_steps = [s for s in subs if s.get("tool_calls")]
        self.completed_steps = len(tool_steps)

        if self.completed_steps != self.last_step_count:
            self.last_step_count = self.completed_steps
            self.step_start_time = now

        if self.completed_steps >= self.estimated_total_steps:
            self.estimated_total_steps = self.completed_steps + 2

        is_done = False
        if subs:
            last_entry = subs[-1]
            if (last_entry.get("type") == "PLANNER_RESPONSE" and
                last_entry.get("content") and
                not last_entry.get("tool_calls") and
                last_entry.get("status") == "DONE"):
                is_done = True

        elapsed = max(0.0, now - self.prompt_time) if self.prompt_time > 0 else 0.0
        m = int(elapsed // 60)
        s = elapsed % 60
        elapsed_fmt = f"{m:02d}:{s:04.1f}s" if m > 0 else f"{s:04.1f}s"
        tgt_m = int(self.target_time_sec // 60)
        tgt_s = int(self.target_time_sec % 60)
        tgt_fmt = f"{tgt_m:02d}:{tgt_s:02d}s" if tgt_m > 0 else f"00:{tgt_s:02d}s"

        if not is_done:
            self.state = "active"
            self.lbl_waiting_badge.hide()
            self.spinner.show()
            self.bar.show()

            # Tool Action Analysis (Second System Logic)
            act_prefix = "Thinking"
            act_detail = "Planning next step..."
            if subs:
                last_entry = subs[-1]
                tcalls = last_entry.get("tool_calls", [])
                if tcalls:
                    tc = tcalls[0]
                    name = tc.get("name", "")
                    args = tc.get("args", {})
                    if isinstance(args, str):
                        try: args = json.loads(args)
                        except Exception: args = {}

                    if name == "edit_file":
                        p = args.get("Path", "")
                        b = os.path.basename(p.strip('"\'')) if p else "file"
                        act_prefix = "Editing"
                        act_detail = b
                    elif name == "write_file":
                        p = args.get("Path", "")
                        b = os.path.basename(p.strip('"\'')) if p else "file"
                        act_prefix = "Writing"
                        act_detail = b
                    elif name == "read_file":
                        p = args.get("Path", "")
                        b = os.path.basename(p.strip('"\'')) if p else "file"
                        act_prefix = "Reading"
                        act_detail = b
                    elif name == "run_command":
                        summ = str(args.get("toolSummary", "")).strip('"\'')
                        if summ:
                            if len(summ) > 24: summ = summ[:22] + ".."
                            act_prefix = "Running"
                            act_detail = summ
                        else:
                            act_prefix = "Running"
                            act_detail = "Command..."
                    elif name == "manage_task":
                        act = args.get("Action", "")
                        act_prefix = "Task"
                        act_detail = act if act else "Managing"
                    else:
                        act_prefix = "Step"
                        act_detail = name.replace('_', ' ').title()

            # Dynamic Header text
            if self.is_flash:
                self.lbl_task.setText(
                    f'<span style="color:#FFE600; font-size:11px; font-weight:800;">⚡ FLASH:</span> '
                    f'<span style="color:#FFFFFF; font-size:11px; font-weight:600;">{act_prefix} - {act_detail}</span>'
                )
            else:
                self.lbl_task.setText(
                    f'<span style="color:#CFFF48; font-size:11px; font-weight:800;">{act_prefix}:</span> '
                    f'<span style="color:#FFFFFF; font-size:11px; font-weight:600;">{act_detail}</span>'
                )

            # Timer Display: Elapsed / Target
            self.lbl_time.setText(f"⏱ {elapsed_fmt} / {tgt_fmt}")
            self.lbl_time.setStyleSheet(
                "color: #FFE600; font-size: 11px; font-weight: 700; font-family: 'Consolas', monospace;"
                if self.is_flash else
                "color: #CFFF48; font-size: 11px; font-weight: 700; font-family: 'Consolas', monospace;"
            )

            # Monotonic Smooth Percentage Progression
            step_base = (self.completed_steps / float(self.estimated_total_steps)) * 86.0
            time_in_step = max(0.0, now - self.step_start_time)
            micro_step = min(8.0, (time_in_step / max(3.0, self.avg_step_duration)) * 8.0)
            target_pct = min(96.0, max(self.pct, step_base + micro_step))

            self.pct = max(self.pct, target_pct)
            self.displayed_pct += (self.pct - self.displayed_pct) * 0.22

            if self.is_flash:
                step_suffix = f"FLASH ⚡ Step {self.completed_steps + 1}/{self.estimated_total_steps}"
            else:
                step_suffix = f"Step {self.completed_steps + 1}/{self.estimated_total_steps}"

            self.bar.set_progress(self.displayed_pct, suffix=step_suffix)

        else:
            # Done state
            self.state = "completed"
            self.spinner.hide()
            self.bar.hide()
            self.lbl_waiting_badge.setText(f"⚡ 100% DONE ({elapsed_fmt}) • READY FOR NEXT TASK")
            self.lbl_waiting_badge.show()

            self.lbl_task.setText(
                '<span style="color:#CFFF48; font-size:11px; font-weight:900;">●</span> '
                '<span style="color:#FFFFFF; font-size:11px; font-weight:700;">Waiting for next task...</span>'
            )
            self.lbl_time.setText(f"✓ Done in {elapsed_fmt}")
            self.lbl_time.setStyleSheet("color: #CFFF48; font-size: 11px; font-weight: 700; font-family: 'Segoe UI', monospace;")

            if not self.confetti_triggered:
                self.confetti_triggered = True
                self.confetti.trigger_burst()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.drag_pos = e.globalPosition().toPoint() - self.frameGeometry().topLeft()
    def mouseMoveEvent(self, e):
        if e.buttons() == Qt.LeftButton and self.drag_pos:
            self.move(e.globalPosition().toPoint() - self.drag_pos)
    def mouseReleaseEvent(self, e):
        self.drag_pos = None


def main():
    app = QApplication.instance() or QApplication(sys.argv)
    hud = UnifiedAntigravityHUD()
    hud.show_to_front()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
