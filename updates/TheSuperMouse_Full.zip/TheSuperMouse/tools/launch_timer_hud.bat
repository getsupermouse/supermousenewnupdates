@echo off
cd /d "%~dp0"
start "" pythonw antigravity_timer_hud.py

