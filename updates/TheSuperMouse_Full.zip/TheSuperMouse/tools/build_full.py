# -*- coding: utf-8 -*-
"""
THE SUPER MOUSE — Full Release Package Builder
Packs the entire software build directory into a release-ready zip file:
  - Excludes __pycache__, .git, and temporary files.
  - Outputs TheSuperMouse_Full.zip + SHA-256 checksum file.
"""
import argparse
import hashlib
import os
import zipfile

IGNORE_DIRS = {"__pycache__", ".git", ".venv", "venv", ".idea", ".vscode"}
IGNORE_EXTS = {".pyc", ".pyo", ".log", ".tmp"}


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest().lower()


def build_full_package(src_dir: str, out_dir: str, ver: str = "1.0") -> str:
    os.makedirs(out_dir, exist_ok=True)
    out_zip = os.path.join(out_dir, "TheSuperMouse_Full.zip")
    
    print(f"[*] Packaging full release from: {src_dir}")
    count = 0
    with zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for root, dirs, files in os.walk(src_dir):
            dirs[:] = [d for d in dirs if d not in IGNORE_DIRS]
            for fn in files:
                ext = os.path.splitext(fn)[1].lower()
                if ext in IGNORE_EXTS:
                    continue
                full_p = os.path.join(root, fn)
                rel_p = os.path.relpath(full_p, src_dir).replace("\\", "/")
                zf.write(full_p, arcname=f"TheSuperMouse/{rel_p}")
                count += 1

    size_mb = round(os.path.getsize(out_zip) / (1024 * 1024), 2)
    sha = sha256_file(out_zip)
    sha_file = os.path.join(out_dir, "TheSuperMouse_Full.sha256")
    with open(sha_file, "w", encoding="utf-8") as f:
        f.write(f"{sha} *TheSuperMouse_Full.zip\n")

    print(f"[+] COMPLETE: {out_zip} ({size_mb} MB, {count} files)")
    print(f"[+] SHA-256 : {sha}")
    return out_zip


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Package full SuperMouse release")
    parser.add_argument("--src", default=r"D:\THESUPERMOUSE\VERSION 1.0", help="Source folder to package")
    parser.add_argument("--out", default=r"D:\THESUPERMOUSE\dist_release", help="Destination folder")
    parser.add_argument("--ver", default="1.0", help="Release version")
    args = parser.parse_args()
    build_full_package(args.src, args.out, args.ver)
