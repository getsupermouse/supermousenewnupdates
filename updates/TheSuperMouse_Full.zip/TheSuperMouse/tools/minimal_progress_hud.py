# -*- coding: utf-8 -*-
"""
THE SUPER MOUSE - ANTIGRAVITY REAL-TIME PROGRESS, TASK MONITOR & LIVE TIMER HUD
=============================================================================
Role:
    A permanent top-most floating HUD (highest Z-index) that tracks Antigravity
    in real time. Shows:
    - Real-time stopwatch timer (00:00.0s) counting every millisecond while tasks run.
    - Live active task & folder action (e.g. "Run command: Test tool parsing").
    - Smooth animated progress bar.
    - Highest Z-index enforcement (Win32 HWND_TOPMOST).
    - Top-center placement so it is always instantly visible.
    - Windows Auto-Start registration so it launches on every system boot.
=============================================================================
"""

import os
import sys
import json
import time
import winreg
import ctypes
from ctypes import wintypes

# ── Attach to interactive Windows desktop ──────────────────────────────────────
user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32
WINSTA_ALL_ACCESS  = 0x37F
DESKTOP_ALL_ACCESS = 0x1FF

try:
    hwinsta = user32.OpenWindowStationW("WinSta0", False, WINSTA_ALL_ACCESS)
    if hwinsta:
        user32.SetProcessWindowStation(hwinsta)
        hdesk = user32.OpenDesktopW("default", 0, False, DESKTOP_ALL_ACCESS)
        if hdesk:
            user32.SetThreadDesktop(hdesk)
except Exception:
    pass

from PySide6.QtCore import Qt, QTimer, QRectF, QThread, Signal, QPoint
from PySide6.QtGui import QPainter, QColor, QFont, QIcon, QLinearGradient
from PySide6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QGraphicsDropShadowEffect, QFrame, QSystemTrayIcon, QMenu
)

BRAIN_DIR = r"C:\Users\mytre\.gemini\antigravity\brain"

MOD_ALT = 0x0001
MOD_SHIFT = 0x0004
VK_P = 0x50
WM_HOTKEY = 0x0312
HOTKEY_ID = 7777

TH32CS_SNAPPROCESS = 0x00000002
class PROCESSENTRY32(ctypes.Structure):
    _fields_ = [
        ('dwSize', wintypes.DWORD), ('cntUsage', wintypes.DWORD),
        ('th32ProcessID', wintypes.DWORD), ('th32DefaultHeapID', ctypes.c_size_t),
        ('th32ModuleID', wintypes.DWORD), ('cntThreads', wintypes.DWORD),
        ('th32ParentProcessID', wintypes.DWORD), ('pcPriClassBase', ctypes.c_long),
        ('dwFlags', wintypes.DWORD), ('szExeFile', ctypes.c_char * 260)
    ]

def is_antigravity_open():
    hSnapshot = kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
    if hSnapshot == -1: return False
    pe32 = PROCESSENTRY32()
    pe32.dwSize = ctypes.sizeof(PROCESSENTRY32)
    has_next = kernel32.Process32First(hSnapshot, ctypes.byref(pe32))
    found = False
    targets = {b'antigravity ide.exe', b'agy.exe', b'antigravity.exe'}
    while has_next:
        if pe32.szExeFile.lower() in targets:
            found = True
            break
        has_next = kernel32.Process32Next(hSnapshot, ctypes.byref(pe32))
    kernel32.CloseHandle(hSnapshot)
    return found

def register_autostart():
    try:
        pyw_exe = sys.executable.replace("python.exe", "pythonw.exe")
        script_path = os.path.abspath(__file__)
        cmd = f'"{pyw_exe}" "{script_path}"'
        key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, "AntigravityProgressHUD", 0, winreg.REG_SZ, cmd)
    except Exception:
        pass


# ──────────────────────────────────────────────────────────────────────────────
#  NEON PROGRESS BAR
# ──────────────────────────────────────────────────────────────────────────────
class MinimalProgressBar(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(5)
        self.progress = 0.0

    def set_progress(self, val):
        self.progress = max(0.0, min(100.0, float(val)))
        self.update()

    def paintEvent(self, e):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        w = self.width()
        h = self.height()

        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor(255, 255, 255, 18))
        painter.drawRoundedRect(QRectF(0, 0, w, h), 2.5, 2.5)

        fill_w = (w * self.progress) / 100.0
        if fill_w > 1.0:
            grad = QLinearGradient(0, 0, fill_w, 0)
            grad.setColorAt(0.0, QColor("#a3e635"))
            grad.setColorAt(1.0, QColor("#d9f99d"))
            painter.setBrush(grad)
            painter.drawRoundedRect(QRectF(0, 0, fill_w, h), 2.5, 2.5)


# ──────────────────────────────────────────────────────────────────────────────
#  GLOBAL HARDWARE HOTKEY POLLER
# ──────────────────────────────────────────────────────────────────────────────
class HardwareHotkeyPoller(QThread):
    triggered = Signal()

    def run(self):
        while True:
            time.sleep(0.02)
            if bool(user32.GetAsyncKeyState(VK_P) & 0x8000):
                if bool(user32.GetAsyncKeyState(0x10) & 0x8000) and bool(user32.GetAsyncKeyState(0x12) & 0x8000):
                    self.triggered.emit()
                    time.sleep(0.4)


# ──────────────────────────────────────────────────────────────────────────────
#  MAIN PROGRESS & REAL-TIME TIMER HUD
# ──────────────────────────────────────────────────────────────────────────────
class MinimalProgressHUD(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(
            Qt.FramelessWindowHint |
            Qt.WindowStaysOnTopHint |
            Qt.SubWindow |
            Qt.NoDropShadowWindowHint
        )
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(380, 96)

        self.drag_pos = None
        self.pct = 0.0
        self.displayed_pct = 0.0
        self.last_prompt_id = ""
        self.prompt_start_time = None
        self.elapsed_frozen = 0.0
        self.is_running_task = False
        self.ag_was_running = False

        self._build_ui()
        self._position_top_center()
        self._setup_tray()

        self.hwnd = int(self.winId())
        self._register_native_hotkey()

        self.poller = HardwareHotkeyPoller()
        self.poller.triggered.connect(self.toggle)
        self.poller.start()

        # Ultra-fast 40ms monitoring loop
        self.timer = QTimer(self)
        self.timer.setInterval(40)
        self.timer.timeout.connect(self._tick)
        self.timer.start()

        register_autostart()

    def _register_native_hotkey(self):
        try:
            user32.RegisterHotKey(self.hwnd, HOTKEY_ID, MOD_ALT | MOD_SHIFT, VK_P)
        except Exception:
            pass

    def nativeEvent(self, eventType, message):
        try:
            msg = wintypes.MSG.from_address(int(message))
            if msg.message == WM_HOTKEY and msg.wParam == HOTKEY_ID:
                self.toggle()
                return True, 0
        except Exception:
            pass
        return False, 0

    def _setup_tray(self):
        ico_file = r"D:\THESUPERMOUSE\thesupermouse\assets\hud_icons\supermouse_logo.ico"
        self.tray = QSystemTrayIcon(self)
        if os.path.exists(ico_file):
            self.tray.setIcon(QIcon(ico_file))
        self.tray.setToolTip("Antigravity Real-Time Timer (Shift + Alt + P)")
        menu = QMenu()
        act_toggle = menu.addAction("Toggle Timer HUD (Shift + Alt + P)")
        act_toggle.triggered.connect(self.toggle)
        menu.addSeparator()
        act_exit = menu.addAction("Exit")
        act_exit.triggered.connect(QApplication.instance().quit)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(lambda r: self.toggle() if r == QSystemTrayIcon.Trigger else None)
        self.tray.show()

    def _build_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(6, 6, 6, 6)

        self.panel = QFrame(self)
        self.panel.setStyleSheet("""
            QFrame {
                background: rgba(10, 12, 16, 0.98);
                border: 1.5px solid rgba(163, 230, 53, 0.50);
                border-radius: 14px;
            }
        """)
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(24)
        shadow.setColor(QColor(0, 0, 0, 220))
        shadow.setOffset(0, 4)
        self.panel.setGraphicsEffect(shadow)

        p_lay = QVBoxLayout(self.panel)
        p_lay.setContentsMargins(14, 8, 14, 8)
        p_lay.setSpacing(5)

        # ── Row 1: [● RUNNING TASK] [00:04.2s] [85%] [✕] ──────────────────
        top = QHBoxLayout()
        top.setContentsMargins(0, 0, 0, 0)
        top.setSpacing(8)

        self.lbl_tag = QLabel("● ANTIGRAVITY", self.panel)
        self.lbl_tag.setStyleSheet("color: #a3e635; font-size: 10px; font-weight: 800; letter-spacing: 0.8px;")
        top.addWidget(self.lbl_tag)

        top.addStretch()

        # Precision Stopwatch Badge
        self.lbl_timer = QLabel("00:00.0s", self.panel)
        self.lbl_timer.setStyleSheet("""
            QLabel {
                color: #a3e635;
                background: rgba(163, 230, 53, 0.16);
                border: 1px solid rgba(163, 230, 53, 0.50);
                border-radius: 5px;
                padding: 1px 7px;
                font-family: 'Consolas', 'Courier New', monospace;
                font-size: 12px;
                font-weight: 800;
            }
        """)
        top.addWidget(self.lbl_timer)

        self.lbl_pct = QLabel("0%", self.panel)
        self.lbl_pct.setStyleSheet("color: #FFFFFF; font-size: 12px; font-weight: 800; min-width: 32px;")
        top.addWidget(self.lbl_pct)

        self.btn_close = QPushButton("✕", self.panel)
        self.btn_close.setFixedSize(18, 18)
        self.btn_close.setCursor(Qt.PointingHandCursor)
        self.btn_close.setToolTip("Hide (Press Shift + Alt + P to reveal)")
        self.btn_close.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.08);
                color: #94A3B8;
                border: 1px solid rgba(255, 255, 255, 0.15);
                border-radius: 9px;
                font-size: 10px;
                font-weight: 700;
            }
            QPushButton:hover {
                background: rgba(239, 68, 68, 0.35);
                color: #ef4444;
                border: 1px solid #ef4444;
            }
        """)
        self.btn_close.clicked.connect(self.hide)
        top.addWidget(self.btn_close)

        p_lay.addLayout(top)

        # ── Row 2: Live Action & Folder Info ──────────────────────────────────
        self.lbl_action = QLabel("Listening for prompt...", self.panel)
        self.lbl_action.setStyleSheet("""
            QLabel {
                color: #94A3B8;
                font-size: 10.5px;
                font-family: 'Segoe UI', sans-serif;
                font-weight: 600;
            }
        """)
        p_lay.addWidget(self.lbl_action)

        # ── Row 3: Neon Progress Bar ──────────────────────────────────────────
        self.bar = MinimalProgressBar(self.panel)
        p_lay.addWidget(self.bar)

        lay.addWidget(self.panel)

    def _position_top_center(self):
        screen = QApplication.primaryScreen()
        if not screen: return
        geo = screen.availableGeometry()
        w = self.width()
        x = geo.x() + (geo.width() - w) // 2
        y = geo.y() + 16
        self.move(x, y)

    def enforce_topmost(self):
        try:
            user32.SetWindowPos(self.hwnd, -1, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010 | 0x0040)
        except Exception:
            pass

    def show_to_front(self):
        self.show()
        self.raise_()
        self.activateWindow()
        self.enforce_topmost()

    def _tick(self):
        # 1. Enforce Permanent Highest Z-Index
        if self.isVisible():
            self.enforce_topmost()

        # 2. Locate Active Transcript
        subdirs = [os.path.join(BRAIN_DIR, d) for d in os.listdir(BRAIN_DIR) if os.path.isdir(os.path.join(BRAIN_DIR, d)) and len(d) > 20] if os.path.exists(BRAIN_DIR) else []
        if not subdirs: return
        subdirs.sort(key=os.path.getmtime, reverse=True)
        t_file = os.path.join(subdirs[0], ".system_generated", "logs", "transcript.jsonl")
        if not os.path.exists(t_file): return

        # 3. Read Recent Events Safely
        try:
            with open(t_file, "rb") as f:
                f.seek(0, os.SEEK_END)
                size = f.tell()
                f.seek(max(0, size - 160000))
                chunk = f.read().decode("utf-8", errors="ignore")
            
            raw_splits = chunk.strip().split("\n")
            lines = []
            for item in raw_splits:
                item = item.strip()
                if item.startswith("{") and item.endswith("}"):
                    try:
                        lines.append(json.loads(item))
                    except Exception:
                        pass
        except Exception:
            return

        if not lines: return

        # Locate latest USER_INPUT
        last_u = -1
        for i, item in enumerate(lines):
            if item.get("type") == "USER_INPUT":
                last_u = i

        if last_u < 0: return

        u_item = lines[last_u]
        cid = u_item.get("created_at", "")

        # 4. Auto-Appear & Start Stopwatch on Prompt
        if self.last_prompt_id != cid:
            self.last_prompt_id = cid
            self.prompt_start_time = time.time()
            self.is_running_task = True
            # Auto-appear immediately
            self.show_to_front()

        subs = lines[last_u+1:]
        steps = sum(1 for s in subs if "tool_calls" in s and s["tool_calls"])

        latest_action = "Running task..."
        for s in reversed(subs):
            calls = s.get("tool_calls") or []
            if calls:
                c0 = calls[-1]
                name = c0.get("name", "")
                args = c0.get("args") or {}
                summary = args.get("toolSummary")
                path = args.get("Path")
                cmd = args.get("CommandLine")
                
                if summary:
                    summary_clean = str(summary).strip('"\'')
                    latest_action = f"⚡ {name}: {summary_clean}"
                elif path:
                    base = os.path.basename(str(path).strip('"\''))
                    latest_action = f"📁 {name}: {base}"
                elif cmd:
                    cmd_clean = str(cmd).strip('"\'')[:35]
                    latest_action = f"⚙ {name}: {cmd_clean}"
                else:
                    latest_action = f"⚙ Running {name}..."
                break

        is_done = any(
            s.get("type") == "PLANNER_RESPONSE" and s.get("content") and not s.get("tool_calls")
            for s in subs
        )

        now = time.time()

        if not is_done:
            # Task in progress
            self.is_running_task = True
            if not self.isVisible():
                self.show_to_front()

            self.lbl_tag.setText("● WORKING")
            self.lbl_tag.setStyleSheet("color: #a3e635; font-size: 10px; font-weight: 800; letter-spacing: 0.8px;")
            
            elapsed = now - (self.prompt_start_time or now)
            mins = int(elapsed // 60)
            secs = elapsed % 60
            self.lbl_timer.setText(f"{mins:02d}:{secs:04.1f}s")
            self.lbl_timer.setStyleSheet("""
                QLabel {
                    color: #a3e635;
                    background: rgba(163, 230, 53, 0.16);
                    border: 1px solid rgba(163, 230, 53, 0.50);
                    border-radius: 5px;
                    padding: 1px 7px;
                    font-family: 'Consolas', 'Courier New', monospace;
                    font-size: 12px;
                    font-weight: 800;
                }
            """)

            if len(latest_action) > 44:
                latest_action = latest_action[:41] + "..."
            self.lbl_action.setText(latest_action)
            self.lbl_action.setStyleSheet("color: #F1F5F9; font-size: 10.5px; font-family: 'Segoe UI', sans-serif; font-weight: 600;")

            self.pct = min(96.0, 15.0 + (steps / max(steps + 1, 5)) * 70.0 + min(12.0, elapsed * 0.4))

        else:
            if self.is_running_task:
                self.is_running_task = False
                if self.prompt_start_time:
                    self.elapsed_frozen = now - self.prompt_start_time

            self.lbl_tag.setText("✓ COMPLETED")
            self.lbl_tag.setStyleSheet("color: #00FF85; font-size: 10px; font-weight: 800; letter-spacing: 0.8px;")
            self.pct = 100.0

            mins = int(self.elapsed_frozen // 60)
            secs = self.elapsed_frozen % 60
            self.lbl_timer.setText(f"{mins:02d}:{secs:04.1f}s")
            self.lbl_timer.setStyleSheet("""
                QLabel {
                    color: #00FF85;
                    background: rgba(0, 255, 133, 0.14);
                    border: 1px solid rgba(0, 255, 133, 0.40);
                    border-radius: 5px;
                    padding: 1px 7px;
                    font-family: 'Consolas', 'Courier New', monospace;
                    font-size: 12px;
                    font-weight: 800;
                }
            """)

            self.lbl_action.setText(f"✓ Task finished in {self.elapsed_frozen:.1f}s")
            self.lbl_action.setStyleSheet("color: #94A3B8; font-size: 10.5px; font-family: 'Segoe UI', sans-serif; font-weight: 600;")

        self.displayed_pct += (self.pct - self.displayed_pct) * 0.3
        if abs(self.displayed_pct - self.pct) < 0.2:
            self.displayed_pct = self.pct

        self.lbl_pct.setText(f"{int(self.displayed_pct)}%")
        self.bar.set_progress(self.displayed_pct)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.drag_pos = e.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, e):
        if e.buttons() == Qt.LeftButton and self.drag_pos:
            self.move(e.globalPosition().toPoint() - self.drag_pos)

    def mouseReleaseEvent(self, e):
        self.drag_pos = None

    def toggle(self):
        if self.isVisible():
            self.hide()
        else:
            self.show_to_front()


def main():
    app = QApplication.instance() or QApplication(sys.argv)
    hud = MinimalProgressHUD()
    hud.show_to_front()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
