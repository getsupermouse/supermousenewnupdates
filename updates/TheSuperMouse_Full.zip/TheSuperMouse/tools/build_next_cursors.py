import os
import struct
import io
from PySide6.QtGui import QImage, QPainter, QColor
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtCore import QByteArray
from PIL import Image

assets_dir = r"D:\THESUPERMOUSE\thesupermouse\assets"

GRAD = """<defs>
  <linearGradient id="g" x1="0%" y1="0%" x2="0%" y2="100%">
    <stop offset="0%" stop-color="#FCFF00"/>
    <stop offset="45%" stop-color="#84FF00"/>
    <stop offset="100%" stop-color="#00FF85"/>
  </linearGradient>
</defs>"""

# 1. Zoom In (Magnifier with +)
SVG_ZOOM_IN = f"""<svg width="256" height="256" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
{GRAD}
<circle cx="10" cy="10" r="7" stroke="url(#g)" stroke-width="2.2"/>
<line x1="15" y1="15" x2="22" y2="22" stroke="url(#g)" stroke-width="3" stroke-linecap="round"/>
<line x1="10" y1="7" x2="10" y2="13" stroke="#FCFF00" stroke-width="1.8" stroke-linecap="round"/>
<line x1="7" y1="10" x2="13" y2="10" stroke="#FCFF00" stroke-width="1.8" stroke-linecap="round"/>
</svg>"""

# 2. Zoom Out (Magnifier with -)
SVG_ZOOM_OUT = f"""<svg width="256" height="256" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
{GRAD}
<circle cx="10" cy="10" r="7" stroke="url(#g)" stroke-width="2.2"/>
<line x1="15" y1="15" x2="22" y2="22" stroke="url(#g)" stroke-width="3" stroke-linecap="round"/>
<line x1="7" y1="10" x2="13" y2="10" stroke="#FCFF00" stroke-width="1.8" stroke-linecap="round"/>
</svg>"""

# 3. Busy (Fluent Smooth Arc Ring)
SVG_BUSY = f"""<svg width="256" height="256" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
{GRAD}
<circle cx="12" cy="12" r="9" stroke="#161E2E" stroke-width="2.8"/>
<circle cx="12" cy="12" r="9" stroke="url(#g)" stroke-width="2.8" stroke-linecap="round" stroke-dasharray="25 35"/>
<circle cx="12" cy="12" r="1.5" fill="#FCFF00"/>
</svg>"""

# 4. Grab (Natural Open Palm - from Bibata)
with open(os.path.join(assets_dir, 'bibata_hand1.svg'), 'r') as f:
    raw_grab = f.read()
# Replace fill with our gradient
SVG_GRAB = raw_grab.replace('fill="#0000FF"', 'fill="#000000"').replace('fill="#00FF00"', 'fill="url(#g)"').replace('<defs>', GRAD)
if '<defs>' not in raw_grab:
    SVG_GRAB = SVG_GRAB.replace('<svg width="256" height="256" viewBox="0 0 256 256" fill="none" xmlns="http://www.w3.org/2000/svg">', f'<svg width="256" height="256" viewBox="0 0 256 256" fill="none" xmlns="http://www.w3.org/2000/svg">{GRAD}')

# 5. Grabbing (Natural Closed Fist - from Bibata)
with open(os.path.join(assets_dir, 'bibata_grabbing.svg'), 'r') as f:
    raw_grabbing = f.read()
SVG_GRABBING = raw_grabbing.replace('fill="#0000FF"', 'fill="#000000"').replace('fill="#00FF00"', 'fill="url(#g)"').replace('<defs>', GRAD)
if '<defs>' not in raw_grabbing:
    SVG_GRABBING = SVG_GRABBING.replace('<svg width="256" height="256" viewBox="0 0 256 256" fill="none" xmlns="http://www.w3.org/2000/svg">', f'<svg width="256" height="256" viewBox="0 0 256 256" fill="none" xmlns="http://www.w3.org/2000/svg">{GRAD}')

# 6. Help / Info (ONLY Question Mark)
SVG_HELP = f"""<svg width="256" height="256" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
{GRAD}
<path d="M 9 9 C 9 6.8 10.3 5 12 5 C 13.7 5 15 6.3 15 8 C 15 9.7 13.5 10.8 12.5 11.8 C 11.8 12.5 11.5 13.2 11.5 14.5" stroke="url(#g)" stroke-width="2.6" stroke-linecap="round"/>
<circle cx="11.5" cy="18.5" r="1.6" fill="#00FF85"/>
</svg>"""

# 7. Move (4-Way Navigation Arrow Compass)
SVG_MOVE = f"""<svg width="256" height="256" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
{GRAD}
<path d="M 12 2 L 15 6 L 13 6 L 13 11 L 18 11 L 18 9 L 22 12 L 18 15 L 18 13 L 13 13 L 13 18 L 15 18 L 12 22 L 9 18 L 11 18 L 11 13 L 6 13 L 6 15 L 2 12 L 6 9 L 6 11 L 11 11 L 11 6 L 9 6 Z" fill="url(#g)" stroke="#000000" stroke-width="1.2" stroke-linejoin="round"/>
</svg>"""

CURSORS_TO_BUILD = [
    ("supermouse_zoom_in", SVG_ZOOM_IN, (10, 10)),
    ("supermouse_zoom_out", SVG_ZOOM_OUT, (10, 10)),
    ("supermouse_busy", SVG_BUSY, (12, 12)),
    ("supermouse_grab", SVG_GRAB, (12, 12)),
    ("supermouse_grabbing", SVG_GRABBING, (12, 12)),
    ("supermouse_help", SVG_HELP, (12, 12)),
    ("supermouse_move", SVG_MOVE, (12, 12)),
]

for name, svg_str, (rel_hx, rel_hy) in CURSORS_TO_BUILD:
    renderer = QSvgRenderer(QByteArray(svg_str.encode("utf-8")))
    frames = []
    for c_size, b_w in [(32, 16), (48, 24), (64, 32)]:
        qimg = QImage(256, 256, QImage.Format_ARGB32_Premultiplied)
        qimg.fill(QColor(0, 0, 0, 0))
        p = QPainter(qimg)
        renderer.render(p)
        p.end()

        tmp_png = os.path.join(assets_dir, f"tmp_{name}_{c_size}.png")
        qimg.save(tmp_png, "PNG")
        pil_master = Image.open(tmp_png)
        bbox = pil_master.getbbox()
        cropped = pil_master.crop(bbox) if bbox else pil_master
        if os.path.exists(tmp_png):
            os.remove(tmp_png)

        aspect = cropped.height / max(1, cropped.width)
        b_h = int(b_w * aspect)
        scaled = cropped.resize((b_w, b_h), Image.Resampling.LANCZOS)

        canvas = Image.new("RGBA", (c_size, c_size), (0, 0, 0, 0))
        canvas.paste(scaled, (0, 0))
        hx = int(rel_hx * b_w / 24.0)
        hy = int(rel_hy * b_h / 24.0)
        frames.append((c_size, canvas, (hx, hy)))

    png_blobs = []
    entries = []
    for size, img, hs in frames:
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        data = buf.getvalue()
        png_blobs.append(data)
        entries.append({"w": size, "h": size, "hx": hs[0], "hy": hs[1], "size": len(data)})

    offset = 6 + 16 * len(entries)
    cur_bytes = bytearray(struct.pack("<HHH", 0, 2, len(entries)))
    for e in entries:
        cur_bytes.extend(struct.pack("<BBBBHHII", e["w"], e["h"], 0, 0, e["hx"], e["hy"], e["size"], offset))
        offset += e["size"]
    for b in png_blobs:
        cur_bytes.extend(b)

    with open(os.path.join(assets_dir, f"{name}.cur"), "wb") as f:
        f.write(cur_bytes)

print("Generated all 7 custom cursors successfully!")

