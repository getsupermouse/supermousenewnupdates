# -*- coding: utf-8 -*-
"""
THE SUPER MOUSE - SYSTEM & APP SELECTION THEME MANAGER
======================================================
Overrides default Windows blue text/marquee selection with SuperMouse Obsidian-Lime
(#a3e635 highlight + #040405 text) cleanly across:
  1. PySide6 / Qt Application (QPalette Highlight + HighlightedText)
  2. Windows Registry HKCU\\Control Panel\\Colors & Live Win32 SetSysColors
     (affects Desktop marquee/hot-tracking, Win32 controls, Notepad, dialogs)
  3. Cleanly saves and restores user's original Windows colors on exit.
"""

import os
import sys
import json
import ctypes
import winreg

from PySide6.QtGui import QColor, QPalette


def _find_base_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    cur = os.path.abspath(__file__)
    for _ in range(6):
        cur = os.path.dirname(cur)
        if os.path.isdir(os.path.join(cur, "thesupermouse", "assets")):
            return cur
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

BASE_DIR = _find_base_dir()
BACKUP_JSON = os.path.join(BASE_DIR, "thesupermouse", "orig_selection_colors.json")
BROWSER_EXT_DIR = os.path.join(BASE_DIR, "thesupermouse", "browser_selection_theme")

# Win32 GetSysColor / SetSysColors constants
COLOR_HIGHLIGHT = 13
COLOR_HIGHLIGHTTEXT = 14
COLOR_HOTLIGHT = 26
COLOR_MENUHILIGHT = 29

# SuperMouse Signature Selection Colors: Neon Lime (#a3e635) + Deep Obsidian (#040405)
SM_HILIGHT_RGB = (163, 230, 53)
SM_HILIGHT_TEXT_RGB = (4, 4, 5)
SM_HOT_RGB = (163, 230, 53)

REG_KEYS = {
    "Hilight": "163 230 53",
    "HilightText": "4 4 5",
    "HotTrackingColor": "163 230 53",
    "MenuHilight": "163 230 53",
}


def _rgb_to_colorref(rgb):
    r, g, b = rgb
    return (b << 16) | (g << 8) | r


def _parse_rgb_str(s, fallback):
    try:
        parts = [int(x) for x in str(s).strip().split()]
        if len(parts) == 3:
            return tuple(max(0, min(255, x)) for x in parts)
    except Exception:
        pass
    return fallback


def _backup_original_reg_colors():
    if os.path.exists(BACKUP_JSON):
        try:
            with open(BACKUP_JSON, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict) and "Hilight" in data:
                    return data
        except Exception:
            pass

    orig = {}
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Control Panel\Colors", 0, winreg.KEY_READ) as k:
            for name in REG_KEYS:
                try:
                    val, _ = winreg.QueryValueEx(k, name)
                    orig[name] = str(val)
                except FileNotFoundError:
                    orig[name] = "0 120 212" if name != "HilightText" else "255 255 255"
    except Exception:
        orig = {
            "Hilight": "0 120 212",
            "HilightText": "255 255 255",
            "HotTrackingColor": "0 102 204",
            "MenuHilight": "0 120 212",
        }

    try:
        os.makedirs(os.path.dirname(BACKUP_JSON), exist_ok=True)
        with open(BACKUP_JSON, "w", encoding="utf-8") as f:
            json.dump(orig, f, indent=2)
    except Exception:
        pass
    return orig


def _apply_win_colors_map(col_map: dict):
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Control Panel\Colors", 0, winreg.KEY_SET_VALUE) as k:
            for name, val in col_map.items():
                winreg.SetValueEx(k, name, 0, winreg.REG_SZ, str(val))
    except Exception:
        pass

    try:
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        user32.SetSysColors.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_uint32)]
        user32.SetSysColors.restype = ctypes.c_int
        user32.SendMessageTimeoutW.argtypes = [
            ctypes.c_void_p, ctypes.c_uint, ctypes.c_size_t, ctypes.c_wchar_p,
            ctypes.c_uint, ctypes.c_uint, ctypes.POINTER(ctypes.c_size_t),
        ]
        user32.SendMessageTimeoutW.restype = ctypes.c_ssize_t

        idx_arr = (ctypes.c_int * 4)(COLOR_HIGHLIGHT, COLOR_HIGHLIGHTTEXT, COLOR_HOTLIGHT, COLOR_MENUHILIGHT)
        c_hi = _rgb_to_colorref(_parse_rgb_str(col_map.get("Hilight", "163 230 53"), SM_HILIGHT_RGB))
        c_tx = _rgb_to_colorref(_parse_rgb_str(col_map.get("HilightText", "4 4 5"), SM_HILIGHT_TEXT_RGB))
        c_ho = _rgb_to_colorref(_parse_rgb_str(col_map.get("HotTrackingColor", "163 230 53"), SM_HOT_RGB))
        c_mh = _rgb_to_colorref(_parse_rgb_str(col_map.get("MenuHilight", "163 230 53"), SM_HILIGHT_RGB))
        val_arr = (ctypes.c_uint32 * 4)(c_hi, c_tx, c_ho, c_mh)
        user32.SetSysColors(4, idx_arr, val_arr)

        # Notify open desktop / Win32 windows about color palette change (non-blocking)
        HWND_BROADCAST = ctypes.c_void_p(0xFFFF)
        WM_SYSCOLORCHANGE = 0x0015
        WM_SETTINGCHANGE = 0x001A
        SMTO_ABORTIFHUNG = 0x0002
        res = ctypes.c_size_t()
        user32.SendMessageTimeoutW(HWND_BROADCAST, WM_SYSCOLORCHANGE, 0, None, SMTO_ABORTIFHUNG, 250, ctypes.byref(res))
        user32.SendMessageTimeoutW(
            HWND_BROADCAST, WM_SETTINGCHANGE, 0, r"Control Panel\Colors", SMTO_ABORTIFHUNG, 250, ctypes.byref(res)
        )
    except Exception:
        pass


def apply_qt_selection_palette(app):
    if app is None:
        return
    pal = app.palette()
    lime = QColor("#a3e635")
    obsidian = QColor("#040405")
    for grp in (QPalette.Active, QPalette.Inactive, QPalette.Disabled):
        pal.setColor(grp, QPalette.Highlight, lime)
        pal.setColor(grp, QPalette.HighlightedText, obsidian)
    app.setPalette(pal)


def apply_supermouse_selection_theme(app=None):
    _backup_original_reg_colors()
    apply_qt_selection_palette(app)
    _apply_win_colors_map(REG_KEYS)


def restore_original_selection_theme():
    if not os.path.exists(BACKUP_JSON):
        return
    try:
        with open(BACKUP_JSON, "r", encoding="utf-8") as f:
            orig = json.load(f)
        if isinstance(orig, dict):
            _apply_win_colors_map(orig)
    except Exception:
        pass
