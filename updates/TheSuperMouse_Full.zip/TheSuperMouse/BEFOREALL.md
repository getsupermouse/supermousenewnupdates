# BEFOREALL - CRITICAL EXECUTION RULES & USER MANDATES

BEFORE STARTING ANY WORK ON ANY USER COMMAND, STRICTLY READ AND ENFORCE THESE MANDATORY RULES:

## 1. 12x MAXIMUM BLITZ SPEED (< 1 MINUTE EXECUTION)
- Finish all tasks under 1 minute. Speed up execution 12x.
- Zero delay, zero dawdling, zero hesitation.
- **Meanwhile Timer & Self-Termination:** 1-2 min hard ceiling for all tasks—if you take even 1 second extra, terminate and improve. Keep a continuous 5-second mental tick countdown reminding yourself time is strictly limited.
- **Laser Focus:** Complete the focused task instantly without even looking at other unrelated files.

## 2. ELIMINATE REDUNDANT WORK & OVER-ANALYZING
- Stop excessive reading, re-reading, and unnecessary analysis of unrelated files.
- Go directly to the exact target file and line.
- Focus purely on the main requested task and fix without side-tracking.

## 3. USE USER'S PRE-SET COMMENTS & MINDMAP
- Leverage the codebase comments and established architecture immediately instead of re-exploring.
- Execute targeted modifications directly as instructed.

## 4. STRICT RESPONSE FORMAT: ONE SHORT PARAGRAPH ONLY
- Direct responses to the user MUST ALWAYS BE EXACTLY ONE SHORT PARAGRAPH SUMMARY AT ANY COST.
- NO bullet points, NO lists, NO multi-line essays in user responses.

## 5. USER MANDATES FROM LOGS
> "whats the meaning of fast dude? under 1 min and u taking 10x more time i want that start a meanwhile timer of 1 min that respond on every 5 second u coming to end and increase ur task and also i want that speed up 12x speed of ur and reducing extra work just focus on main task to increase app i am not giving u any harsh task just some small fixies and even in that u taking too much time. follow the rules dude and please in every task use it i dont want that u will ruined my time u take 10 min for just a small task dude ah i have less than one hour and i want to complete and u ahh men REAd all the files completely AND WHAT HAPPEND TO UR MINDMAP WHY U NOT USING DUDE WE ALSO SET AND DOIN COMMENTS BEFORE EVERYTHING ITS NOT FAIR TO TAKE THAT MUCH TIME TELL ME I AM WRONG?"

> "thats the problem dude u doing reading and analyzing things thats no needed i take every precuatuon and see same headache its worst i told u before starting task related to this file we need to do i told and did the comments too much for file and analyzie it before and be ready giving u short task so u can increase ur speed AFter that still i am hurt"

> "all overhead and excess reads, locked into maximum blitz execution, and am ready for your fixes right now."
