# -*- coding: utf-8 -*-
"""
THE SUPER MOUSE — SuperUpdateWindow & Floating Gradient Download Pill
  - Pure Neutral Monochrome Obsidian Typography (ZERO blue-grey, ZERO Roboto/monospace in MB)
  - Exact Cursor Window header ('THE' white + 'UPDATE' #FFFF00 -> #00FF85 gradient, 11.4pt Display Bold)
  - Boxless Accounting Ledger: S.NO | 75% Particulars (Big crisp Headline + sharp large Sub-text + Date)
    | 15% empty gap | Numeric MB + circular White Download icon
  - Bottom Subtotal HR line: White 'Refresh' button | Combined Total MB | Green 'Download All' (disabled when 0 updates)
  - On Download / Download All: closes all open software windows & flies a wide gradient pill from the last
    window's position smoothly to bottom-right showing live Downloading & Installing, then launches a fresh Cursor Window!
"""
import math
import os

from PySide6.QtCore import (
    Qt,
    QByteArray,
    QPoint,
    QPointF,
    QRect,
    QRectF,
    QTimer,
    QPropertyAnimation,
    QParallelAnimationGroup,
    QEasingCurve,
)
from PySide6.QtGui import (
    QColor,
    QCursor,
    QFont,
    QFontMetrics,
    QImage,
    QLinearGradient,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
)
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from ui_theme import CleanBackButton, CleanCloseButton, apply_window_identity, native_dpr
from .patch_engine import PatchChecker, get_patch_checker

_DOWNLOAD_SVG = (
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">'
    '<g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2">'
    '<path d="M12 3v12m0 0-4.5-4.5M12 15l4.5-4.5"/>'
    '<path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/>'
    '</g></svg>'
)


class _PatchProgressPillWindow(QWidget):
    """
    Wide Gradient Floating Pill:
      - Spawns at the last open window's exact position and smoothly flies to Bottom-Right above taskbar.
      - Vibrant animated #FFFF00 -> #A3E635 -> #00FF85 gradient pill border + smooth progress fill.
      - Displays live Downloading -> Installing -> Complete status, then opens a fresh Cursor Window!
    """

    def __init__(self, on_done_open_cursor=None, parent=None):
        super().__init__(parent)
        self.on_done_open_cursor = on_done_open_cursor
        self.setWindowFlags(
            Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool | Qt.NoDropShadowWindowHint
        )
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(384, 64)

        self._pct = 0
        self._msg = "Starting download..."
        self._phase = 0.0
        self._finished = False

        self._anim_timer = QTimer(self)
        self._anim_timer.setInterval(20)
        self._anim_timer.timeout.connect(self._tick)

    def _tick(self):
        self._phase = (self._phase + 0.06) % math.tau
        if self.isVisible():
            self.update()

    def launch_from_rect(self, origin_rect: QRect):
        self._pct = 2
        self._msg = "Downloading patch..."
        self._finished = False

        scr = QApplication.screenAt(origin_rect.center()) or QApplication.primaryScreen()
        avail = scr.availableGeometry()

        start_x = origin_rect.center().x() - self.width() // 2
        start_y = origin_rect.center().y() - self.height() // 2
        end_x = avail.right() - self.width() - 22
        end_y = avail.bottom() - self.height() - 22

        start_geo = QRect(start_x, start_y, self.width(), self.height())
        end_geo = QRect(end_x, end_y, self.width(), self.height())

        self.setGeometry(start_geo)
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self._anim_timer.start()

        ag = QPropertyAnimation(self, b"geometry", self)
        ag.setDuration(520)
        ag.setStartValue(start_geo)
        ag.setEndValue(end_geo)
        ag.setEasingCurve(QEasingCurve.OutExpo)

        af = QPropertyAnimation(self, b"windowOpacity", self)
        af.setDuration(220)
        af.setStartValue(0.0)
        af.setEndValue(1.0)
        af.setEasingCurve(QEasingCurve.OutCubic)

        self._fly_anim = QParallelAnimationGroup(self)
        self._fly_anim.addAnimation(ag)
        self._fly_anim.addAnimation(af)
        self._fly_anim.start()

    def set_progress(self, pct: int, msg: str):
        self._pct = max(0, min(100, int(pct)))
        self._msg = msg
        self.update()

    def finish_and_reopen_cursor(self, ok: bool, msg: str):
        if self._finished:
            return
        self._finished = True
        self._pct = 100 if ok else self._pct
        self._msg = "Update installed! Launching fresh menu..." if ok else f"Failed: {msg}"
        self.update()

        QTimer.singleShot(850 if ok else 2000, self._fade_out_and_launch)

    def _fade_out_and_launch(self):
        self._anim_timer.stop()
        cur = self.geometry()
        end = QRect(cur.x(), cur.y() + 18, cur.width(), cur.height())

        ag = QPropertyAnimation(self, b"geometry", self)
        ag.setDuration(220)
        ag.setStartValue(cur)
        ag.setEndValue(end)
        ag.setEasingCurve(QEasingCurve.InCubic)

        af = QPropertyAnimation(self, b"windowOpacity", self)
        af.setDuration(200)
        af.setStartValue(1.0)
        af.setEndValue(0.0)

        self._out_anim = QParallelAnimationGroup(self)
        self._out_anim.addAnimation(ag)
        self._out_anim.addAnimation(af)

        def _done():
            self.hide()
            if callable(self.on_done_open_cursor):
                self.on_done_open_cursor()

        self._out_anim.finished.connect(_done)
        self._out_anim.start()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)

        w, h = float(self.width()), float(self.height())
        r = h * 0.5
        outer = QRectF(1.5, 1.5, w - 3.0, h - 3.0)
        pill = QPainterPath()
        pill.addRoundedRect(outer, r - 1.5, r - 1.5)

        # Animated shifting gradient border + subtle interior ambient tint
        shift = 0.5 + 0.5 * math.sin(self._phase)
        border_grad = QLinearGradient(outer.left(), outer.top(), outer.right(), outer.bottom())
        border_grad.setColorAt(0.0, QColor("#FFFF00"))
        border_grad.setColorAt(0.35 + 0.3 * shift, QColor("#A3E635"))
        border_grad.setColorAt(1.0, QColor("#00FF85"))

        # Deep Obsidian pill body
        p.save()
        p.setClipPath(pill)
        bg_grad = QLinearGradient(outer.left(), outer.top(), outer.right(), outer.bottom())
        bg_grad.setColorAt(0.0, QColor(12, 16, 10, 248))
        bg_grad.setColorAt(0.55, QColor(7, 8, 8, 250))
        bg_grad.setColorAt(1.0, QColor(6, 18, 13, 248))
        p.fillPath(pill, bg_grad)

        # Live gradient progress fill sweep across bottom of the pill
        fill_w = outer.width() * (self._pct / 100.0)
        if fill_w > 1.0:
            prog_grad = QLinearGradient(outer.left(), 0.0, outer.left() + max(fill_w, 40.0), 0.0)
            prog_grad.setColorAt(0.0, QColor(255, 255, 0, 38))
            prog_grad.setColorAt(0.6, QColor(163, 230, 53, 52))
            prog_grad.setColorAt(1.0, QColor(0, 255, 133, 70))
            p.fillRect(QRectF(outer.left(), outer.top(), fill_w, outer.height()), prog_grad)

            # Razor-bright bottom edge progress beam
            beam_grad = QLinearGradient(outer.left(), 0.0, outer.right(), 0.0)
            beam_grad.setColorAt(0.0, QColor("#FFFF00"))
            beam_grad.setColorAt(1.0, QColor("#00FF85"))
            p.fillRect(QRectF(outer.left(), outer.bottom() - 3.5, fill_w, 3.5), beam_grad)
        p.restore()

        # Crisp vibrant gradient border
        p.setPen(QPen(border_grad, 1.8))
        p.drawPath(pill)

        # Left animated spinning ring + icon
        cx, cy = 32.0, h * 0.5
        p.setPen(QPen(QColor(255, 255, 255, 36), 2.0))
        p.drawEllipse(QPointF(cx, cy), 12.0, 12.0)

        arc_pen = QPen(border_grad, 2.3, Qt.SolidLine, Qt.RoundCap)
        p.setPen(arc_pen)
        start_deg = int((self._phase / math.tau) * 360.0)
        span_deg = 360 if self._pct >= 100 else 130
        p.drawArc(QRectF(cx - 12.0, cy - 12.0, 24.0, 24.0), -start_deg * 16, span_deg * 16)

        # Center Status Text (Line 1: Status Message | Line 2: Brand tag)
        f_main = QFont("Segoe UI Variable Display", 10, QFont.Bold)
        f_main.setHintingPreference(QFont.PreferNoHinting)
        p.setFont(f_main)
        p.setPen(QColor("#FFFFFF"))
        elided = QFontMetrics(f_main).elidedText(self._msg, Qt.ElideRight, int(w - 130))
        p.drawText(QRectF(56.0, 11.0, w - 124.0, 22.0), Qt.AlignLeft | Qt.AlignVCenter, elided)

        f_sub = QFont("Segoe UI Variable Text", 8, QFont.DemiBold)
        p.setFont(f_sub)
        p.setPen(QColor("#A3A3A3"))
        sub_txt = "THE SUPERMOUSE  ·  PATCHER"
        p.drawText(QRectF(56.0, 32.0, w - 124.0, 18.0), Qt.AlignLeft | Qt.AlignVCenter, sub_txt)

        # Right Percentage Number
        f_pct = QFont("Segoe UI Variable Display", 12, QFont.ExtraBold)
        p.setFont(f_pct)
        p.setPen(QColor("#A3E635"))
        p.drawText(QRectF(w - 68.0, 0.0, 50.0, h), Qt.AlignRight | Qt.AlignVCenter, f"{self._pct}%")

        p.end()


class _DownloadIconButton(QPushButton):
    """Crisp circular solid-white Download Icon button (turns Cyber-Lime on hover)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(32, 32)
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip("Download this update")
        self._hovered = False

    def enterEvent(self, e):
        self._hovered = True
        self.update()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._hovered = False
        self.update()
        super().leaveEvent(e)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        r = QRectF(0.5, 0.5, self.width() - 1.0, self.height() - 1.0)

        if not self.isEnabled():
            bg = QColor(255, 255, 255, 36)
            icon_col = "#666666"
        elif self._hovered:
            bg = QColor("#A3E635")
            icon_col = "#050608"
        else:
            bg = QColor("#FFFFFF")
            icon_col = "#050608"

        p.setPen(Qt.NoPen)
        p.setBrush(bg)
        p.drawEllipse(r)

        svg = _DOWNLOAD_SVG.replace("{col}", icon_col).encode("utf-8")
        QSvgRenderer(QByteArray(svg)).render(p, QRectF(8.0, 8.0, 16.0, 16.0))
        p.end()


class _AccountingUpdateRow(QWidget):
    """Boxless accounting row: S.No | 75% Particulars (Headline, big sharp Sub-text, bottom Date) | 15% Gap | MB + Icon."""

    def __init__(self, index_num: int, item: dict, on_download, installing: bool = False, parent=None):
        super().__init__(parent)
        self.item = item
        self.setStyleSheet("background: transparent;")

        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 15, 0, 15)
        lay.setSpacing(0)

        # S.NO column (true neutral grey, clean Segoe UI Variable)
        lbl_sno = QLabel(f"{index_num:02d}", self)
        lbl_sno.setFixedWidth(36)
        lbl_sno.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        lbl_sno.setStyleSheet(
            "color: #8A8A8A; font-size: 13.5px; font-weight: 700; padding-top: 2px; background: transparent; "
            "font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif;"
        )
        lay.addWidget(lbl_sno, alignment=Qt.AlignTop)

        # LEFT 75%: Headline + Large Sharp Neutral Sub-text + Date at bottom
        left_wrap = QWidget(self)
        left_wrap.setStyleSheet("background: transparent;")
        left = QVBoxLayout(left_wrap)
        left.setContentsMargins(0, 0, 0, 0)
        left.setSpacing(6)

        headline = str(item.get("headline") or f"Update v{item.get('version', '')}")
        lbl_head = QLabel(headline, left_wrap)
        lbl_head.setWordWrap(True)
        lbl_head.setStyleSheet(
            "color: #FFFFFF; font-size: 15.5px; font-weight: 800; background: transparent; "
            "font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif;"
        )
        left.addWidget(lbl_head)

        sub = str(item.get("subtext") or "").strip()
        if sub:
            lbl_sub = QLabel(sub, left_wrap)
            lbl_sub.setWordWrap(True)
            lbl_sub.setStyleSheet(
                "color: #CFCFCF; font-size: 13.5px; font-weight: 500; background: transparent; "
                "font-family: 'Segoe UI Variable Text', 'Segoe UI', sans-serif;"
            )
            left.addWidget(lbl_sub)

        dt = str(item.get("date") or "").strip()
        ver = str(item.get("version") or "").strip()
        date_line = f"{dt}  ·  v{ver}" if (dt and ver) else (dt or f"v{ver}")
        lbl_date = QLabel(date_line, left_wrap)
        lbl_date.setStyleSheet(
            "color: #858585; font-size: 11.5px; font-weight: 600; padding-top: 2px; background: transparent; "
            "font-family: 'Segoe UI Variable Text', 'Segoe UI', sans-serif;"
        )
        left.addWidget(lbl_date)

        lay.addWidget(left_wrap, stretch=75)

        # MIDDLE 15%: Pure empty breathing space
        lay.addStretch(15)

        # RIGHT SIDE: Numeric MB size (Segoe UI Variable Display — zero Roboto/monospace) + White Download Icon
        right_wrap = QWidget(self)
        right_wrap.setStyleSheet("background: transparent;")
        right = QHBoxLayout(right_wrap)
        right.setContentsMargins(0, 0, 0, 0)
        right.setSpacing(14)

        sz_num = float(item.get("size_mb") or 0.0)
        lbl_sz = QLabel(f"{sz_num:.1f}" if sz_num % 1 != 0 else f"{sz_num:g}", right_wrap)
        lbl_sz.setFixedWidth(48)
        lbl_sz.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        lbl_sz.setStyleSheet(
            "color: #FFFFFF; font-size: 14px; font-weight: 700; background: transparent; "
            "font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif;"
        )
        right.addWidget(lbl_sz, alignment=Qt.AlignVCenter)

        btn_dl = _DownloadIconButton(right_wrap)
        btn_dl.setEnabled(not installing)
        btn_dl.clicked.connect(lambda: on_download(item))
        right.addWidget(btn_dl, alignment=Qt.AlignVCenter)

        lay.addWidget(right_wrap, alignment=Qt.AlignVCenter)


class SuperUpdateWindow(QWidget):
    """Boxless Accounting-Style Update Ledger matched 1:1 to Cursor Window header."""

    def __init__(self, checker: PatchChecker | None = None, on_back=None, parent=None):
        super().__init__(parent)
        self.checker = checker or get_patch_checker()
        self.on_back = on_back

        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(624, 434)

        apply_window_identity(self, "TheSuperMouse - Update")

        self._dragging = False
        self._is_animating = False
        self._anim_gen = 0
        self._drag_offset = QPoint()
        self._pill = _PatchProgressPillWindow(on_done_open_cursor=self._open_fresh_cursor_window)

        base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        base_assets = os.path.join(base_dir, "thesupermouse", "assets")
        logo_fp = os.path.join(base_assets, "supermouse_app_logo_cropped.png")
        if not os.path.exists(logo_fp):
            logo_fp = os.path.join(base_assets, "supermouse_app_logo_trans.png")
        raw_logo = QImage(logo_fp) if os.path.exists(logo_fp) else None
        if raw_logo and not raw_logo.isNull():
            ldpr = native_dpr(self)
            li = raw_logo.scaledToHeight(max(20, int(round(20 * ldpr))), Qt.SmoothTransformation)
            self.logo_pix = QPixmap.fromImage(li)
            self.logo_pix.setDevicePixelRatio(ldpr)
        else:
            self.logo_pix = None

        self._build_ui()
        self.checker.status_changed.connect(self._apply_status)
        self.checker.download_progress.connect(self._on_progress)
        self.checker.update_finished.connect(self._on_finished)
        self._apply_status(self.checker.get_status())

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # 1. Exact Cursor Window Header Bar (52px)
        header = QWidget(self)
        header.setFixedHeight(52)
        header.setCursor(Qt.OpenHandCursor)
        hdr = QHBoxLayout(header)
        hdr.setContentsMargins(16, 0, 14, 0)
        hdr.setSpacing(2)
        hdr.addStretch(1)

        self.btn_back = CleanBackButton("Back to Quick Menu", box_size=30, icon_size=15, parent=header)
        self.btn_back.clicked.connect(self._go_back)
        hdr.addWidget(self.btn_back, alignment=Qt.AlignVCenter)

        self.btn_close = CleanCloseButton("Close Update Window", box_size=30, icon_size=15, parent=header)
        self.btn_close.clicked.connect(self.close_with_pull_animation)
        hdr.addWidget(self.btn_close, alignment=Qt.AlignVCenter)
        root.addWidget(header)

        div_top = QFrame(self)
        div_top.setFixedHeight(1)
        div_top.setStyleSheet("background-color: rgba(255, 255, 255, 0.08); margin: 0px 24px;")
        root.addWidget(div_top)

        # 2. Accounting Ledger Body
        body = QWidget(self)
        bl = QVBoxLayout(body)
        bl.setContentsMargins(24, 14, 24, 18)
        bl.setSpacing(0)

        # Accounting Column Header Row: S.NO | PARTICULARS (75%) | 15% Gap | MB (+ icon spacer)
        col_hdr_widget = QWidget(body)
        col_hdr_widget.setStyleSheet("background: transparent;")
        ch = QHBoxLayout(col_hdr_widget)
        ch.setContentsMargins(0, 0, 0, 8)
        ch.setSpacing(0)

        lbl_h_sno = QLabel("S.NO", col_hdr_widget)
        lbl_h_sno.setFixedWidth(36)
        lbl_h_sno.setStyleSheet(
            "color: #808080; font-size: 9.5px; font-weight: 800; letter-spacing: 1.1px; "
            "background: transparent; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        ch.addWidget(lbl_h_sno)

        lbl_h_left = QLabel("PARTICULARS", col_hdr_widget)
        lbl_h_left.setStyleSheet(
            "color: #808080; font-size: 9.5px; font-weight: 800; letter-spacing: 1.1px; "
            "background: transparent; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        ch.addWidget(lbl_h_left, stretch=75)
        ch.addStretch(15)

        right_hdr = QWidget(col_hdr_widget)
        right_hdr.setStyleSheet("background: transparent;")
        rh = QHBoxLayout(right_hdr)
        rh.setContentsMargins(0, 0, 0, 0)
        rh.setSpacing(14)

        lbl_h_mb = QLabel("MB", right_hdr)
        lbl_h_mb.setFixedWidth(48)
        lbl_h_mb.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        lbl_h_mb.setStyleSheet(
            "color: #808080; font-size: 9.5px; font-weight: 800; letter-spacing: 1.1px; "
            "background: transparent; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        rh.addWidget(lbl_h_mb)

        icon_col_spacer = QWidget(right_hdr)
        icon_col_spacer.setFixedWidth(32)
        rh.addWidget(icon_col_spacer)

        ch.addWidget(right_hdr)
        self.col_hdr_widget = col_hdr_widget
        bl.addWidget(col_hdr_widget)

        self.hr_header = QFrame(body)
        self.hr_header.setFixedHeight(1)
        self.hr_header.setStyleSheet("background-color: rgba(255, 255, 255, 0.14);")
        bl.addWidget(self.hr_header)

        # Scrollable Boxless Update Rows
        self.scroll = QScrollArea(body)
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll.setStyleSheet(
            "QScrollArea { background: transparent; border: none; }"
            "QScrollBar:vertical { width: 4px; background: transparent; margin: 2px 0; }"
            "QScrollBar::handle:vertical { background: rgba(255, 255, 255, 0.18); border-radius: 2px; }"
            "QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }"
        )
        self.list_container = QWidget()
        self.list_container.setStyleSheet("background: transparent;")
        self.list_layout = QVBoxLayout(self.list_container)
        self.list_layout.setContentsMargins(0, 0, 0, 0)
        self.list_layout.setSpacing(0)
        self.scroll.setWidget(self.list_container)
        bl.addWidget(self.scroll, stretch=1)

        bl.addSpacing(8)

        # Accounting Subtotal HR Line
        hr_sub = QFrame(body)
        hr_sub.setFixedHeight(1)
        hr_sub.setStyleSheet("background-color: rgba(255, 255, 255, 0.20);")
        bl.addWidget(hr_sub)

        bl.addSpacing(12)

        # Bottom Subtotal Row (ZERO 'TOTAL (2)' text!): Left = White 'Refresh' | Right = Total MB + Green 'Download All'
        sub_row = QHBoxLayout()
        sub_row.setContentsMargins(0, 0, 0, 0)
        sub_row.setSpacing(14)

        self.btn_refresh = QPushButton("Refresh", body)
        self.btn_refresh.setCursor(Qt.PointingHandCursor)
        self.btn_refresh.setFixedHeight(34)
        self.btn_refresh.setStyleSheet(
            "QPushButton { background: #FFFFFF; color: #050608; border: none; border-radius: 17px; "
            "font-size: 12px; font-weight: 800; padding: 0px 18px; "
            "font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif; }"
            "QPushButton:hover { background: #E5E5E5; color: #050608; }"
            "QPushButton:pressed { background: #CCCCCC; color: #050608; }"
            "QPushButton:disabled { background: rgba(255, 255, 255, 0.20); color: #666666; }"
        )
        self.btn_refresh.clicked.connect(lambda: self.checker.check_now(mark_daily_slot=False))
        sub_row.addWidget(self.btn_refresh, alignment=Qt.AlignVCenter)

        sub_row.addStretch(1)

        self.lbl_total_mb = QLabel("0 MB", body)
        self.lbl_total_mb.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.lbl_total_mb.setStyleSheet(
            "color: #FFFFFF; font-size: 14.5px; font-weight: 800; background: transparent; padding-right: 4px; "
            "font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif;"
        )
        sub_row.addWidget(self.lbl_total_mb, alignment=Qt.AlignVCenter)

        self.btn_download_all = QPushButton("Download All", body)
        self.btn_download_all.setCursor(Qt.PointingHandCursor)
        self.btn_download_all.setFixedHeight(34)
        self.btn_download_all.clicked.connect(self._trigger_download_all)
        sub_row.addWidget(self.btn_download_all, alignment=Qt.AlignVCenter)

        bl.addLayout(sub_row)
        root.addWidget(body, stretch=1)

    def _close_all_app_windows_and_launch_pill(self):
        origin = self.geometry()
        for w in QApplication.topLevelWidgets():
            if w is self._pill:
                continue
            try:
                if w.isVisible():
                    w.hide()
            except Exception:
                pass
        self._pill.launch_from_rect(origin)

    def _trigger_download_single(self, item: dict):
        self._close_all_app_windows_and_launch_pill()
        self.checker.install_single_update(item)

    def _trigger_download_all(self):
        if not self.checker.get_status().get("has_update"):
            return
        self._close_all_app_windows_and_launch_pill()
        self.checker.install_all_updates()

    def _open_fresh_cursor_window(self):
        if callable(self.on_back):
            self.on_back()

    def _clear_list(self):
        while self.list_layout.count():
            child = self.list_layout.takeAt(0)
            w = child.widget()
            if w is not None:
                w.deleteLater()

    def _apply_status(self, st: dict):
        has_upd = bool(st.get("has_update"))
        updates = list(st.get("updates") or [])
        checking = bool(st.get("checking"))
        installing = bool(st.get("installing"))
        total_mb = float(st.get("total_size_mb") or 0.0)

        self._clear_list()

        if has_upd and updates:
            self.col_hdr_widget.show()
            self.hr_header.show()

            for i, item in enumerate(updates):
                row = _AccountingUpdateRow(
                    index_num=i + 1,
                    item=item,
                    on_download=self._trigger_download_single,
                    installing=installing,
                    parent=self.list_container,
                )
                self.list_layout.addWidget(row)
                if i < len(updates) - 1:
                    sep = QFrame(self.list_container)
                    sep.setFixedHeight(1)
                    sep.setStyleSheet("background-color: rgba(255, 255, 255, 0.07);")
                    self.list_layout.addWidget(sep)
            self.list_layout.addStretch(1)

            self.lbl_total_mb.setText(f"{total_mb:.1f} MB" if total_mb % 1 != 0 else f"{total_mb:g} MB")
        else:
            self.col_hdr_widget.hide()
            self.hr_header.hide()

            empty_wrap = QWidget(self.list_container)
            empty_wrap.setStyleSheet("background: transparent;")
            el = QVBoxLayout(empty_wrap)
            el.setContentsMargins(0, 82, 0, 20)
            el.setSpacing(8)

            lbl_msg = QLabel("You are uptodate no updates there pending.", empty_wrap)
            lbl_msg.setWordWrap(True)
            lbl_msg.setStyleSheet(
                "color: #FFFFFF; font-size: 16.5px; font-weight: 700; background: transparent; "
                "font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif;"
            )
            el.addWidget(lbl_msg)

            last_chk = st.get("last_checked") or "Auto-checks daily at 7:00 PM IST"
            lbl_sub = QLabel(last_chk, empty_wrap)
            lbl_sub.setStyleSheet(
                "color: #8A8A8A; font-size: 12.5px; font-weight: 500; background: transparent; "
                "font-family: 'Segoe UI Variable Text', 'Segoe UI', sans-serif;"
            )
            el.addWidget(lbl_sub)
            self.list_layout.addWidget(empty_wrap)
            self.list_layout.addStretch(1)

            self.lbl_total_mb.setText("0 MB")

        self.btn_refresh.setText("Refreshing..." if checking else "Refresh")
        self.btn_refresh.setEnabled(not checking and not installing)

        # Always show Download All — Vibrant Green when updates exist, cleanly disabled when 0 updates!
        self.btn_download_all.show()
        if has_upd and not installing:
            self.btn_download_all.setText("Download All")
            self.btn_download_all.setEnabled(True)
            self.btn_download_all.setStyleSheet(
                "QPushButton { background: #A3E635; color: #050608; border: none; border-radius: 17px; "
                "font-size: 12px; font-weight: 800; padding: 0px 20px; "
                "font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif; }"
                "QPushButton:hover { background: #BEF264; color: #050608; }"
                "QPushButton:pressed { background: #84CC16; color: #050608; }"
            )
        else:
            self.btn_download_all.setText("Installing..." if installing else "Download All")
            self.btn_download_all.setEnabled(False)
            self.btn_download_all.setStyleSheet(
                "QPushButton { background: rgba(255, 255, 255, 0.08); color: #666666; border: none; "
                "border-radius: 17px; font-size: 12px; font-weight: 800; padding: 0px 20px; "
                "font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif; }"
            )

        self.update()

    def _on_progress(self, pct: int, msg: str):
        if self._pill.isVisible():
            self._pill.set_progress(pct, msg)

    def _on_finished(self, ok: bool, msg: str):
        if self._pill.isVisible():
            self._pill.finish_and_reopen_cursor(ok, msg)

    def _go_back(self):
        self.switch_out_asmr_animation(on_finished=self.on_back)

    def open_asmr_switch(self):
        self._anim_gen += 1
        gen = self._anim_gen
        self._is_animating = True
        self._apply_status(self.checker.get_status())
        # Automatically trigger a fresh live check whenever update window opens
        try:
            self.checker.check_now(mark_daily_slot=False)
        except Exception:
            pass

        scr = QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()
        avail = scr.availableGeometry()
        tx = avail.center().x() - self.width() // 2
        ty = avail.center().y() - self.height() // 2

        start_rect = QRect(tx, ty + 18, self.width(), self.height())
        end_rect = QRect(tx, ty, self.width(), self.height())
        self.setGeometry(start_rect)
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.activateWindow()

        ag = QPropertyAnimation(self, b"geometry", self)
        ag.setDuration(220)
        ag.setStartValue(start_rect)
        ag.setEndValue(end_rect)
        ag.setEasingCurve(QEasingCurve.OutCubic)

        af = QPropertyAnimation(self, b"windowOpacity", self)
        af.setDuration(200)
        af.setStartValue(0.0)
        af.setEndValue(1.0)
        af.setEasingCurve(QEasingCurve.OutCubic)

        self.anim_in = QParallelAnimationGroup(self)
        self.anim_in.addAnimation(ag)
        self.anim_in.addAnimation(af)

        def _done():
            if self._anim_gen == gen:
                self._is_animating = False

        self.anim_in.finished.connect(_done)
        self.anim_in.start()

    def switch_out_asmr_animation(self, on_finished=None):
        self._anim_gen += 1
        gen = self._anim_gen
        self._is_animating = True
        cur = self.geometry()
        end = QRect(cur.x(), cur.y() + 14, cur.width(), cur.height())

        ag = QPropertyAnimation(self, b"geometry", self)
        ag.setDuration(150)
        ag.setStartValue(cur)
        ag.setEndValue(end)
        ag.setEasingCurve(QEasingCurve.InCubic)

        af = QPropertyAnimation(self, b"windowOpacity", self)
        af.setDuration(140)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)

        self.anim_out = QParallelAnimationGroup(self)
        self.anim_out.addAnimation(ag)
        self.anim_out.addAnimation(af)

        def _done():
            if self._anim_gen != gen:
                return
            self._is_animating = False
            self.hide()
            if callable(on_finished):
                on_finished()

        self.anim_out.finished.connect(_done)
        self.anim_out.start()

    def close_with_pull_animation(self):
        self.switch_out_asmr_animation(on_finished=None)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton and e.position().y() <= 52.0:
            self._dragging = True
            self._drag_offset = e.globalPosition().toPoint() - self.pos()
            self.setCursor(Qt.ClosedHandCursor)
            e.accept()
            return
        elif e.button() == Qt.RightButton:
            self.close_with_pull_animation()
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        if self._dragging:
            self.move(e.globalPosition().toPoint() - self._drag_offset)
            e.accept()
            return
        super().mouseMoveEvent(e)

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self._dragging:
            self._dragging = False
            self.setCursor(Qt.ArrowCursor)
            e.accept()
            return
        super().mouseReleaseEvent(e)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.close_with_pull_animation()
            e.accept()
        else:
            super().keyPressEvent(e)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        w, h = float(self.width()), float(self.height())
        rect = QRectF(0.6, 0.6, w - 1.2, h - 1.2)
        card = QPainterPath()
        card.addRoundedRect(rect, 14.0, 14.0)

        p.fillPath(card, QColor(4, 4, 5, 253))
        p.setPen(QPen(QColor(255, 255, 255, 26), 1.0))
        p.drawPath(card)

        # Exact Cursor Window ('THE SUPERMOUSE') vector brand typography:
        # 'THE' white + 'UPDATE' with #FFFF00 -> #00FF85 horizontal gradient (11.4pt Display Bold)
        bx = 16.0
        by_c = 26.0
        if self.logo_pix and not self.logo_pix.isNull():
            ldpr = max(1.0, float(self.logo_pix.devicePixelRatio() or 1.0))
            lw = self.logo_pix.width() / ldpr
            lh = self.logo_pix.height() / ldpr
            p.drawPixmap(int(round(bx)), int(round(by_c - lh * 0.5)), self.logo_pix)
            bx += lw + 8.0

        f_logo = QFont("Segoe UI Variable")
        f_logo.setStyleName("Display Bold")
        f_logo.setPointSizeF(11.4)
        f_logo.setLetterSpacing(QFont.AbsoluteSpacing, 0.35)
        f_logo.setHintingPreference(QFont.PreferNoHinting)

        probe = QPainterPath()
        probe.addText(0.0, 0.0, f_logo, "THE UPDATE")
        br = probe.boundingRect()
        baseline_y = by_c - (br.top() + br.height() * 0.5)

        p1 = QPainterPath()
        p1.addText(bx, baseline_y, f_logo, "THE")
        p.fillPath(p1, QColor("#FFFFFF"))

        w1 = p1.boundingRect().width()
        ux = bx + w1 + 5.5
        p2 = QPainterPath()
        p2.addText(ux, baseline_y, f_logo, "UPDATE")
        b2 = p2.boundingRect()
        g_upd = QLinearGradient(b2.left(), 0.0, b2.right(), 0.0)
        g_upd.setColorAt(0.0, QColor("#FFFF00"))
        g_upd.setColorAt(1.0, QColor("#00FF85"))
        p.fillPath(p2, g_upd)

        p.end()
