from .common import *
# -*- coding: utf-8 -*-
import os
import sys
import time
import json
import random
import re
import socket
import hashlib
import subprocess
import threading
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from PySide6.QtCore import (
    QEasingCurve,
    QObject,
    QParallelAnimationGroup,
    QPoint,
    QPropertyAnimation,
    QRect,
    QRectF,
    QSize,
    Qt,
    QTimer,
    QVariantAnimation,
    Signal,
)
from PySide6.QtGui import (
    QBrush,
    QIcon,
    QImage,
    QColor,
    QCursor,
    QFont,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
    QTransform,
    QLinearGradient,
)
from PySide6.QtWidgets import (
    QApplication,
    QDialog,
    QFileDialog,
    QFrame,
    QGraphicsOpacityEffect,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMenu,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from ui_theme import (
    ACCENT_LIME,
    TEXT_MUTED,
    TEXT_PRIMARY,
    TEXT_SECONDARY,
    native_dpr,
    CleanBackButton,
    CleanCloseButton,
    CleanHeaderIconButton,
    render_common_icon,
    COMMON_ICONS,
    format_count_label,
)

from .common import (
    BASE_DIR, DEFAULT_SAVE_DIR, generate_8char_device_id, compute_linked_12_code,
    format_12_code, _load_or_create_config, _save_config, _load_app_logo_pix,
    _draw_vector_brand, get_avatar_pixmap, AVATARS_DIR
)
from .engine import SuperShareEngine


class QueueRequestModalDialog(QWidget):
    """Obsidian modal dialog asking whether to queue an out-of-signal vibe request."""
    def __init__(self, target_id: str, on_confirm=None, parent=None):
        super().__init__(parent, Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.SubWindow)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.on_confirm = on_confirm
        self.target_id = target_id
        self._build_ui()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)

        card = QFrame(self)
        card.setStyleSheet(
            "QFrame { background-color: #0A0B0E; border: 1.5px solid rgba(142, 255, 0, 0.4); border-radius: 12px; }"
        )
        cl = QVBoxLayout(card)
        cl.setContentsMargins(16, 16, 16, 16)
        cl.setSpacing(10)

        t_lbl = QLabel("Device Out of Signal", card)
        t_lbl.setStyleSheet("color: #FFFFFF; font-size: 13.5px; font-weight: 800; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;")
        cl.addWidget(t_lbl)

        msg = QLabel(
            f"Device ID [{self.target_id}] is not currently in your signal range.\n\n"
            "Do you want to queue your vibe request?\n"
            "It will auto-send the moment this device comes into signal range.",
            card
        )
        msg.setWordWrap(True)
        msg.setStyleSheet("color: #D4D4D8; font-size: 11px; font-weight: 500; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; line-height: 1.4;")
        cl.addWidget(msg)

        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)
        btn_row.addStretch(1)

        btn_cancel = QPushButton("Cancel", card)
        btn_cancel.setFixedHeight(28)
        btn_cancel.setCursor(Qt.PointingHandCursor)
        btn_cancel.setStyleSheet(
            "QPushButton { background: rgba(255, 255, 255, 0.06); color: #A1A1AA; border: 1px solid rgba(255, 255, 255, 0.14); border-radius: 6px; padding: 4px 14px; font-size: 11px; font-weight: 700; font-family: 'Segoe UI Variable', sans-serif; } "
            "QPushButton:hover { color: #FFFFFF; background: rgba(255, 255, 255, 0.12); }"
        )
        btn_cancel.clicked.connect(self.close)
        btn_row.addWidget(btn_cancel)

        btn_queue = QPushButton("Queue Request", card)
        btn_queue.setFixedHeight(28)
        btn_queue.setCursor(Qt.PointingHandCursor)
        btn_queue.setStyleSheet(
            "QPushButton { background: #8EFF00; color: #040405; border: none; border-radius: 6px; padding: 4px 16px; font-size: 11px; font-weight: 800; font-family: 'Segoe UI Variable', sans-serif; } "
            "QPushButton:hover { background: #A3FF2E; }"
        )
        def _do_confirm():
            self.close()
            if callable(self.on_confirm):
                self.on_confirm()
        btn_queue.clicked.connect(_do_confirm)
        btn_row.addWidget(btn_queue)

        cl.addLayout(btn_row)
        root.addWidget(card)


# ──────────────────────────────────────────────────────────────────────────────
#  WINDOW 1: DEVICE HUB (Unified Design Language matching Super Snap & Pin & Quick Menu)
# ──────────────────────────────────────────────────────────────────────────────

class _DeviceHubBrandTitle(QWidget):
    """Vector-crisp brand title: Logo (20px) + 'THE' (White) + 'DEVICE HUB' (#FFFF00->#00FF85 gradient)."""
    def __init__(self, logo_pix=None, parent=None):
        super().__init__(parent)
        self.logo_pix = logo_pix
        self.setFixedHeight(30)
        self.setFixedWidth(230)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        bx = 0.0
        by_c = float(self.height()) * 0.5
        if self.logo_pix and not self.logo_pix.isNull():
            ldpr = max(1.0, float(self.logo_pix.devicePixelRatio() or 1.0))
            lw = self.logo_pix.width() / ldpr
            lh = self.logo_pix.height() / ldpr
            p.drawPixmap(int(round(bx)), int(round(by_c - lh * 0.5)), self.logo_pix)
            bx += lw + 8.0

        f_logo = QFont("Segoe UI Variable")
        f_logo.setStyleName("Display Bold")
        f_logo.setPointSizeF(11.4)
        f_logo.setLetterSpacing(QFont.AbsoluteSpacing, 0.35)
        f_logo.setHintingPreference(QFont.PreferNoHinting)

        probe = QPainterPath()
        probe.addText(0.0, 0.0, f_logo, "THE DEVICE HUB")
        br = probe.boundingRect()
        baseline_y = by_c - (br.top() + br.height() * 0.5)

        p1 = QPainterPath()
        p1.addText(bx, baseline_y, f_logo, "THE")
        p.fillPath(p1, QColor("#FFFFFF"))

        w1 = p1.boundingRect().width()
        smx = bx + w1 + 5.5

        p2 = QPainterPath()
        p2.addText(smx, baseline_y, f_logo, "DEVICE HUB")
        b2 = p2.boundingRect()
        g_sm = QLinearGradient(b2.left(), 0.0, b2.right(), 0.0)
        g_sm.setColorAt(0.0, QColor("#FFFF00"))
        g_sm.setColorAt(1.0, QColor("#00FF85"))
        p.fillPath(p2, g_sm)
        p.end()


_SVG_KILL = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M18 6L6 18M6 6l12 12"/></svg>'
_SVG_MORE_FILES = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M12 5v14m-7-7h14"/></svg>'
_SVG_INFINITY = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M18.178 8c5.096 0 5.096 8 0 8c-5.095 0-7.262-8-12.356-8c-5.096 0-5.096 8 0 8c5.094 0 7.261-8 12.356-8z"/></svg>'
_SVG_SESSION_CLOSE = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" fill="none" stroke="{col}" stroke-width="2.0"/><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0" d="m15 9l-6 6m0-6l6 6"/></svg>'
_SVG_SHIELD_TRUST = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0" d="M12 22s8-4 8-10V5l-8-3l-8 3v7c0 6 8 10 8 10z"/><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0" d="m9 12l2 2l4-4"/></svg>'
_SVG_TRASH_CLEAN = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0" d="M3 6h18m-2 0v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6m3 0V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2m-6 5v6m4-6v6"/></svg>'


class PeerCardWidget(QWidget):
    """
    Peer card with clean open-canvas row, zero box container, and bottom HR line.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(64)
        self.setAttribute(Qt.WA_StyledBackground, True)
        self._progress = 0.0
        self.setStyleSheet(
            "PeerCardWidget { background: transparent; border: none; border-bottom: 1px solid rgba(255, 255, 255, 0.08); } "
            "PeerCardWidget:hover { background: rgba(255, 255, 255, 0.03); }"
        )

    def set_progress(self, val: float):
        try:
            self._progress = max(0.0, min(100.0, float(val)))
            self.update()
        except Exception:
            pass

    def paintEvent(self, event):
        super().paintEvent(event)
        if self._progress > 0.0:
            p = QPainter(self)
            p.setRenderHint(QPainter.Antialiasing, True)
            w = float(self.width())
            h = float(self.height())
            bar_w = max(4.0, (w - 2.0) * (self._progress / 100.0))

            grad = QLinearGradient(1.0, h - 3.0, bar_w, h - 3.0)
            grad.setColorAt(0.0, QColor("#FFFF00"))
            grad.setColorAt(0.4, QColor("#a3e635"))
            grad.setColorAt(1.0, QColor("#00FF85"))

            p.setPen(Qt.NoPen)
            p.setBrush(QBrush(grad))

            path = QPainterPath()
            path.addRoundedRect(QRectF(1.0, h - 3.5, bar_w, 3.0), 1.5, 1.5)
            p.fillPath(path, p.brush())
            p.end()


class BeamActionButton(QPushButton):
    """
    Dynamic stateful button:
      - 'Share' (Trusted peer: solid cyber lime)
      - 'Send' (Active 5-minute session: solid cyber lime)
      - 'Let's Vibe' (Non-trusted peer: dark glass, requests session)
      - '[pct]%' (Beaming transfer in progress: animated loading progress bar)
    """
    def __init__(self, mode: str = "VIBE", is_beaming: bool = False, progress: float = 0.0, parent=None):
        super().__init__(parent)
        self.mode = mode.upper()  # "SHARE", "SEND", "VIBE"
        self.is_beaming = is_beaming
        self.progress = max(0.0, min(100.0, float(progress)))
        self.setCursor(Qt.PointingHandCursor)
        self._update_appearance()

    def set_beaming_progress(self, progress: float):
        try:
            self.is_beaming = True
            self.progress = max(0.0, min(100.0, float(progress)))
            self._update_appearance()
        except Exception:
            pass

    def set_mode(self, mode: str):
        try:
            self.mode = mode.upper()
            self.is_beaming = False
            self._update_appearance()
        except Exception:
            pass

    def reset_state(self):
        try:
            self.is_beaming = False
            self.progress = 0.0
            self._update_appearance()
        except Exception:
            pass

    def _update_appearance(self):
        try:
            if not self.isVisible() and not self.parent():
                return
        except Exception:
            return
        if self.is_beaming:
            pct = int(self.progress)
            self.setText(f"{pct}%")
            self.setFixedSize(68, 28)
            pct_stop = max(0.01, min(0.99, self.progress / 100.0))
            pct_next = min(1.0, pct_stop + 0.001)
            self.setStyleSheet(
                f"QPushButton {{ "
                f"  background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #a3e635, stop:{pct_stop:.3f} #a3e635, stop:{pct_next:.3f} rgba(255, 255, 255, 0.08), stop:1 rgba(255, 255, 255, 0.08)); "
                f"  color: #040405; "
                f"  border: 1px solid rgba(163, 230, 53, 0.6); "
                f"  border-radius: 8px; "
                f"  font-size: 11px; "
                f"  font-weight: 800; "
                f"  font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif; "
                f"}}"
            )
        elif self.mode == "SHARE":
            self.setText("Share")
            self.setFixedSize(64, 28)
            self.setStyleSheet(
                "QPushButton { "
                "  background: #a3e635; "
                "  color: #040405; "
                "  border: none; "
                "  border-radius: 8px; "
                "  font-size: 11.5px; "
                "  font-weight: 800; "
                "  font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif; "
                "} "
                "QPushButton:hover { background: #bbf45c; } "
                "QPushButton:pressed { background: #8cd622; }"
            )
        elif self.mode == "SEND":
            self.setText("Send")
            self.setFixedSize(64, 28)
            self.setStyleSheet(
                "QPushButton { "
                "  background: #a3e635; "
                "  color: #040405; "
                "  border: none; "
                "  border-radius: 8px; "
                "  font-size: 11.5px; "
                "  font-weight: 800; "
                "  font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif; "
                "} "
                "QPushButton:hover { background: #bbf45c; } "
                "QPushButton:pressed { background: #8cd622; }"
            )
        else:
            # Non-trusted peer: Let's Vibe
            self.setText("Let's Vibe")
            self.setFixedSize(76, 28)
            self.setStyleSheet(
                "QPushButton { "
                "  background: rgba(255, 255, 255, 0.08); "
                "  color: #FFFFFF; "
                "  border: 1px solid rgba(255, 255, 255, 0.16); "
                "  border-radius: 8px; "
                "  font-size: 10.5px; "
                "  font-weight: 700; "
                "  font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif; "
                "} "
                "QPushButton:hover { background: #bbf45c; color: #040405; border: none; font-weight: 800; } "
                "QPushButton:pressed { background: #8cd622; color: #040405; border: none; }"
            )


class PeerActionsFlyout(QWidget):
    """
    Polished Obsidian Dropdown Menu matching Android Mobile & Windows 11 style:
      - Opening & Closing fade + vertical slide animations.
      - 26x26 rounded icon badges with tint matching action states.
      - Exactly matching action set: Kill Beam, More to Go, Continuous Sharing, Close Session, Trust, Forget.
    """
    def __init__(self, peer: dict, engine: SuperShareEngine, device_window=None, parent=None):
        super().__init__(parent, Qt.Popup | Qt.FramelessWindowHint | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_DeleteOnClose, True)
        self.peer = peer
        self.engine = engine
        self.device_window = device_window
        self._closing = False

        pid = peer.get("id", "")
        pname = peer.get("name", "Device")
        is_trusted = bool(peer.get("is_trusted"))

        self.setFixedWidth(208)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(6, 6, 6, 6)
        lay.setSpacing(2)

        def _add_action_row(svg_tpl, icon_color_hex, label_text, text_color_hex, on_click):
            row = QWidget(self)
            row.setFixedHeight(36)
            row.setCursor(Qt.PointingHandCursor)
            row.setAttribute(Qt.WA_StyledBackground, True)
            is_dest = (text_color_hex == "#EF4444")
            hover_bg = "rgba(239, 68, 68, 0.14)" if is_dest else "rgba(255, 255, 255, 0.08)"
            row.setStyleSheet(
                f"QWidget {{ background: transparent; border-radius: 8px; }} "
                f"QWidget:hover {{ background: {hover_bg}; }}"
            )
            rl = QHBoxLayout(row)
            rl.setContentsMargins(8, 0, 10, 0)
            rl.setSpacing(10)

            ico_badge = QWidget(row)
            ico_badge.setFixedSize(26, 26)
            ico_badge.setAttribute(Qt.WA_StyledBackground, True)
            c = QColor(icon_color_hex)
            badge_bg = f"rgba({c.red()}, {c.green()}, {c.blue()}, 0.14)"
            ico_badge.setStyleSheet(f"background: {badge_bg}; border-radius: 6px; border: none;")
            ibl = QHBoxLayout(ico_badge)
            ibl.setContentsMargins(0, 0, 0, 0)
            ibl.setAlignment(Qt.AlignCenter)

            ico_lbl = QLabel(ico_badge)
            ico_lbl.setPixmap(render_common_icon(svg_tpl, icon_color_hex, 15))
            ico_lbl.setStyleSheet("background: transparent; border: none;")
            ibl.addWidget(ico_lbl)
            rl.addWidget(ico_badge, alignment=Qt.AlignVCenter)

            txt_lbl = QLabel(label_text, row)
            txt_lbl.setStyleSheet(
                f"color: {text_color_hex}; font-size: 12.5px; font-weight: 600; "
                "font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif; "
                "background: transparent; border: none;"
            )
            rl.addWidget(txt_lbl, 1, alignment=Qt.AlignVCenter)

            def _on_press(e):
                self.dismiss_with_anim(on_click)
            row.mousePressEvent = _on_press
            lay.addWidget(row)

        def _add_divider():
            div = QFrame(self)
            div.setFixedHeight(1)
            div.setStyleSheet("background: rgba(255, 255, 255, 0.08); border: none; margin: 3px 6px;")
            lay.addWidget(div)

        # 1. Beaming actions
        active_tx = getattr(self.device_window, "_active_transfers", {}).get(pid) if self.device_window else None
        is_actively_beaming = bool(active_tx and not active_tx.get("cancelled") and active_tx.get("files"))

        if is_actively_beaming:
            def _kill_beam():
                tx = getattr(self.device_window, "_active_transfers", {}).get(pid) if self.device_window else None
                if tx:
                    tx["cancelled"] = True
                    tx["files"].clear()
                    if tx.get("btn"):
                        try:
                            tx["btn"].reset_state()
                        except Exception:
                            pass
                    if tx.get("card"):
                        tx["card"].set_progress(0.0)
                if self.device_window and hasattr(self.device_window, "_active_beaming_peers"):
                    self.device_window._active_beaming_peers.discard(pid)
                if self.device_window and hasattr(self.device_window, "_active_transfers"):
                    self.device_window._active_transfers.pop(pid, None)
                if self.device_window:
                    self.device_window._refresh_peers_ui()
            _add_action_row(_SVG_KILL, "#EF4444", "Kill Beam", "#EF4444", _kill_beam)

            def _more_to_go():
                if not self.device_window:
                    return
                more_files, _ = QFileDialog.getOpenFileNames(
                    self.device_window,
                    f"Add more files to queue for {pname}",
                    DEFAULT_SAVE_DIR if os.path.exists(DEFAULT_SAVE_DIR) else os.path.expanduser("~"),
                    "Images, PDFs & Media (*.png *.jpg *.jpeg *.webp *.gif *.mp4 *.pdf *.mov);;All Files (*.*)"
                )
                if more_files:
                    sorted_more = sorted(more_files, key=lambda f: os.path.getsize(f) if os.path.exists(f) else 0)
                    tx = getattr(self.device_window, "_active_transfers", {}).get(pid)
                    if tx:
                        tx["files"].extend(sorted_more)
                        tx["total_initial"] += len(sorted_more)
            _add_action_row(_SVG_MORE_FILES, "#A3E635", "More to Go", "#FFFFFF", _more_to_go)
            _add_divider()

        # 2. Continuous Sharing
        is_cont = pid in getattr(self.engine, "continuous_sharing_ids", set())
        def _toggle_continuous():
            if hasattr(self.engine, "toggle_continuous_sharing"):
                self.engine.toggle_continuous_sharing(pid)
            if self.device_window:
                self.device_window._refresh_peers_ui()
        _add_action_row(
            _SVG_INFINITY,
            "#A3E635" if is_cont else "#D4D4D8",
            "Turn Off Continuous" if is_cont else "Continuous Sharing",
            "#A3E635" if is_cont else "#FFFFFF",
            _toggle_continuous
        )

        # 3. Close Session (if active session & not trusted)
        if not is_trusted and self.engine.is_session_active(pid):
            _add_divider()
            def _close_session():
                self.engine.kill_session(pid)
                if self.device_window:
                    self.device_window._refresh_peers_ui()
            _add_action_row(_SVG_SESSION_CLOSE, "#F59E0B", "Close Session", "#F59E0B", _close_session)

        _add_divider()

        # 4. Trust / Untrust
        def _toggle_trust():
            self.engine.set_peer_trusted(pid, not is_trusted)
            if self.device_window:
                self.device_window._refresh_peers_ui()
        _add_action_row(
            _SVG_SHIELD_TRUST,
            "#A3E635" if is_trusted else "#38BDF8",
            "Remove Trusted" if is_trusted else "Mark as Trusted",
            "#FFFFFF",
            _toggle_trust
        )

        _add_divider()

        # 5. Forget Device
        def _forget_peer():
            if pid in self.engine.trusted_ids:
                self.engine.set_peer_trusted(pid, False)
            if hasattr(self.engine, "queued_signal_requests") and pid in self.engine.queued_signal_requests:
                self.engine.queued_signal_requests.discard(pid)
            with self.engine._lock:
                self.engine._peers.pop(pid, None)
                self.engine._connected_modes.pop(pid, None)
            if self.device_window:
                self.device_window._refresh_peers_ui()
        _add_action_row(_SVG_TRASH_CLEAN, "#EF4444", "Forget Device", "#EF4444", _forget_peer)

        self.adjustSize()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = float(self.width()), float(self.height())
        card = QPainterPath()
        card.addRoundedRect(QRectF(0.6, 0.6, w - 1.2, h - 1.2), 14.0, 14.0)
        p.fillPath(card, QColor(13, 15, 20, 252))
        p.setPen(QPen(QColor(255, 255, 255, 34), 1.0))
        p.drawPath(card)
        p.end()

    def show_anchored(self, anchor_btn: QWidget):
        self.setWindowOpacity(0.0)
        self.show()
        pos = anchor_btn.mapToGlobal(QPoint(anchor_btn.width() - self.width(), anchor_btn.height() + 4))
        scr = (QApplication.screenAt(pos) or QApplication.primaryScreen()).availableGeometry()
        x = min(scr.right() - self.width() - 8, max(scr.left() + 8, pos.x()))
        target_y = min(scr.bottom() - self.height() - 8, max(scr.top() + 8, pos.y()))
        self.move(x, target_y - 6)
        self.raise_()
        self.activateWindow()

        self._anim_group = QParallelAnimationGroup(self)
        fade_anim = QPropertyAnimation(self, b"windowOpacity", self)
        fade_anim.setDuration(140)
        fade_anim.setStartValue(0.0)
        fade_anim.setEndValue(1.0)
        fade_anim.setEasingCurve(QEasingCurve.OutCubic)
        self._anim_group.addAnimation(fade_anim)

        slide_anim = QPropertyAnimation(self, b"pos", self)
        slide_anim.setDuration(140)
        slide_anim.setStartValue(QPoint(x, target_y - 6))
        slide_anim.setEndValue(QPoint(x, target_y))
        slide_anim.setEasingCurve(QEasingCurve.OutCubic)
        self._anim_group.addAnimation(slide_anim)

        self._anim_group.start()

    def dismiss_with_anim(self, callback=None):
        if self._closing:
            return
        self._closing = True

        self._close_group = QParallelAnimationGroup(self)
        fade_out = QPropertyAnimation(self, b"windowOpacity", self)
        fade_out.setDuration(110)
        fade_out.setStartValue(self.windowOpacity())
        fade_out.setEndValue(0.0)
        fade_out.setEasingCurve(QEasingCurve.InCubic)
        self._close_group.addAnimation(fade_out)

        curr_pos = self.pos()
        slide_out = QPropertyAnimation(self, b"pos", self)
        slide_out.setDuration(110)
        slide_out.setStartValue(curr_pos)
        slide_out.setEndValue(QPoint(curr_pos.x(), curr_pos.y() + 4))
        slide_out.setEasingCurve(QEasingCurve.InCubic)
        self._close_group.addAnimation(slide_out)

        def _done():
            self.close()
            if callback:
                callback()
        self._close_group.finished.connect(_done)
        self._close_group.start()

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.dismiss_with_anim()
        else:
            super().keyPressEvent(e)


class SuperShareDeviceWindow(QWidget):
    """
    Razor-Sharp, Zero-Blur Obsidian DEVICE HUB Window:
      - Clean Brand Vector Header: 'THE' (White) + 'DEVICE HUB' (Cyber-Lime).
      - Back & Close buttons on right.
      - Clean 'DEVICE IDENTITY' eyebrow (NO Win+Shift+M!).
      - Floating User Identity: Ultra-sharp circular avatar, bold white Nickname, crisp sans-serif ID (NO code font!).
      - Subheader with live 'X ONLINE' badge + Pill Tabs (ALL, VIBES, TRUSTED) in white text with sharp cyber-lime border.
      - Floating peer rows: Peer Avatar, clean name & status sans-serif typography, solid cyber-lime 'Beam' button.
      - Minimalist Connect input with high-contrast, razor-sharp solid cyber-lime 'Connect' button (zero blur!).
      - Watermark: THE SUPERMOUSE v1.0.
    """

    def __init__(self, engine: SuperShareEngine, on_back_to_menu=None, on_back_to_share_menu=None, on_main_menu=None, on_open_stored=None, on_open_settings=None, parent=None):
        super().__init__(parent)
        self.engine = engine
        self.on_back_to_menu = on_back_to_menu
        self.on_back_to_share_menu = on_back_to_share_menu
        self.on_main_menu = on_main_menu or on_back_to_menu
        self.on_open_stored = on_open_stored
        self.on_open_settings = on_open_settings
        self._active_tab = "ALL"
        self._dragging = False
        self._drag_offset = QPoint()
        self._active_beaming_peers = set()

        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Window | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(396, 600)

        from ui_theme import apply_window_identity
        apply_window_identity(self, "TheSuperMouse - Device Hub")

        self.logo_pix = _load_app_logo_pix(self)
        self._build_ui()
        self.engine.signals.peers_updated.connect(self._refresh_peers_ui)
        self.engine.signals.pair_result.connect(self._on_pair_result)
        self._pending_vibe_peers = set()
        self.engine.history_events = self._load_history_events()

        if hasattr(self.engine.signals, "session_started"):
            self.engine.signals.session_started.connect(self._record_session_started)
        if hasattr(self.engine.signals, "file_received"):
            self.engine.signals.file_received.connect(self._record_file_received)

    def _get_history_file_path(self):
        return os.path.join(BASE_DIR, "super_share_history.json")

    def _load_history_events(self):
        p = self._get_history_file_path()
        if os.path.exists(p):
            try:
                with open(p, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return []

    def _save_history_events(self):
        p = self._get_history_file_path()
        try:
            with open(p, "w", encoding="utf-8") as f:
                json.dump(getattr(self.engine, "history_events", [])[:80], f, indent=2)
        except Exception:
            pass

    def _add_history_event(self, kind: str, title: str, detail: str):
        if not hasattr(self.engine, "history_events") or self.engine.history_events is None:
            self.engine.history_events = self._load_history_events()
        now_str = time.strftime("%I:%M %p")
        self.engine.history_events.insert(0, {
            "kind": kind,
            "title": title,
            "detail": detail,
            "time": now_str,
            "ts": time.time(),
        })
        if len(self.engine.history_events) > 80:
            self.engine.history_events.pop()
        self._save_history_events()
        if getattr(self, "_active_tab", "ALL") == "HISTORY":
            self._refresh_peers_ui()

    def _record_session_started(self, device_name: str, device_id: str):
        self._pending_vibe_peers.discard(device_id)
        self._add_history_event(
            "vibe_accepted",
            "Connected to Device",
            f"Active with {device_name} [{device_id}]"
        )

    def _record_file_received(self, path: str, sender: str, size_bytes: int, _mime: str):
        fname = os.path.basename(path)
        self._add_history_event(
            "image_received",
            f"Received {fname}",
            f"from {sender} · {_format_bytes(size_bytes)}"
        )

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # 1. Header: Brand Logo + 'THE' White + 'DEVICE HUB' Gradient | Back, Home & Close (Matching Quick Menu exactly!)
        header = QWidget(self)
        header.setFixedHeight(54)
        header.setCursor(Qt.OpenHandCursor)
        hdr = QHBoxLayout(header)
        hdr.setContentsMargins(16, 0, 14, 0)
        hdr.setSpacing(6)

        self.brand_title = _DeviceHubBrandTitle(self.logo_pix, header)
        hdr.addWidget(self.brand_title, alignment=Qt.AlignVCenter)

        hdr.addStretch(1)

        self.btn_back = CleanBackButton("Back to Super Share", box_size=30, icon_size=15, parent=header)
        self.btn_back.clicked.connect(self._go_back)
        hdr.addWidget(self.btn_back, alignment=Qt.AlignVCenter)

        self.btn_home = CleanHeaderIconButton("home", "Main Menu", box_size=30, icon_size=15, parent=header)
        self.btn_home.clicked.connect(self._go_menu)
        hdr.addWidget(self.btn_home, alignment=Qt.AlignVCenter)

        self.btn_close = CleanCloseButton("Close Device Hub", box_size=30, icon_size=15, parent=header)
        self.btn_close.clicked.connect(self.hide)
        hdr.addWidget(self.btn_close, alignment=Qt.AlignVCenter)

        root.addWidget(header)

        # 2. Main Body (Zero Box Containers)
        body = QWidget(self)
        b_lay = QVBoxLayout(body)
        b_lay.setContentsMargins(14, 2, 14, 12)
        b_lay.setSpacing(8)

        # Floating User Identity Section (Open-Canvas, Zero Box Container!)
        user_card = QWidget(body)
        user_card.setFixedHeight(66)
        user_card.setAttribute(Qt.WA_StyledBackground, True)
        user_card.setStyleSheet(
            "QWidget {"
            "  background: transparent;"
            "  border: none;"
            "}"
        )
        url = QHBoxLayout(user_card)
        url.setContentsMargins(10, 8, 10, 8)
        url.setSpacing(12)

        self.lbl_my_avatar = QLabel(user_card)
        self.lbl_my_avatar.setFixedSize(56, 56)
        self.lbl_my_avatar.setStyleSheet("background: transparent; border: none;")
        url.addWidget(self.lbl_my_avatar, alignment=Qt.AlignVCenter)

        col_user = QVBoxLayout()
        col_user.setSpacing(0)
        col_user.setContentsMargins(0, 0, 0, 0)
        col_user.setAlignment(Qt.AlignVCenter)

        self.lbl_my_name = QLabel(user_card)
        self.lbl_my_name.setStyleSheet("background: transparent; border: none; color: #FFFFFF; font-size: 14.5px; font-weight: 700; font-family: 'Segoe UI Variable Display', 'Segoe UI Variable', sans-serif;")
        col_user.addWidget(self.lbl_my_name, alignment=Qt.AlignVCenter)

        url.addLayout(col_user, 1)

        # Right-side Device ID copy button matching Share Settings exactly (108 x 28)
        dev_id = self.engine.cfg.get("device_id", "49281SMX")
        self.btn_copy_id = QPushButton(f"{dev_id}  ⧉", user_card)
        self.btn_copy_id.setCursor(Qt.PointingHandCursor)
        self.btn_copy_id.setToolTip("Click to copy Device ID")
        self.btn_copy_id.setFixedSize(108, 28)
        self._apply_id_button_idle_style(self.btn_copy_id)

        def _copy_id():
            cur_id = self.engine.cfg.get("device_id", "49281SMX")
            QApplication.clipboard().setText(cur_id)
            self.btn_copy_id.setText("COPIED!")
            self.btn_copy_id.setStyleSheet(
                "QPushButton { background: #a3e635; border: 1px solid #a3e635; border-radius: 6px; color: #040405; font-size: 11px; font-weight: 800; font-family: 'Segoe UI Variable Display', sans-serif; }"
            )
            QTimer.singleShot(2500, lambda: (
                self.btn_copy_id.setText(f"{self.engine.cfg.get('device_id', '49281SMX')}  ⧉"),
                self._apply_id_button_idle_style(self.btn_copy_id)
            ))
        self.btn_copy_id.clicked.connect(_copy_id)
        url.addWidget(self.btn_copy_id, alignment=Qt.AlignVCenter)
        b_lay.addWidget(user_card)
        self._refresh_identity_card()

        # Hairline Divider
        div1 = QFrame(body)
        div1.setFixedHeight(1)
        div1.setStyleSheet("background-color: rgba(255, 255, 255, 0.08);")
        b_lay.addWidget(div1)
        b_lay.addSpacing(2)

        # Row 1: Compact Devices Counter (Above)
        row_devices = QHBoxLayout()
        row_devices.setContentsMargins(4, 2, 4, 2)
        row_devices.setSpacing(6)

        self.lbl_online_pill = QLabel(body)
        self.lbl_online_pill.setText("<span style='color: #A1A1AA; font-weight: 700; letter-spacing: 0.8px; font-size: 11px;'>DEVICES</span> &nbsp;<span style='color: #a3e635; font-size: 11.5px; font-weight: 800;'>1</span>")
        self.lbl_online_pill.setStyleSheet(
            "QLabel { "
            "  background: transparent; "
            "  border: none; "
            "  font-family: 'Segoe UI Variable Display', -apple-system, sans-serif; "
            "}"
        )
        row_devices.addWidget(self.lbl_online_pill, alignment=Qt.AlignVCenter)
        row_devices.addStretch(1)
        b_lay.addLayout(row_devices)

        # Row 2: Tabs Row (Below DEVICES counter, utilizing full line space)
        row_tabs = QHBoxLayout()
        row_tabs.setContentsMargins(2, 2, 2, 4)
        row_tabs.setSpacing(6)

        # 1. ALL, VIBES, TRUSTED unified under ONE pill container (Bigger & Roomy)
        self.filter_pill = QFrame(body)
        self.filter_pill.setStyleSheet(
            "QFrame { background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.10); border-radius: 14px; }"
        )
        fpl = QHBoxLayout(self.filter_pill)
        fpl.setContentsMargins(3, 2, 3, 2)
        fpl.setSpacing(2)

        self.btn_tab_all = QPushButton("ALL", self.filter_pill)
        self.btn_tab_vibes = QPushButton("VIBES", self.filter_pill)
        self.btn_tab_trusted = QPushButton("TRUSTED", self.filter_pill)

        for btn, name in [
            (self.btn_tab_all, "ALL"),
            (self.btn_tab_vibes, "VIBES"),
            (self.btn_tab_trusted, "TRUSTED"),
        ]:
            btn.setFixedHeight(24)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda _, n=name: self._switch_tab(n))
            fpl.addWidget(btn)

        row_tabs.addWidget(self.filter_pill)

        row_tabs.addStretch(1)

        # 2. PENDING tab (NO pill container! Pure text tab, clean & bigger)
        self.btn_tab_pending = QPushButton("PENDING", body)
        self.btn_tab_pending.setFixedHeight(26)
        self.btn_tab_pending.setCursor(Qt.PointingHandCursor)
        self.btn_tab_pending.clicked.connect(lambda: self._switch_tab("PENDING"))
        row_tabs.addWidget(self.btn_tab_pending, alignment=Qt.AlignVCenter)

        # 3. HISTORY tab (NO pill container! Pure text tab, clean & bigger)
        self.btn_tab_history = QPushButton("HISTORY", body)
        self.btn_tab_history.setFixedHeight(26)
        self.btn_tab_history.setCursor(Qt.PointingHandCursor)
        self.btn_tab_history.clicked.connect(lambda: self._switch_tab("HISTORY"))
        row_tabs.addWidget(self.btn_tab_history, alignment=Qt.AlignVCenter)

        b_lay.addLayout(row_tabs)
        self._update_tab_styles()

        # 3. Floating Peer List (Open Canvas)
        self.scroll = QScrollArea(body)
        self.scroll.setWidgetResizable(True)
        self.scroll.setStyleSheet("QScrollArea { background: transparent; border: none; } QScrollBar { width: 0px; }")

        self.scroll_content = QWidget()
        self.scroll_content.setStyleSheet("background: transparent;")
        self.peers_layout = QVBoxLayout(self.scroll_content)
        self.peers_layout.setContentsMargins(0, 0, 0, 0)
        self.peers_layout.setSpacing(0)
        self.peers_layout.addStretch(1)

        self.scroll.setWidget(self.scroll_content)
        b_lay.addWidget(self.scroll, 1)

        # 4. Pure Floating Hint (Zero Box, Zero Border, Open Canvas)
        lbl_signal_hint = QLabel("• If device is in same signal, it will send request instantly.", body)
        lbl_signal_hint.setAlignment(Qt.AlignCenter)
        lbl_signal_hint.setStyleSheet(
            "color: #71717A; font-size: 10px; font-weight: 600; font-family: 'Segoe UI Variable Text', 'Segoe UI Variable', sans-serif; "
            "background: transparent; border: none; padding: 0px 4px; margin-bottom: 3px;"
        )
        b_lay.addWidget(lbl_signal_hint)

        # Simple, Clean Minimalist Input Bar
        conn_bar = QFrame(body)
        conn_bar.setFixedHeight(38)
        conn_bar.setAttribute(Qt.WA_StyledBackground, True)
        conn_bar.setStyleSheet(
            "QFrame { "
            "  background: #0E1013; "
            "  border: 1px solid rgba(255, 255, 255, 0.08); "
            "  border-radius: 19px; "
            "} "
            "QFrame:focus-within { "
            "  border-color: rgba(163, 230, 53, 0.55); "
            "}"
        )
        cbl = QHBoxLayout(conn_bar)
        cbl.setContentsMargins(14, 0, 5, 0)
        cbl.setSpacing(6)

        self.in_peer_id = QLineEdit(conn_bar)
        self.in_peer_id.setAttribute(Qt.WA_StyledBackground, True)
        self.in_peer_id.setPlaceholderText("Enter Device ID to make vibe")
        self.in_peer_id.setMaxLength(8)
        f_in = QFont("Segoe UI Variable Text", 9)
        f_in.setStyleStrategy(QFont.PreferQuality)
        self.in_peer_id.setFont(f_in)
        self.in_peer_id.setStyleSheet(
            "QLineEdit { "
            "  background: transparent; "
            "  border: none; "
            "  color: #FFFFFF; "
            "  font-size: 11.5px; "
            "  font-weight: 600; "
            "  font-family: 'Segoe UI Variable Text', 'Segoe UI', sans-serif; "
            "} "
            "QLineEdit::placeholder { "
            "  color: #A1A1AA; "
            "  font-weight: 500; "
            "}"
        )
        self.in_peer_id.returnPressed.connect(self._on_manual_pair_click)
        cbl.addWidget(self.in_peer_id, 1)

        self.btn_pair = QPushButton(conn_bar)
        self.btn_pair.setFixedSize(32, 32)
        self.btn_pair.setCursor(Qt.PointingHandCursor)
        self.btn_pair.setToolTip("Let's Vibe")
        vibe_ico = QIcon(render_common_icon("arrow_up_right", "#040405", 15))
        self.btn_pair.setIcon(vibe_ico)
        self.btn_pair.setIconSize(QSize(15, 15))
        self.btn_pair.setStyleSheet(
            "QPushButton { background-color: #a3e635; border: none; border-radius: 16px; } "
            "QPushButton:hover { background-color: #bbf45c; } QPushButton:pressed { background-color: #8cd622; }"
        )
        self.btn_pair.clicked.connect(self._on_manual_pair_click)
        cbl.addWidget(self.btn_pair, alignment=Qt.AlignVCenter)

        b_lay.addWidget(conn_bar)

        # 5. Version Watermark: v1.0
        lbl_watermark = QLabel("THE SUPERMOUSE v1.0", body)
        lbl_watermark.setAlignment(Qt.AlignCenter)
        lbl_watermark.setFixedHeight(18)
        lbl_watermark.setStyleSheet("color: rgba(255, 255, 255, 0.22); font-size: 8px; font-weight: 600; letter-spacing: 0.9px; background: transparent; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;")
        b_lay.addWidget(lbl_watermark)

        root.addWidget(body, 1)

    def _apply_id_button_idle_style(self, btn):
        btn.setStyleSheet(
            "QPushButton {"
            "  background: #090A0E;"
            "  border: 1px solid #38383F;"
            "  border-radius: 6px;"
            "  color: #FFFFFF;"
            "  font-size: 11.5px;"
            "  font-weight: 800;"
            "  letter-spacing: 0.6px;"
            "  font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif;"
            "}"
            "QPushButton:hover {"
            "  background: #a3e635;"
            "  border: 1px solid #a3e635;"
            "  color: #040405;"
            "}"
            "QPushButton:pressed {"
            "  background: #8cd622;"
            "}"
        )

    def _refresh_identity_card(self):
        cfile = self.engine.cfg.get("custom_avatar_file")
        g_idx = int(self.engine.cfg.get("avatar_gradient_idx", 0))
        aid = self.engine.cfg.get("avatar_id", 1)
        self.lbl_my_avatar.setPixmap(get_avatar_pixmap(cfile or aid, size=56, gradient_idx=g_idx, with_border=True))
        name = self.engine.cfg.get("device_name") or f"{socket.gethostname() or 'Windows'} PC"
        self.lbl_my_name.setText(name)
        dev_id = self.engine.cfg.get("device_id", "49281SMX")
        if hasattr(self, "btn_copy_id") and not self.btn_copy_id.text().startswith("COPIED"):
            self.btn_copy_id.setText(f"{dev_id}  ⧉")
            self._apply_id_button_idle_style(self.btn_copy_id)

    def _switch_tab(self, tab_name: str):
        if getattr(self, "_active_tab", None) == tab_name:
            return
        self._active_tab = tab_name
        self._update_tab_styles()
        self._refresh_peers_ui()

        # Silky smooth cross-fade animation on tab transition
        try:
            effect = QGraphicsOpacityEffect(self.scroll)
            self.scroll.setGraphicsEffect(effect)
            anim = QPropertyAnimation(effect, b"opacity", self)
            anim.setDuration(160)
            anim.setStartValue(0.2)
            anim.setEndValue(1.0)
            anim.setEasingCurve(QEasingCurve.OutCubic)
            anim.start(QPropertyAnimation.DeleteWhenStopped)
        except Exception:
            pass

    def _update_tab_styles(self):
        # Segmented Filter Pill styles (ALL, VIBES, TRUSTED under one pill)
        seg_active = (
            "QPushButton { background: #a3e635; color: #040405; border: none; border-radius: 11px; "
            "font-size: 10px; font-weight: 800; padding: 2px 8px; font-family: 'Segoe UI Variable Display', sans-serif; }"
        )
        seg_idle = (
            "QPushButton { background: transparent; color: #71717A; border: none; border-radius: 11px; "
            "font-size: 10px; font-weight: 700; padding: 2px 8px; font-family: 'Segoe UI Variable Display', sans-serif; } "
            "QPushButton:hover { color: #FFFFFF; background: rgba(255, 255, 255, 0.07); }"
        )
        self.btn_tab_all.setStyleSheet(seg_active if self._active_tab == "ALL" else seg_idle)
        self.btn_tab_vibes.setStyleSheet(seg_active if self._active_tab == "VIBES" else seg_idle)
        self.btn_tab_trusted.setStyleSheet(seg_active if self._active_tab == "TRUSTED" else seg_idle)

        # Standalone tabs (PENDING, HISTORY) - Vibrant Cyber-Lime pill when active, clean borderless when idle!
        ext_active = (
            "QPushButton { background: #a3e635; color: #040405; border: none; border-radius: 12px; "
            "font-size: 10px; font-weight: 800; padding: 2px 9px; font-family: 'Segoe UI Variable Display', sans-serif; }"
        )
        ext_idle = (
            "QPushButton { background: transparent; color: #71717A; border: none; border-radius: 12px; "
            "font-size: 10px; font-weight: 700; padding: 2px 9px; font-family: 'Segoe UI Variable Display', sans-serif; } "
            "QPushButton:hover { color: #FFFFFF; background: rgba(255, 255, 255, 0.07); }"
        )
        self.btn_tab_pending.setStyleSheet(ext_active if self._active_tab == "PENDING" else ext_idle)
        self.btn_tab_history.setStyleSheet(ext_active if self._active_tab == "HISTORY" else ext_idle)

    def _refresh_peers_ui(self):
        self._refresh_identity_card()
        while self.peers_layout.count() > 1:
            item = self.peers_layout.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()

        # Handle HISTORY Tab (Open-Canvas chronological activity stream, Zero Box Container!)
        if self._active_tab == "HISTORY":
            events = getattr(self.engine, "history_events", [])
            self.lbl_online_pill.setText(
                f"<span style='color: #A1A1AA; font-weight: 700; letter-spacing: 0.8px; font-size: 11px;'>DEVICES</span>"
                f"&nbsp;&nbsp;"
                f"<span style='color: #a3e635; font-size: 11.5px; font-weight: 800;'>{len(events)}</span>"
            )
            if not events:
                empty = QWidget()
                empty.setFixedHeight(120)
                el = QVBoxLayout(empty)
                el.setContentsMargins(14, 20, 14, 12)
                el.setSpacing(6)
                el.setAlignment(Qt.AlignCenter)
                lbl_e1 = QLabel("No Activity History Yet", empty)
                lbl_e1.setStyleSheet("color: #FFFFFF; font-size: 13.5px; font-weight: 800; font-family: 'Segoe UI Variable Display', sans-serif;")
                lbl_e1.setAlignment(Qt.AlignCenter)
                el.addWidget(lbl_e1)
                lbl_e2 = QLabel("Session vibe requests, connections, and beamed media will appear here.", empty)
                lbl_e2.setStyleSheet("color: #9CA3AF; font-size: 11px; font-weight: 500; font-family: 'Segoe UI Variable Text', sans-serif;")
                lbl_e2.setAlignment(Qt.AlignCenter)
                el.addWidget(lbl_e2)
                self.peers_layout.insertWidget(0, empty)
                return

            for ev in events:
                row = QWidget()
                row.setAttribute(Qt.WA_StyledBackground, True)
                row.setStyleSheet(
                    "QWidget { background: transparent; border-bottom: 1px solid rgba(255, 255, 255, 0.05); } "
                    "QWidget:hover { background: rgba(255, 255, 255, 0.03); }"
                )
                rl = QHBoxLayout(row)
                rl.setContentsMargins(10, 8, 10, 8)
                rl.setSpacing(12)

                ico_lbl = QLabel(row)
                ico_lbl.setFixedSize(28, 28)
                ekind = ev.get("kind", "")
                if ekind == "image_sent":
                    char_sym = "↗"
                    tint = "#a3e635"
                elif ekind == "image_received":
                    char_sym = "↙"
                    tint = "#38bdf8"
                elif ekind == "vibe_accepted":
                    char_sym = "●"
                    tint = "#a3e635"
                else:
                    char_sym = "∞"
                    tint = "#eab308"

                ico_lbl.setStyleSheet(
                    f"background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.10); "
                    f"border-radius: 14px; color: {tint}; font-size: 12px; font-weight: 800;"
                )
                ico_lbl.setAlignment(Qt.AlignCenter)
                ico_lbl.setText(char_sym)
                rl.addWidget(ico_lbl, alignment=Qt.AlignVCenter)

                col = QVBoxLayout()
                col.setSpacing(2)
                col.setContentsMargins(0, 0, 0, 0)
                t_lbl = QLabel(ev.get("title", ""), row)
                t_lbl.setStyleSheet("color: #FFFFFF; font-size: 12.5px; font-weight: 700; font-family: 'Segoe UI Variable Display', sans-serif;")
                col.addWidget(t_lbl)

                d_lbl = QLabel(ev.get("detail", ""), row)
                d_lbl.setStyleSheet("color: #94A3B8; font-size: 11px; font-weight: 500; font-family: 'Segoe UI Variable Text', sans-serif;")
                col.addWidget(d_lbl)
                rl.addLayout(col, 1)

                time_lbl = QLabel(ev.get("time", ""), row)
                time_lbl.setStyleSheet("color: #71717A; font-size: 10px; font-weight: 700; font-family: 'Segoe UI Variable Text', sans-serif;")
                rl.addWidget(time_lbl, alignment=Qt.AlignVCenter)

                self.peers_layout.insertWidget(self.peers_layout.count() - 1, row)
            return

        raw_peers = self.engine.get_peers_snapshot() if hasattr(self.engine, "get_peers_snapshot") else []

        # Auto-send to any queued IDs that just entered signal range
        queued = getattr(self.engine, "queued_signal_requests", set())
        if queued:
            matched = [p.get("id") for p in raw_peers if p.get("id") in queued]
            for q_id in matched:
                queued.remove(q_id)
                if hasattr(self.engine, "check_and_connect_id"):
                    self.engine.check_and_connect_id(q_id)

        trusted_ids = getattr(self.engine, "trusted_ids", set())
        vibes_ids = set(self.engine.cfg.get("vibes_ids", []))

        filtered = []
        if self._active_tab == "PENDING":
            pending_decisions = getattr(self.engine, "_pending_decisions", {})
            raw_peers_dict = {p.get("id"): p for p in raw_peers}
            for req_id, p_info in list(pending_decisions.items()):
                sender_id = p_info.get("sender_id", "")
                if sender_id:
                    base_p = raw_peers_dict.get(sender_id, {
                        "id": sender_id,
                        "name": f"Incoming ({sender_id})",
                        "avatar_id": 1,
                        "connected": False,
                        "mode": "PENDING"
                    })
                    item = dict(base_p)
                    item["is_pending"] = True
                    item["pending_type"] = "INCOMING"
                    item["req_id"] = req_id
                    filtered.append(item)

            for pid in list(getattr(self, "_pending_vibe_peers", set())):
                if not any(p.get("id") == pid for p in filtered):
                    base_p = raw_peers_dict.get(pid, {
                        "id": pid,
                        "name": f"Device ({pid})",
                        "avatar_id": 2,
                        "connected": False,
                        "mode": "PENDING"
                    })
                    item = dict(base_p)
                    item["is_pending"] = True
                    item["pending_type"] = "VIBING"
                    filtered.append(item)

            for q_id in list(queued):
                if not any(p.get("id") == q_id for p in filtered):
                    filtered.append({
                        "id": q_id,
                        "name": f"Queued ({q_id})",
                        "avatar_id": 2,
                        "connected": False,
                        "mode": "PENDING",
                        "is_pending": True,
                        "pending_type": "QUEUED"
                    })
        else:
            for p in raw_peers:
                pid = p.get("id", "")
                is_trusted = (pid in trusted_ids) or p.get("mode") == "TRUSTED"
                if self._active_tab == "TRUSTED" and not is_trusted:
                    continue
                if self._active_tab == "VIBES" and is_trusted:
                    continue
                filtered.append(p)

        online_count = len([p for p in filtered if p.get("connected")]) or (1 if filtered else 0)
        self.lbl_online_pill.setText(
            f"<span style='color: #A1A1AA; font-weight: 700; letter-spacing: 0.8px; font-size: 11px;'>DEVICES</span>"
            f"&nbsp;&nbsp;"
            f"<span style='color: #a3e635; font-size: 11.5px; font-weight: 800;'>{online_count}</span>"
        )

        if not filtered:
            empty = QWidget()
            empty.setFixedHeight(110)
            el = QVBoxLayout(empty)
            el.setContentsMargins(14, 18, 14, 12)
            el.setSpacing(6)
            el.setAlignment(Qt.AlignCenter)
            empty_title = "No Pending Requests" if self._active_tab == "PENDING" else f"No {self._active_tab} Devices In Signal"
            empty_desc = "Pending session and device vibe requests will appear here." if self._active_tab == "PENDING" else "Connect an 8-char Device ID below to beam files or vibe."
            lbl_e1 = QLabel(empty_title, empty)
            lbl_e1.setStyleSheet("color: #FFFFFF; font-size: 13px; font-weight: 800; font-family: 'Segoe UI Variable Display', 'Segoe UI Variable', sans-serif;")
            lbl_e1.setAlignment(Qt.AlignCenter)
            el.addWidget(lbl_e1)
            lbl_e2 = QLabel(empty_desc, empty)
            lbl_e2.setStyleSheet("color: #9CA3AF; font-size: 11px; font-weight: 500; font-family: 'Segoe UI Variable Text', 'Segoe UI Variable', sans-serif;")
            lbl_e2.setAlignment(Qt.AlignCenter)
            el.addWidget(lbl_e2)
            self.peers_layout.insertWidget(0, empty)
            return

        for p in filtered:
            row = PeerCardWidget()
            pid = p.get("id", "")
            pname = p.get("name", "Device")
            is_trusted = (pid in trusted_ids) or p.get("mode") == "TRUSTED"
            is_connected = bool(p.get("connected"))
            is_vibed = is_trusted or is_connected
            is_beaming = (pid in getattr(self, "_active_beaming_peers", set()))
            rl = QHBoxLayout(row)
            rl.setContentsMargins(12, 7, 10, 7)
            rl.setSpacing(12)

            avatar_lbl = QLabel(row)
            avatar_lbl.setFixedSize(52, 52)
            g_idx = int(p.get("avatar_gradient_idx", 0))
            a_id = p.get("avatar_id", 1)
            avatar_lbl.setPixmap(get_avatar_pixmap(a_id, size=52, gradient_idx=g_idx, with_border=True))
            avatar_lbl.setStyleSheet("background: transparent; border: none;")
            rl.addWidget(avatar_lbl, alignment=Qt.AlignVCenter)

            col = QVBoxLayout()
            col.setSpacing(0)
            col.setContentsMargins(0, 0, 0, 0)

            name_lbl = QLabel(pname, row)
            f_nm = QFont("Segoe UI Variable Display", 10, QFont.Bold)
            f_nm.setStyleStrategy(QFont.PreferQuality)
            name_lbl.setFont(f_nm)
            name_lbl.setAttribute(Qt.WA_StyledBackground, True)
            name_lbl.setStyleSheet("background: transparent; border: none; color: #FFFFFF; font-size: 13.5px; font-weight: 700; margin: 0px; padding: 0px; margin-bottom: -3px; font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif;")
            col.addWidget(name_lbl)

            # Plain text peer code only (No box container, no 'ID' prefix, snug zero-gap spacing)
            sub_lbl = QLabel(f"{pid}", row)
            sub_lbl.setStyleSheet(
                "QLabel { "
                "  background: transparent; "
                "  border: none; "
                "  color: #8E95A2; "
                "  font-size: 11px; "
                "  font-weight: 600; "
                "  margin: 0px; "
                "  padding: 0px; "
                "  margin-top: -3px; "
                "  letter-spacing: 0.5px; "
                "  font-family: 'Segoe UI Variable Text', sans-serif; "
                "}"
            )
            col.addWidget(sub_lbl)
            rl.addLayout(col, 1)

            is_session = self.engine.is_session_active(pid)
            if p.get("is_pending"):
                ptype = p.get("pending_type", "QUEUED")
                if ptype == "INCOMING":
                    btn_beam = QPushButton("Accept", row)
                    btn_beam.setFixedSize(62, 28)
                    btn_beam.setCursor(Qt.PointingHandCursor)
                    btn_beam.setStyleSheet(
                        "QPushButton { background: #A3E635; color: #040405; border: none; border-radius: 8px; font-size: 11px; font-weight: 800; } "
                        "QPushButton:hover { background: #BEF264; }"
                    )
                    req_id = p.get("req_id", "")
                    btn_beam.clicked.connect(lambda _, rid=req_id: self._resolve_pending_request(rid, True))
                elif ptype == "VIBING":
                    btn_beam = QPushButton("Vibing...", row)
                    btn_beam.setFixedSize(70, 28)
                    btn_beam.setEnabled(False)
                    btn_beam.setStyleSheet(
                        "QPushButton { background: rgba(163, 230, 53, 0.16); color: #A3E635; border: 1px solid #A3E635; border-radius: 8px; font-size: 10.5px; font-weight: 700; }"
                    )
                else:
                    btn_beam = QPushButton("Queued", row)
                    btn_beam.setFixedSize(64, 28)
                    btn_beam.setEnabled(False)
                    btn_beam.setStyleSheet(
                        "QPushButton { background: rgba(255, 255, 255, 0.08); color: #71717A; border: 1px solid rgba(255, 255, 255, 0.12); border-radius: 8px; font-size: 10.5px; font-weight: 700; }"
                    )
            else:
                if is_trusted:
                    btn_mode = "SHARE"
                elif is_session:
                    btn_mode = "SEND"
                else:
                    btn_mode = "VIBE"
                btn_beam = BeamActionButton(mode=btn_mode, is_beaming=is_beaming, parent=row)
                btn_beam.clicked.connect(lambda _, peer=p, b=btn_beam, r=row, m=btn_mode: self._handle_peer_action_click(peer, b, r, m))
            rl.addWidget(btn_beam, alignment=Qt.AlignVCenter)

            btn_dots = QPushButton("•••", row)
            btn_dots.setFixedSize(28, 26)
            btn_dots.setCursor(Qt.PointingHandCursor)
            btn_dots.setStyleSheet(
                "QPushButton { background: transparent; color: #71717A; border: none; border-radius: 6px; font-size: 11px; font-weight: 800; letter-spacing: 1px; } "
                "QPushButton:hover { color: #FFFFFF; background: rgba(255, 255, 255, 0.08); } "
                "QPushButton:pressed { background: rgba(255, 255, 255, 0.14); }"
            )
            p_data = dict(p)
            p_data["is_trusted"] = is_trusted
            btn_dots.clicked.connect(lambda _, b=btn_dots, peer=p_data: self._show_dots_menu(peer, anchor=b))
            rl.addWidget(btn_dots, alignment=Qt.AlignVCenter)

            self.peers_layout.insertWidget(self.peers_layout.count() - 1, row)

    def _handle_peer_action_click(self, peer: dict, btn_beam=None, card_widget=None, mode: str = "VIBE"):
        pid = peer.get("id", "")
        pname = peer.get("name", "Device")
        if mode in ("SHARE", "SEND"):
            self._on_beam_to_peer(peer, btn_beam, card_widget)
        else:
            # Let's Vibe: start vibe session request
            self._pending_vibe_peers.add(pid)
            self._add_history_event("vibe_request", "Vibe Request Sent", f"to {pname} [{pid}]")
            if btn_beam:
                btn_beam.setText("Vibing...")
                btn_beam.setEnabled(False)
            try:
                from .toasts import SingleLineNoticeToast
                toast = SingleLineNoticeToast("Waiting for the device to accept the connection")
                toast.launch()
            except Exception:
                pass
            if hasattr(self.engine, "check_and_connect_id"):
                self.engine.check_and_connect_id(pid)

    def _resolve_pending_request(self, req_id: str, allow: bool):
        if hasattr(self.engine, "resolve_prompt"):
            self.engine.resolve_prompt(req_id, allow)
        self._refresh_peers_ui()

    def _show_dots_menu(self, peer: dict, anchor=None):
        old_flyout = getattr(self, "_active_flyout", None)
        if old_flyout is not None:
            try:
                is_same = getattr(old_flyout, "_peer_id", None) == peer.get("id")
                old_flyout.close()
                self._active_flyout = None
                if is_same:
                    return
            except Exception:
                self._active_flyout = None

        flyout = PeerActionsFlyout(peer, self.engine, device_window=self, parent=self)
        flyout._peer_id = peer.get("id")
        self._active_flyout = flyout
        if anchor:
            flyout.show_anchored(anchor)
        else:
            flyout.show_anchored(self)

    def _on_manual_pair_click(self):
        raw = self.in_peer_id.text().strip().upper()
        target = "".join(c for c in raw if c.isalnum())
        if not target:
            return

        self.in_peer_id.clear()

        raw_peers = self.engine.get_peers_snapshot() if hasattr(self.engine, "get_peers_snapshot") else []
        is_in_signal = any(p.get("id") == target for p in raw_peers)

        if is_in_signal:
            if hasattr(self.engine, "check_and_connect_id"):
                self.engine.check_and_connect_id(target)
            self._switch_tab("ALL")
        else:
            if not hasattr(self.engine, "queued_signal_requests"):
                self.engine.queued_signal_requests = set()
            self.engine.queued_signal_requests.add(target)
            self._switch_tab("PENDING")

        self._refresh_peers_ui()

    def _show_queue_dialog(self, target: str):
        def _confirm_queue():
            if not hasattr(self.engine, "queued_signal_requests"):
                self.engine.queued_signal_requests = set()
            self.engine.queued_signal_requests.add(target)
            self.in_peer_id.clear()

        dlg = QueueRequestModalDialog(target, on_confirm=_confirm_queue, parent=self)
        dlg.resize(320, 185)
        dlg.move(self.geometry().center().x() - 160, self.geometry().center().y() - 92)
        dlg.show()
        dlg.raise_()

    def _on_pair_result(self, *args):
        self._refresh_peers_ui()

    def _on_beam_to_peer(self, peer, btn_beam=None, card_widget=None):
        pname = peer.get("name", "Device")
        pid = peer.get("id", "")
        default_dir = DEFAULT_SAVE_DIR if os.path.exists(DEFAULT_SAVE_DIR) else os.path.expanduser("~")
        files, _ = QFileDialog.getOpenFileNames(
            self,
            f"Select items to send to {pname}",
            default_dir,
            "Images, PDFs & Media (*.png *.jpg *.jpeg *.webp *.gif *.mp4 *.pdf *.mov);;All Files (*.*)"
        )
        if not files:
            return

        # Priority Sorting: Smallest and fastest files send first!
        sorted_files = sorted(files, key=lambda f: os.path.getsize(f) if os.path.exists(f) else 0)

        fnames = [os.path.basename(f) for f in sorted_files]
        summary = fnames[0] if len(fnames) == 1 else f"{len(fnames)} items ({', '.join(fnames[:2])}...)"
        self._add_history_event("image_sent", f"Beamed {summary}", f"to {pname} [{pid}]")

        if not hasattr(self, "_active_beaming_peers"):
            self._active_beaming_peers = set()
        self._active_beaming_peers.add(pid)

        if not hasattr(self, "_active_transfers"):
            self._active_transfers = {}

        tx_state = {
            "files": list(sorted_files),
            "cancelled": False,
            "btn": btn_beam,
            "card": card_widget,
            "total_initial": len(sorted_files),
            "sent_count": 0
        }
        self._active_transfers[pid] = tx_state

        if btn_beam:
            btn_beam.set_beaming_progress(6.0)
        if card_widget:
            card_widget.set_progress(6.0)

        def _worker():
            while tx_state["files"] and not tx_state["cancelled"]:
                fpath = tx_state["files"].pop(0)
                if not os.path.exists(fpath):
                    continue
                tx_state["sent_count"] += 1
                total = max(1, tx_state["total_initial"] + len(tx_state["files"]))
                pct = int((tx_state["sent_count"] / float(total)) * 88.0) + 6
                if btn_beam and not tx_state["cancelled"]:
                    QTimer.singleShot(0, lambda p=pct: btn_beam.set_beaming_progress(p))
                if card_widget and not tx_state["cancelled"]:
                    QTimer.singleShot(0, lambda p=pct: card_widget.set_progress(p))
                try:
                    self.engine.send_file_to_connected(fpath, peer, sync=True)
                except Exception as ex:
                    print(f"Error beaming {fpath}: {ex}")
                time.sleep(0.16)

            if not tx_state["cancelled"]:
                if btn_beam:
                    QTimer.singleShot(0, lambda: btn_beam.set_beaming_progress(100.0))
                if card_widget:
                    QTimer.singleShot(0, lambda: card_widget.set_progress(100.0))
                time.sleep(0.4)

            self._active_beaming_peers.discard(pid)
            self._active_transfers.pop(pid, None)

            if card_widget:
                QTimer.singleShot(0, lambda: card_widget.set_progress(0.0))

            if btn_beam:
                btn_beam.reset_state()
                is_trusted = (pid in self.engine.trusted_ids) or peer.get("mode") == "TRUSTED"
                is_sess = self.engine.is_session_active(pid)
                next_mode = "SHARE" if is_trusted else ("SEND" if is_sess else "VIBE")
                QTimer.singleShot(0, lambda m=next_mode: (btn_beam.reset_state(), btn_beam.set_mode(m)))

            QTimer.singleShot(100, self._refresh_peers_ui)

        threading.Thread(target=_worker, daemon=True).start()

    def _go_back(self):
        target = self.on_back_to_share_menu or self.on_back_to_menu
        if callable(target):
            self.switch_out_asmr_animation(on_finished=target)
        else:
            self.hide()

    def _go_menu(self):
        target = self.on_main_menu or self.on_back_to_menu
        if callable(target):
            self.switch_out_asmr_animation(on_finished=target)
        else:
            self.hide()

    def switch_out_asmr_animation(self, on_finished=None):
        from PySide6.QtCore import QParallelAnimationGroup, QPropertyAnimation, QEasingCurve
        start_geom = self.geometry()
        end_geom = self.geometry()
        end_geom.moveTop(end_geom.top() + 30)

        group = QParallelAnimationGroup(self)
        anim_op = QPropertyAnimation(self, b"windowOpacity", self)
        anim_op.setDuration(160)
        anim_op.setStartValue(self.windowOpacity())
        anim_op.setEndValue(0.0)
        anim_op.setEasingCurve(QEasingCurve.InCubic)
        group.addAnimation(anim_op)

        anim_pos = QPropertyAnimation(self, b"geometry", self)
        anim_pos.setDuration(160)
        anim_pos.setStartValue(start_geom)
        anim_pos.setEndValue(end_geom)
        anim_pos.setEasingCurve(QEasingCurve.InCubic)
        group.addAnimation(anim_pos)

        def _done():
            self.hide()
            self.setWindowOpacity(1.0)
            if on_finished:
                on_finished()

        group.finished.connect(_done)
        group.start()
        self._close_anim_group = group

    def open_window(self):
        self._refresh_identity_card()
        self._refresh_peers_ui()
        self._center_or_cursor()
        final_geom = self.geometry()
        start_geom = self.geometry()
        start_geom.moveTop(start_geom.top() + 30)
        self.setGeometry(start_geom)
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.activateWindow()

        from PySide6.QtCore import QParallelAnimationGroup, QPropertyAnimation, QEasingCurve
        group = QParallelAnimationGroup(self)
        anim_op = QPropertyAnimation(self, b"windowOpacity", self)
        anim_op.setDuration(210)
        anim_op.setStartValue(0.0)
        anim_op.setEndValue(1.0)
        anim_op.setEasingCurve(QEasingCurve.OutCubic)
        group.addAnimation(anim_op)

        anim_pos = QPropertyAnimation(self, b"geometry", self)
        anim_pos.setDuration(210)
        anim_pos.setStartValue(start_geom)
        anim_pos.setEndValue(final_geom)
        anim_pos.setEasingCurve(QEasingCurve.OutCubic)
        group.addAnimation(anim_pos)

        group.start()
        self._open_anim_group = group

    def open_asmr_switch(self):
        self.open_window()

    def _center_or_cursor(self):
        scr = (QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()).availableGeometry()
        w, h = self.width(), self.height()
        tx = scr.center().x() - w // 2
        ty = scr.center().y() - h // 2
        self.setGeometry(tx, ty, w, h)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._dragging = True
            self._drag_offset = e.globalPosition().toPoint() - self.frameGeometry().topLeft()
            e.accept()

    def mouseMoveEvent(self, e):
        if self._dragging and e.buttons() & Qt.LeftButton:
            self.move(e.globalPosition().toPoint() - self._drag_offset)
            e.accept()

    def mouseReleaseEvent(self, e):
        self._dragging = False

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        w, h = float(self.width()), float(self.height())
        rect = QRectF(0.5, 0.5, w - 1.0, h - 1.0)
        card = QPainterPath()
        card.addRoundedRect(rect, 14.0, 14.0)
        p.fillPath(card, QColor(4, 4, 5, 254))
        p.setPen(QPen(QColor(255, 255, 255, 24), 1.0))
        p.drawPath(card)
        p.end()
