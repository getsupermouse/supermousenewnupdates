# -*- coding: utf-8 -*-
"""
THE SUPER MOUSE - SUPER SHARE SETTINGS WINDOW MODULE
=====================================================
Unified Obsidian Design Language matching Device Hub:
  - Header: Dual-tone Brand Vector 'THE' (White) + 'SHARE SETTINGS' (Cyber-Lime Gradient).
  - Profile Card: High-DPI 58x58 Circular Avatar Preview with Gradient Border Ring + Micro Dark 'Edit' Pill + Razor-sharp Solid ID Button (3s 'COPIED!').
  - Avatar Selector: 4-column 64x64 enlarged circular avatars with balanced equal margins (14px L/R, 8px T/B) and 12px grid spacing.
  - 22 Gradient Borders: Enlarged 36x36 100% Vector Circular Swatches with visible cyber-lime scrollbar (fewer visible, more on scroll).
  - Shared Action Card: Houses both the prominent iOS Permission Toggle AND Storage Directory with normal separate Change/Open buttons.
  - Minimalist 'WHAT'S!': Positioned at bottom with a single elegant, neat paragraph.
  - Window Size: Strict 380x600 matching Device Hub.
"""

from .common import *
import os
import sys
import time
import json
import random
import re
import socket
import hashlib
import subprocess
import threading
import urllib.request

from PySide6.QtCore import (
    QEasingCurve,
    QObject,
    QPoint,
    QPropertyAnimation,
    QRect,
    QRectF,
    Qt,
    QTimer,
    QVariantAnimation,
    Signal,
)
from PySide6.QtGui import (
    QIcon,
    QImage,
    QColor,
    QCursor,
    QFont,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
    QTransform,
    QLinearGradient,
)
from PySide6.QtWidgets import (
    QApplication,
    QDialog,
    QFileDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QToolTip,
    QVBoxLayout,
    QWidget,
)

from ui_theme import (
    ACCENT_LIME,
    TEXT_MUTED,
    TEXT_PRIMARY,
    TEXT_SECONDARY,
    native_dpr,
    CleanBackButton,
    CleanCloseButton,
    CleanHeaderIconButton,
    render_common_icon,
    COMMON_ICONS,
    format_count_label,
)

from .common import (
    BASE_DIR, CONFIG_PATH, DEFAULT_SAVE_DIR, _load_or_create_config, _save_config,
    _load_app_logo_pix, get_avatar_pixmap, AVATARS_DIR, GRADIENT_PRESETS
)
from .engine import SuperShareEngine


# ──────────────────────────────────────────────────────────────────────────────
#  SMOOTH KINETIC SCROLL AREAS
# ──────────────────────────────────────────────────────────────────────────────
class SmoothScrollArea(QScrollArea):
    """Sleek vertical scroll area with fluid, cubic-eased wheel scrolling and visible 3.5px cyber-lime thumb."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self._anim = None
        self.setWidgetResizable(True)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.setStyleSheet("""
            QScrollArea { background: transparent; border: none; }
            QScrollBar:vertical {
                width: 3.5px;
                background: rgba(255, 255, 255, 0.04);
                margin: 2px 0px 2px 0px;
                border-radius: 2px;
            }
            QScrollBar::handle:vertical {
                background: #a3e635;
                min-height: 20px;
                border-radius: 2px;
            }
            QScrollBar::handle:vertical:hover {
                background: #bbf45c;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
                background: none;
            }
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
                background: none;
            }
        """)

    def wheelEvent(self, event):
        num_degrees = event.angleDelta().y()
        if num_degrees == 0:
            return
        num_steps = num_degrees / 120.0
        cur_val = self.verticalScrollBar().value()
        target_val = int(cur_val - num_steps * 60)
        target_val = max(0, min(self.verticalScrollBar().maximum(), target_val))

        if self._anim and self._anim.state() == QPropertyAnimation.Running:
            cur_val = self._anim.currentValue()
            self._anim.stop()

        self._anim = QPropertyAnimation(self.verticalScrollBar(), b"value", self)
        self._anim.setDuration(160)
        self._anim.setStartValue(cur_val)
        self._anim.setEndValue(target_val)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)
        self._anim.start()
        event.accept()


class SmoothHScrollArea(QScrollArea):
    """Sleek horizontal scroll area with fluid wheel scrolling and always-visible 3.5px cyber-lime thumb."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self._anim = None
        self.setWidgetResizable(True)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self.setStyleSheet("""
            QScrollArea { background: transparent; border: none; }
            QScrollBar:horizontal {
                height: 3.5px;
                background: rgba(255, 255, 255, 0.04);
                margin: 0px 2px 0px 2px;
                border-radius: 2px;
            }
            QScrollBar::handle:horizontal {
                background: #a3e635;
                min-width: 24px;
                border-radius: 2px;
            }
            QScrollBar::handle:horizontal:hover {
                background: #bbf45c;
            }
            QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
                width: 0px;
                background: none;
            }
            QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {
                background: none;
            }
        """)

    def wheelEvent(self, event):
        delta = event.angleDelta().x() or event.angleDelta().y()
        if delta == 0:
            return
        num_steps = delta / 120.0
        cur_val = self.horizontalScrollBar().value()
        target_val = int(cur_val - num_steps * 52)
        target_val = max(0, min(self.horizontalScrollBar().maximum(), target_val))

        if self._anim and self._anim.state() == QPropertyAnimation.Running:
            cur_val = self._anim.currentValue()
            self._anim.stop()

        self._anim = QPropertyAnimation(self.horizontalScrollBar(), b"value", self)
        self._anim.setDuration(160)
        self._anim.setStartValue(cur_val)
        self._anim.setEndValue(target_val)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)
        self._anim.start()
        event.accept()


# ──────────────────────────────────────────────────────────────────────────────
#  PURE CIRCULAR AVATAR BUTTON (64x64 ENLARGED SIZE)
# ──────────────────────────────────────────────────────────────────────────────
class AvatarCircleButton(QPushButton):
    """Pure circular avatar button: 64x64 enlarged, 100% round clip, zero border on all, active green ring only on selected."""
    def __init__(self, fname: str, is_selected=False, parent=None):
        super().__init__(parent)
        self.fname = fname
        self.is_selected = is_selected
        self.setFixedSize(64, 64)
        self.setCursor(Qt.PointingHandCursor)
        self.setAttribute(Qt.WA_Hover, True)
        self.setStyleSheet("background: transparent; border: none;")
        self.pix = get_avatar_pixmap(fname, size=60, with_border=False)

    def set_selected(self, sel: bool):
        if self.is_selected != sel:
            self.is_selected = sel
            self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        w = float(self.width())
        h = float(self.height())

        if self.is_selected:
            p.setPen(QPen(QColor("#a3e635"), 2.2))
            p.setBrush(Qt.NoBrush)
            p.drawEllipse(QRectF(1.0, 1.0, w - 2.0, h - 2.0))
            inner_rect = QRectF(3.5, 3.5, w - 7.0, h - 7.0)
        else:
            inner_rect = QRectF(1.0, 1.0, w - 2.0, h - 2.0)

        clip = QPainterPath()
        clip.addEllipse(inner_rect)
        p.setClipPath(clip)

        if self.pix and not self.pix.isNull():
            p.drawPixmap(inner_rect.toRect(), self.pix)
        else:
            p.fillRect(inner_rect, QColor("#12141A"))

        p.end()


# ──────────────────────────────────────────────────────────────────────────────
#  VECTOR CIRCULAR GRADIENT SWATCH (36x36 ENLARGED)
# ──────────────────────────────────────────────────────────────────────────────
class GradientSwatchButton(QPushButton):
    """36x36 Vector Circular Swatch with light-grey spaced selection ring (does not touch circle)."""
    def __init__(self, g_idx: int, g_name: str, stops: list, is_selected=False, parent=None):
        super().__init__(parent)
        self.g_idx = g_idx
        self.g_name = g_name
        self.stops = stops
        self.is_selected = is_selected
        self.setFixedSize(36, 36)
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip(g_name)
        self.setAttribute(Qt.WA_Hover, True)
        self.setStyleSheet("background: transparent; border: none;")

    def set_selected(self, sel: bool):
        if self.is_selected != sel:
            self.is_selected = sel
            self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        w = float(self.width())
        h = float(self.height())

        if self.is_selected:
            p.setPen(QPen(QColor("#A1A1AA"), 1.5))
            p.setBrush(Qt.NoBrush)
            p.drawEllipse(QRectF(1.0, 1.0, w - 2.0, h - 2.0))
            grad_rect = QRectF(3.5, 3.5, w - 7.0, h - 7.0)
        else:
            p.setPen(QPen(QColor(255, 255, 255, 25), 1.0))
            grad_rect = QRectF(2.0, 2.0, w - 4.0, h - 4.0)

        grad = QLinearGradient(grad_rect.left(), grad_rect.top(), grad_rect.right(), grad_rect.bottom())
        for stop, col in self.stops:
            grad.setColorAt(stop, QColor(col))

        p.setBrush(grad)
        p.drawEllipse(grad_rect)
        p.end()


# ──────────────────────────────────────────────────────────────────────────────
#  PROMINENT iOS-STYLE TOGGLE SWITCH
# ──────────────────────────────────────────────────────────────────────────────
class CleanToggleSwitch(QPushButton):
    """High-contrast, prominent iOS-style toggle switch with crisp borders and solid thumb."""
    def __init__(self, checked=False, parent=None):
        super().__init__(parent)
        self.setCheckable(True)
        self.setChecked(checked)
        self.setFixedSize(42, 22)
        self.setCursor(Qt.PointingHandCursor)
        self.setStyleSheet("background: transparent; border: none;")

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = float(self.width()), float(self.height())

        if self.isChecked():
            # Cyber-Lime Track
            p.setBrush(QColor("#a3e635"))
            p.setPen(QPen(QColor("#bbf45c"), 1.0))
            p.drawRoundedRect(1.0, 1.0, w - 2.0, h - 2.0, (h - 2.0) / 2.0, (h - 2.0) / 2.0)

            # Obsidian Thumb
            thumb_x = w - h + 2.0
            p.setBrush(QColor("#040405"))
            p.setPen(Qt.NoPen)
            p.drawEllipse(QRectF(thumb_x, 3.0, h - 6.0, h - 6.0))
        else:
            # High-contrast Glass Track
            p.setBrush(QColor(255, 255, 255, 28))
            p.setPen(QPen(QColor(255, 255, 255, 60), 1.0))
            p.drawRoundedRect(1.0, 1.0, w - 2.0, h - 2.0, (h - 2.0) / 2.0, (h - 2.0) / 2.0)

            # Solid White Thumb
            p.setBrush(QColor("#FFFFFF"))
            p.setPen(Qt.NoPen)
            p.drawEllipse(QRectF(3.0, 3.0, h - 6.0, h - 6.0))

        p.end()


# ──────────────────────────────────────────────────────────────────────────────
#  INTERACTIVE DIRECTORY HOVER LABEL
# ──────────────────────────────────────────────────────────────────────────────
class DirectoryHoverLabel(QLabel):
    """Hoverable path label that reveals full location cleanly in tooltip and highlights."""
    def __init__(self, full_path: str, parent=None):
        super().__init__(parent)
        self.full_path = full_path
        self.setCursor(Qt.PointingHandCursor)
        self.update_path(full_path)

    def update_path(self, path: str):
        self.full_path = path
        fm = self.fontMetrics()
        elided = fm.elidedText(path, Qt.ElideMiddle, 150)
        self.setText(elided)
        self.setToolTip(path)
        self.setStyleSheet(
            "QLabel { color: #D4D4D8; font-size: 11px; font-weight: 600; font-family: 'Segoe UI Variable Text', sans-serif; background: transparent; border: none; }"
        )

    def enterEvent(self, e):
        QToolTip.showText(QCursor.pos(), self.full_path, self)
        self.setStyleSheet(
            "QLabel { color: #a3e635; font-size: 11px; font-weight: 700; font-family: 'Segoe UI Variable Text', sans-serif; background: transparent; border: none; }"
        )
        super().enterEvent(e)

    def leaveEvent(self, e):
        QToolTip.hideText()
        self.setStyleSheet(
            "QLabel { color: #D4D4D8; font-size: 11px; font-weight: 600; font-family: 'Segoe UI Variable Text', sans-serif; background: transparent; border: none; }"
        )
        super().leaveEvent(e)


# ──────────────────────────────────────────────────────────────────────────────
#  VECTOR BRAND HEADER
# ──────────────────────────────────────────────────────────────────────────────
class _ShareSettingsBrandTitle(QWidget):
    """Render razor-sharp vector brand: 'THE' (White) + 'SHARE SETTINGS' (Cyber-Lime Gradient)."""
    def __init__(self, logo_pix: QPixmap | None, parent=None):
        super().__init__(parent)
        self.logo_pix = logo_pix
        self.setFixedHeight(30)
        self.setFixedWidth(230)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        bx = 0.0
        by_c = float(self.height()) * 0.5
        if self.logo_pix and not self.logo_pix.isNull():
            ldpr = max(1.0, float(self.logo_pix.devicePixelRatio() or 1.0))
            lw = self.logo_pix.width() / ldpr
            lh = self.logo_pix.height() / ldpr
            p.drawPixmap(int(round(bx)), int(round(by_c - lh * 0.5)), self.logo_pix)
            bx += lw + 8.0

        f_logo = QFont("Segoe UI Variable")
        f_logo.setStyleName("Display Bold")
        f_logo.setPointSizeF(11.2)
        f_logo.setLetterSpacing(QFont.AbsoluteSpacing, 0.35)
        f_logo.setHintingPreference(QFont.PreferNoHinting)

        probe = QPainterPath()
        probe.addText(0.0, 0.0, f_logo, "THE SHARE SETTINGS")
        br = probe.boundingRect()
        baseline_y = by_c - (br.top() + br.height() * 0.5)

        p1 = QPainterPath()
        p1.addText(bx, baseline_y, f_logo, "THE")
        p.fillPath(p1, QColor("#FFFFFF"))

        w1 = p1.boundingRect().width()
        smx = bx + w1 + 5.5

        p2 = QPainterPath()
        p2.addText(smx, baseline_y, f_logo, "SHARE SETTINGS")
        b2 = p2.boundingRect()
        g_sm = QLinearGradient(b2.left(), 0.0, b2.right(), 0.0)
        g_sm.setColorAt(0.0, QColor("#FFFF00"))
        g_sm.setColorAt(1.0, QColor("#00FF85"))
        p.fillPath(p2, g_sm)
        p.end()


# ──────────────────────────────────────────────────────────────────────────────
#  MASTER SHARE SETTINGS WINDOW (STRICT 380 x 600 SIZING)
# ──────────────────────────────────────────────────────────────────────────────
class SuperShareSettingsWindow(QWidget):
    """
    Super Share Settings Window aligned with Device Hub architecture & styling.
    """
    def __init__(self, engine: SuperShareEngine, on_back_to_menu=None, parent=None):
        super().__init__(parent)
        self.engine = engine
        self.on_back_to_menu = on_back_to_menu
        self.on_settings_changed = None
        self._dragging = False
        self._drag_offset = QPoint()

        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Window | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(380, 600)

        from ui_theme import apply_window_identity
        apply_window_identity(self, "TheSuperMouse - Share Settings")

        self.logo_pix = _load_app_logo_pix(self)
        self._build_ui()

    def _apply_id_button_idle_style(self, btn):
        btn.setStyleSheet(
            "QPushButton {"
            "  background: #090A0E;"
            "  border: 1px solid #38383F;"
            "  border-radius: 6px;"
            "  color: #FFFFFF;"
            "  font-size: 11.5px;"
            "  font-weight: 800;"
            "  letter-spacing: 0.6px;"
            "  font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif;"
            "}"
            "QPushButton:hover {"
            "  background: #a3e635;"
            "  border: 1px solid #a3e635;"
            "  color: #040405;"
            "}"
            "QPushButton:pressed {"
            "  background: #8cd622;"
            "}"
        )

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # 1. Header: Brand Vector Logo/Text + Back, Home & Close
        header = QWidget(self)
        header.setFixedHeight(48)
        header.setCursor(Qt.OpenHandCursor)
        hdr = QHBoxLayout(header)
        hdr.setContentsMargins(16, 0, 14, 0)
        hdr.setSpacing(6)

        self.brand_title = _ShareSettingsBrandTitle(self.logo_pix, header)
        hdr.addWidget(self.brand_title, alignment=Qt.AlignVCenter)

        hdr.addStretch(1)

        self.btn_back = CleanBackButton("Back to Super Share", box_size=30, icon_size=15, parent=header)
        self.btn_back.clicked.connect(self._go_back)
        hdr.addWidget(self.btn_back, alignment=Qt.AlignVCenter)

        self.btn_home = CleanHeaderIconButton("home", "Main Menu", box_size=30, icon_size=15, parent=header)
        self.btn_home.clicked.connect(self._go_menu)
        hdr.addWidget(self.btn_home, alignment=Qt.AlignVCenter)

        self.btn_close = CleanCloseButton("Close Settings", box_size=30, icon_size=15, parent=header)
        self.btn_close.clicked.connect(self.hide)
        hdr.addWidget(self.btn_close, alignment=Qt.AlignVCenter)

        root.addWidget(header)

        # 2. Main Body with clean vertical flow
        body = QWidget(self)
        b_lay = QVBoxLayout(body)
        b_lay.setContentsMargins(14, 0, 14, 8)
        b_lay.setSpacing(6)

        # SECTION 1: Device Identity Profile Card
        user_card = QWidget(body)
        user_card.setFixedHeight(74)
        user_card.setAttribute(Qt.WA_StyledBackground, True)
        user_card.setStyleSheet(
            "QWidget {"
            "  background: rgba(255, 255, 255, 0.035);"
            "  border: 1px solid rgba(255, 255, 255, 0.07);"
            "  border-radius: 14px;"
            "}"
        )
        url = QHBoxLayout(user_card)
        url.setContentsMargins(10, 7, 10, 7)
        url.setSpacing(12)

        self.lbl_profile_big = QLabel(user_card)
        self.lbl_profile_big.setFixedSize(58, 58)
        self.lbl_profile_big.setStyleSheet("background: transparent; border: none;")
        url.addWidget(self.lbl_profile_big, alignment=Qt.AlignVCenter)

        col_user = QVBoxLayout()
        col_user.setSpacing(2)
        col_user.setContentsMargins(0, 0, 0, 0)

        self.in_nickname = QLineEdit(user_card)
        self.in_nickname.setAttribute(Qt.WA_StyledBackground, True)
        self.in_nickname.setText(self.engine.cfg.get("device_name", "My SuperMouse PC"))
        self.in_nickname.setPlaceholderText("Enter Device Name")
        self.in_nickname.setStyleSheet(
            "QLineEdit { background: transparent; border: none; color: #FFFFFF; font-size: 14.5px; font-weight: 700; "
            "font-family: 'Segoe UI Variable Display', sans-serif; padding: 0px; } "
            "QLineEdit:focus { color: #a3e635; }"
        )
        self.in_nickname.textChanged.connect(self._on_nickname_changed)
        col_user.addWidget(self.in_nickname)

        btn_edit = QPushButton("Edit", user_card)
        btn_edit.setCursor(Qt.PointingHandCursor)
        btn_edit.setFixedSize(36, 17)
        btn_edit.setStyleSheet(
            "QPushButton {"
            "  background: rgba(255, 255, 255, 0.06);"
            "  border: 1px solid rgba(255, 255, 255, 0.09);"
            "  border-radius: 4px;"
            "  color: #8E8E93;"
            "  font-size: 9.5px;"
            "  font-weight: 700;"
            "  font-family: 'Segoe UI Variable Display', sans-serif;"
            "  text-align: center;"
            "  padding: 0px;"
            "}"
            "QPushButton:hover {"
            "  background: rgba(255, 255, 255, 0.12);"
            "  color: #FFFFFF;"
            "  border-color: rgba(255, 255, 255, 0.2);"
            "}"
        )
        btn_edit.clicked.connect(lambda: (self.in_nickname.setFocus(), self.in_nickname.selectAll()))
        col_user.addWidget(btn_edit)

        url.addLayout(col_user, 1)

        dev_id = self.engine.cfg.get("device_id", "49281SMX")
        self.btn_copy_id = QPushButton(f"{dev_id}  ⧉", user_card)
        self.btn_copy_id.setCursor(Qt.PointingHandCursor)
        self.btn_copy_id.setToolTip("Click to copy Device ID")
        self.btn_copy_id.setFixedSize(108, 28)
        self._apply_id_button_idle_style(self.btn_copy_id)

        def _copy_id():
            cur_id = self.engine.cfg.get("device_id", "49281SMX")
            QApplication.clipboard().setText(cur_id)
            self.btn_copy_id.setText("COPIED!")
            self.btn_copy_id.setStyleSheet(
                "QPushButton { background: #a3e635; border: 1px solid #a3e635; border-radius: 6px; color: #040405; font-size: 11px; font-weight: 800; font-family: 'Segoe UI Variable Display', sans-serif; }"
            )
            QTimer.singleShot(3000, lambda: (
                self.btn_copy_id.setText(f"{self.engine.cfg.get('device_id', '49281SMX')}  ⧉"),
                self._apply_id_button_idle_style(self.btn_copy_id)
            ))
        self.btn_copy_id.clicked.connect(_copy_id)
        url.addWidget(self.btn_copy_id, alignment=Qt.AlignVCenter)
        b_lay.addWidget(user_card)

        # Hairline Divider
        div1 = QFrame(body)
        div1.setFixedHeight(1)
        div1.setStyleSheet("background-color: rgba(255, 255, 255, 0.07);")
        b_lay.addWidget(div1)

        # SECTION 2: AVATAR GRID (Enlarged 64x64, equal balanced 14px L/R, 8px T/B margins and 12px grid spacing)
        scroll_av = SmoothScrollArea(body)
        scroll_av.setFixedHeight(190)
        scroll_av.setWidgetResizable(True)

        av_wrap = QWidget()
        av_wrap.setStyleSheet("background: transparent;")
        grid_av = QGridLayout(av_wrap)
        grid_av.setContentsMargins(14, 8, 14, 8)
        grid_av.setSpacing(12)
        grid_av.setAlignment(Qt.AlignCenter)

        self.avatar_files = []
        if os.path.exists(AVATARS_DIR):
            self.avatar_files = sorted([f for f in os.listdir(AVATARS_DIR) if f.lower().endswith(('.jpg', '.jpeg', '.png'))])

        curr_file = self.engine.cfg.get("custom_avatar_file") or (self.avatar_files[0] if self.avatar_files else "")
        self.avatar_btns = []
        for idx, fname in enumerate(self.avatar_files):
            r = idx // 4
            c = idx % 4
            btn = AvatarCircleButton(fname, is_selected=(fname == curr_file), parent=av_wrap)
            btn.clicked.connect(lambda _, fn=fname: self._select_avatar_file(fn))
            grid_av.addWidget(btn, r, c, alignment=Qt.AlignCenter)
            self.avatar_btns.append(btn)

        scroll_av.setWidget(av_wrap)
        b_lay.addWidget(scroll_av)

        # SECTION 2b: 22 GRADIENT BORDERS (Enlarged 36x36 Vector Circles, fewer visible on screen, more on scroll)
        scroll_grad = SmoothHScrollArea(body)
        scroll_grad.setFixedHeight(46)
        scroll_grad.setWidgetResizable(True)

        grad_wrap = QWidget()
        grad_wrap.setStyleSheet("background: transparent;")
        gl = QHBoxLayout(grad_wrap)
        gl.setContentsMargins(8, 0, 8, 4)
        gl.setSpacing(10)

        curr_gidx = int(self.engine.cfg.get("avatar_gradient_idx", 0))
        self.grad_btns = []
        for g_idx, (g_name, g_stops) in enumerate(GRADIENT_PRESETS):
            g_btn = GradientSwatchButton(g_idx, g_name, g_stops, is_selected=(g_idx == curr_gidx), parent=grad_wrap)
            g_btn.clicked.connect(lambda _, gi=g_idx: self._select_gradient(gi))
            gl.addWidget(g_btn)
            self.grad_btns.append((g_idx, g_btn))

        scroll_grad.setWidget(grad_wrap)
        b_lay.addWidget(scroll_grad)

        # Hairline Divider
        div2 = QFrame(body)
        div2.setFixedHeight(1)
        div2.setStyleSheet("background-color: rgba(255, 255, 255, 0.07);")
        b_lay.addWidget(div2)

        # SECTION 3: SHARED SETTINGS CONTAINER (Houses both the Permission Toggle AND Storage Location)
        card_actions = QWidget(body)
        card_actions.setFixedHeight(74)
        card_actions.setAttribute(Qt.WA_StyledBackground, True)
        card_actions.setStyleSheet(
            "QWidget {"
            "  background: rgba(255, 255, 255, 0.035);"
            "  border: 1px solid rgba(255, 255, 255, 0.07);"
            "  border-radius: 12px;"
            "}"
        )
        cal = QVBoxLayout(card_actions)
        cal.setContentsMargins(12, 6, 12, 6)
        cal.setSpacing(6)

        # Top row: Prominent iOS Toggle Setting
        t_row = QWidget(card_actions)
        t_row.setFixedHeight(28)
        t_row.setStyleSheet("background: transparent; border: none;")
        trl = QHBoxLayout(t_row)
        trl.setContentsMargins(0, 0, 0, 0)
        trl.setSpacing(10)

        lbl_perm = QLabel("Ask permission for every beam session", t_row)
        lbl_perm.setStyleSheet("color: #FFFFFF; font-size: 11px; font-weight: 600; font-family: 'Segoe UI Variable Text', sans-serif; background: transparent; border: none;")
        trl.addWidget(lbl_perm, 1, alignment=Qt.AlignVCenter)

        cur_perm = bool(self.engine.cfg.get("ask_beam_permission", False))
        self.switch_perm = CleanToggleSwitch(checked=cur_perm, parent=t_row)
        def _on_toggle_perm():
            self.engine.cfg["ask_beam_permission"] = self.switch_perm.isChecked()
            _save_config(self.engine.cfg)
            self.switch_perm.update()
        self.switch_perm.clicked.connect(_on_toggle_perm)
        trl.addWidget(self.switch_perm, alignment=Qt.AlignVCenter)
        cal.addWidget(t_row)

        # Hairline separator between toggle and storage
        c_div = QFrame(card_actions)
        c_div.setFixedHeight(1)
        c_div.setStyleSheet("background-color: rgba(255, 255, 255, 0.06); border: none;")
        cal.addWidget(c_div)

        # Bottom row: Storage Directory with separate normal Change and Open buttons
        s_row = QWidget(card_actions)
        s_row.setFixedHeight(28)
        s_row.setStyleSheet("background: transparent; border: none;")
        srl = QHBoxLayout(s_row)
        srl.setContentsMargins(0, 0, 0, 0)
        srl.setSpacing(8)

        lbl_folder_ico = QLabel(s_row)
        lbl_folder_ico.setFixedSize(16, 16)
        lbl_folder_ico.setStyleSheet("background: transparent; border: none;")
        f_pix = QPixmap(32, 32)
        f_pix.fill(Qt.transparent)
        fp = QPainter(f_pix)
        fp.setRenderHint(QPainter.Antialiasing, True)
        fp.setPen(QPen(QColor("#a3e635"), 2.2))
        fp.setBrush(Qt.NoBrush)
        f_path = QPainterPath()
        f_path.moveTo(3, 7)
        f_path.lineTo(12, 7)
        f_path.lineTo(15, 11)
        f_path.lineTo(29, 11)
        f_path.lineTo(29, 27)
        f_path.lineTo(3, 27)
        f_path.closeSubpath()
        fp.drawPath(f_path)
        fp.end()
        f_pix.setDevicePixelRatio(2.0)
        lbl_folder_ico.setPixmap(f_pix)
        srl.addWidget(lbl_folder_ico, alignment=Qt.AlignVCenter)

        cur_dir = getattr(self.engine, "save_dir", DEFAULT_SAVE_DIR)
        self.lbl_path = DirectoryHoverLabel(cur_dir, s_row)
        srl.addWidget(self.lbl_path, 1, alignment=Qt.AlignVCenter)

        # Normal Change and Open buttons with tight 5px spacing between them
        btn_box = QWidget(s_row)
        btn_box.setFixedHeight(24)
        btn_box.setStyleSheet("background: transparent; border: none;")
        bbl = QHBoxLayout(btn_box)
        bbl.setContentsMargins(0, 0, 0, 0)
        bbl.setSpacing(5)

        normal_btn_style = (
            "QPushButton {"
            "  background: rgba(255, 255, 255, 0.06);"
            "  color: #E4E4E7;"
            "  border: 1px solid rgba(255, 255, 255, 0.12);"
            "  border-radius: 6px;"
            "  font-size: 10.5px;"
            "  font-weight: 700;"
            "  padding: 0 9px;"
            "  font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif;"
            "}"
            "QPushButton:hover {"
            "  background: rgba(163, 230, 53, 0.14);"
            "  color: #a3e635;"
            "  border-color: rgba(163, 230, 53, 0.4);"
            "}"
            "QPushButton:pressed {"
            "  background: rgba(163, 230, 53, 0.22);"
            "}"
        )

        btn_change = QPushButton("Change", btn_box)
        btn_change.setFixedHeight(24)
        btn_change.setCursor(Qt.PointingHandCursor)
        btn_change.setStyleSheet(normal_btn_style)
        btn_change.clicked.connect(self._change_folder)
        bbl.addWidget(btn_change)

        btn_open = QPushButton("Open", btn_box)
        btn_open.setFixedHeight(24)
        btn_open.setCursor(Qt.PointingHandCursor)
        btn_open.setStyleSheet(normal_btn_style)
        btn_open.clicked.connect(self._open_folder)
        bbl.addWidget(btn_open)

        srl.addWidget(btn_box, alignment=Qt.AlignVCenter)
        cal.addWidget(s_row)

        b_lay.addWidget(card_actions)

        # SECTION 4: 'WHAT'S!' - EXACTLY ONE NEAT PARAGRAPH (Cleanly positioned at bottom)
        cl_box = QWidget(body)
        cl_box.setFixedHeight(64)
        cl_box.setStyleSheet("background: transparent;")
        cbl = QVBoxLayout(cl_box)
        cbl.setContentsMargins(2, 2, 2, 0)
        cbl.setSpacing(3)

        cl_hdr = QLabel("WHAT'S!", cl_box)
        cl_hdr.setStyleSheet("color: #a3e635; font-size: 10.5px; font-weight: 900; letter-spacing: 1.2px; font-family: 'Segoe UI Variable Display', sans-serif;")
        cbl.addWidget(cl_hdr)

        cl_para = QLabel(
            "Super Share v1.0 delivers instant in-signal peer discovery with live proximity tracking, custom high-resolution profile avatars, customizable dynamic gradient border presets, reliable vibe requests with queue management, and ultra-smooth kinetic navigation across all menus.",
            cl_box
        )
        cl_para.setWordWrap(True)
        cl_para.setStyleSheet("color: #A1A1AA; font-size: 10px; font-weight: 500; font-family: 'Segoe UI Variable Text', sans-serif; line-height: 1.35; background: transparent; border: none;")
        cbl.addWidget(cl_para)

        b_lay.addWidget(cl_box)

        root.addWidget(body, 1)

        self._refresh_profile_preview()
        self._update_avatar_btn_styles()

    def _refresh_profile_preview(self):
        curr_file = self.engine.cfg.get("custom_avatar_file")
        if not curr_file and self.avatar_files:
            curr_file = self.avatar_files[0]
            self.engine.cfg["custom_avatar_file"] = curr_file
            _save_config(self.engine.cfg)

        g_idx = int(self.engine.cfg.get("avatar_gradient_idx", 0))
        pix = get_avatar_pixmap(curr_file or 1, size=58, gradient_idx=g_idx, with_border=True)
        self.lbl_profile_big.setPixmap(pix)

    def _select_avatar_file(self, fname: str):
        self.engine.cfg["custom_avatar_file"] = fname
        if fname in self.avatar_files:
            self.engine.cfg["avatar_id"] = self.avatar_files.index(fname) + 1
        _save_config(self.engine.cfg)
        self._refresh_profile_preview()
        self._update_avatar_btn_styles()
        try:
            self.engine.broadcast_now()
        except Exception:
            pass
        if callable(self.on_settings_changed):
            try:
                self.on_settings_changed()
            except Exception:
                pass

    def _select_gradient(self, g_idx: int):
        self.engine.cfg["avatar_gradient_idx"] = g_idx
        _save_config(self.engine.cfg)
        self._refresh_profile_preview()
        self._update_avatar_btn_styles()
        try:
            self.engine.broadcast_now()
        except Exception:
            pass
        if callable(self.on_settings_changed):
            try:
                self.on_settings_changed()
            except Exception:
                pass

    def _update_avatar_btn_styles(self):
        curr_file = self.engine.cfg.get("custom_avatar_file")
        g_idx = int(self.engine.cfg.get("avatar_gradient_idx", 0))

        for btn in self.avatar_btns:
            btn.set_selected(btn.fname == curr_file)

        for gi, g_btn in self.grad_btns:
            g_btn.set_selected(gi == g_idx)

    def _on_nickname_changed(self, text: str):
        clean = text.strip()
        if clean:
            self.engine.cfg["device_name"] = clean
            _save_config(self.engine.cfg)
            if callable(self.on_settings_changed):
                try:
                    self.on_settings_changed()
                except Exception:
                    pass

    def _change_folder(self):
        chosen = QFileDialog.getExistingDirectory(self, "Select SuperShare Storage Folder", self.engine.save_dir)
        if chosen and os.path.exists(chosen):
            self.engine.save_dir = chosen
            self.engine.cfg["save_dir"] = chosen
            _save_config(self.engine.cfg)
            self.lbl_path.update_path(chosen)

    def _open_folder(self):
        save_dir = getattr(self.engine, "save_dir", DEFAULT_SAVE_DIR)
        os.makedirs(save_dir, exist_ok=True)
        os.startfile(save_dir)

    def _go_back(self):
        target = getattr(self, "on_back_to_share_menu", None) or self.on_back_to_menu
        if callable(target):
            self.switch_out_asmr_animation(on_finished=target)
        else:
            self.hide()

    def _go_menu(self):
        target = getattr(self, "on_main_menu", None) or self.on_back_to_menu
        if callable(target):
            self.switch_out_asmr_animation(on_finished=target)
        else:
            self.hide()

    def switch_out_asmr_animation(self, on_finished=None):
        anim = QPropertyAnimation(self, b"windowOpacity", self)
        anim.setDuration(110)
        anim.setStartValue(self.windowOpacity())
        anim.setEndValue(0.0)
        anim.setEasingCurve(QEasingCurve.OutCubic)

        def _done():
            self.hide()
            self.setWindowOpacity(1.0)
            if on_finished:
                on_finished()

        anim.finished.connect(_done)
        anim.start()

    def open_window(self):
        self._refresh_profile_preview()
        self._update_avatar_btn_styles()
        self.lbl_path.update_path(getattr(self.engine, "save_dir", DEFAULT_SAVE_DIR))
        self.in_nickname.setText(self.engine.cfg.get("device_name", "My SuperMouse PC"))
        self.switch_perm.setChecked(bool(self.engine.cfg.get("ask_beam_permission", False)))
        self.switch_perm.update()
        self._center_or_cursor()
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.activateWindow()
        self._anim = QPropertyAnimation(self, b"windowOpacity", self)
        self._anim.setDuration(160)
        self._anim.setStartValue(0.0)
        self._anim.setEndValue(1.0)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)
        self._anim.start()

    def open_asmr_switch(self):
        self.open_window()

    def _center_or_cursor(self):
        scr = (QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()).availableGeometry()
        w, h = self.width(), self.height()
        tx = scr.center().x() - w // 2
        ty = scr.center().y() - h // 2
        self.setGeometry(tx, ty, w, h)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._dragging = True
            self._drag_offset = e.globalPosition().toPoint() - self.frameGeometry().topLeft()
            e.accept()

    def mouseMoveEvent(self, e):
        if self._dragging and e.buttons() & Qt.LeftButton:
            self.move(e.globalPosition().toPoint() - self._drag_offset)
            e.accept()

    def mouseReleaseEvent(self, e):
        self._dragging = False

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = float(self.width()), float(self.height())
        rect = QRectF(0.5, 0.5, w - 1.0, h - 1.0)
        card = QPainterPath()
        card.addRoundedRect(rect, 16.0, 16.0)
        p.fillPath(card, QColor(4, 4, 5, 252))
        p.setPen(QPen(QColor(163, 230, 53, 90), 1.0))
        p.drawPath(card)
        p.end()
