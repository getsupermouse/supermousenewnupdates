# -*- coding: utf-8 -*-
from .common import *
class _PinLightboxDialog(QDialog):
    """Pure #040405 enlarged preview viewer when clicking any Pin inside MY BOX."""

    def __init__(self, image_path, title_text, parent=None):
        super().__init__(parent, Qt.FramelessWindowHint | Qt.Dialog | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.image_path = image_path
        self._pix = QPixmap(image_path)

        scr = (QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()).availableGeometry()
        max_w = min(int(scr.width() * 0.78), max(480, self._pix.width() + 48))
        max_h = min(int(scr.height() * 0.80), max(350, self._pix.height() + 124))
        self.resize(max_w, max_h)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 14, 16, 14)
        lay.setSpacing(10)

        hdr = QHBoxLayout()
        lbl = QLabel(title_text, self)
        lbl.setStyleSheet(
            "color: #F4F4F5; font-size: 13px; font-weight: 700; "
            "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; background: transparent;"
        )
        hdr.addWidget(lbl)
        hdr.addStretch()
        btn_x = _CloseCircleBtn("Close Preview", self)
        btn_x.clicked.connect(self.close)
        hdr.addWidget(btn_x)
        lay.addLayout(hdr)

        img_lbl = QLabel(self)
        img_lbl.setAlignment(Qt.AlignCenter)
        if not self._pix.isNull():
            dpr = _native_dpr(self)
            tw = int(round((max_w - 40) * dpr))
            th = int(round((max_h - 118) * dpr))
            src_img = self._pix.toImage()
            if src_img.width() > tw or src_img.height() > th:
                src_img = src_img.scaled(tw, th, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            scaled = QPixmap.fromImage(src_img)
            scaled.setDevicePixelRatio(dpr)
            img_lbl.setPixmap(scaled)
        img_lbl.setStyleSheet("background: #080809; border: 1px solid rgba(255,255,255,0.08); border-radius: 10px;")
        lay.addWidget(img_lbl, stretch=1)

        foot = QHBoxLayout()
        foot.setSpacing(8)
        foot.addStretch()
        b_copy = _ActionPillButton("Copy Image", _LUCIDE_PIN_ICONS["copy_fill"], primary=True, parent=self)
        b_copy.clicked.connect(lambda: (copy_pixmap_to_clipboard(self._pix, int(self.winId())), self.close()))
        b_save = _ActionPillButton("Save to Desktop", _LUCIDE_PIN_ICONS["save"], parent=self)
        b_save.clicked.connect(self._save_desktop)
        foot.addWidget(b_copy)
        foot.addWidget(b_save)
        lay.addLayout(foot)

    def _save_desktop(self):
        if not self._pix.isNull():
            out_fp = os.path.join(get_desktop_dir(), f"SuperSnap_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png")
            self._pix.save(out_fp, "PNG")
        self.close()

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.close()
        else:
            super().keyPressEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        rect = QRectF(0.6, 0.6, self.width() - 1.2, self.height() - 1.2)
        path = QPainterPath()
        path.addRoundedRect(rect, 14.0, 14.0)
        p.fillPath(path, QColor(4, 4, 5, 253))
        p.setPen(QPen(QColor(255, 255, 255, 34), 1.0))
        p.drawPath(path)
        p.end()


