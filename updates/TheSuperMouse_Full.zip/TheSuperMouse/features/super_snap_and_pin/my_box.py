# -*- coding: utf-8 -*-
"""
SUPER SNAP & PIN: MY BOX (SAVED SNAPS & SHOWCASE GALLERY)
=========================================================
ARCHITECTURAL MINDMAP & COMPONENT MAP:
  [1] Header Buttons & Triggers
      ├── _HeaderIconBtn: Unified borderless header icon (Back, Home, Open Folder, Close)
      └── _HeaderTakeSnapBtn: Quick 'Take Snap' header action button
  
  [2] View & Format Mode Switcher
      └── _FormatModeBar: 'Complete' (detailed cards) vs 'One-Line' (compact horizontal rows)

  [3] Horizontal Carousel Strip
      └── _HorizontalSnapStrip: Smooth mouse-wheel driven horizontal scrolling gallery

  [4] Tile Showcase Component
      └── _FramelessSnapTile: Individual card with crisp thumbnail, live rename inline, 
                               and hover action dock (Copy, Pin Lightbox, Delete)

  [5] MyBoxWindow (Main Gallery Window - 766x588)
      ├── Header: Logo + 'MY BOX' (Left), Snap Count + Take Snap + Folder + Back + Home + Close (Right)
      ├── Search Bar: Live ASMR search input with clear trigger
      ├── Grid/Strip Area: Dynamic tile instantiation & gallery layout
      └── Navigation & ASMR Transitions:
           ├── _go_back() -> Routes to Super Snap & Pin Submenu Hub (SuperClipboardWindow)
           ├── _go_menu() -> Routes to Quick Menu (at cursor)
           └── Smooth ASMR Switch & Pull animations
"""
from .common import *
from .pin_window import _PinLightboxDialog
from .take_snap import _SnipOverlay
class _MyBoxBrandTitle(QWidget):
    """Vector-crisp brand title: Logo (20px) + 'THE' (White) + 'MY BOX' (#FFFF00->#00FF85 gradient)."""
    def __init__(self, logo_pix=None, parent=None):
        super().__init__(parent)
        self.logo_pix = logo_pix
        self.setFixedHeight(30)
        self.setFixedWidth(280)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        bx = 0.0
        by_c = float(self.height()) * 0.5
        if self.logo_pix and not self.logo_pix.isNull():
            ldpr = max(1.0, float(self.logo_pix.devicePixelRatio() or 1.0))
            lw = self.logo_pix.width() / ldpr
            lh = self.logo_pix.height() / ldpr
            p.drawPixmap(int(round(bx)), int(round(by_c - lh * 0.5)), self.logo_pix)
            bx += lw + 8.0

        f_logo = QFont("Segoe UI Variable")
        f_logo.setStyleName("Display Bold")
        f_logo.setPointSizeF(11.4)
        f_logo.setLetterSpacing(QFont.AbsoluteSpacing, 0.35)
        f_logo.setHintingPreference(QFont.PreferNoHinting)

        probe = QPainterPath()
        probe.addText(0.0, 0.0, f_logo, "THE MY BOX")
        br = probe.boundingRect()
        baseline_y = by_c - (br.top() + br.height() * 0.5)

        p1 = QPainterPath()
        p1.addText(bx, baseline_y, f_logo, "THE")
        p.fillPath(p1, QColor("#FFFFFF"))

        w1 = p1.boundingRect().width()
        smx = bx + w1 + 5.5

        p2 = QPainterPath()
        p2.addText(smx, baseline_y, f_logo, "MY BOX")
        b2 = p2.boundingRect()
        g_sm = QLinearGradient(b2.left(), 0.0, b2.right(), 0.0)
        g_sm.setColorAt(0.0, QColor("#FFFF00"))
        g_sm.setColorAt(1.0, QColor("#00FF85"))
        p.fillPath(p2, g_sm)
        p.end()


class _HeaderIconBtn(CleanHeaderIconButton):
    """Unified borderless fixed-size header slot (invisible box at rest, crisp common icon)."""

    def __init__(self, icon_key, tip_text="", parent=None):
        super().__init__(icon_key=icon_key, tip_text=tip_text, box_size=32, icon_size=16, on_press_tick=_play_asmr_tick, parent=parent)


class _HeaderTakeSnapBtn(QWidget):
    """Refined obsidian Take Snap pill with common Lucide scissors icon + crisp label."""
    clicked = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(104, 30)
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip("Take a new Snap right away")
        self._h = 0.0
        self._t = 0.0
        self._press = 0.0
        self._tm = QTimer(self)
        self._tm.setInterval(16)
        self._tm.timeout.connect(self._step)

    def _step(self):
        act = False
        if abs(self._t - self._h) >= 0.008:
            self._h += (self._t - self._h) * 0.25
            act = True
        else:
            self._h = self._t
        if self._press > 0.01:
            self._press *= 0.80
            act = True
        else:
            self._press = 0.0
        self.update()
        if not act:
            self._tm.stop()

    def enterEvent(self, e):
        self._t = 1.0
        if not self._tm.isActive():
            self._tm.start()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._t = 0.0
        if not self._tm.isActive():
            self._tm.start()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            _play_asmr_tick()
            self._press = 1.0
            if not self._tm.isActive():
                self._tm.start()
            self.clicked.emit()
            e.accept()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        w, h = float(self.width()), float(self.height())
        hv = self._h
        sc = 1.0 - self._press * 0.04
        p.save()
        p.translate(w * 0.5, h * 0.5)
        p.scale(sc, sc)
        p.translate(-w * 0.5, -h * 0.5)

        path = QPainterPath()
        path.addRoundedRect(QRectF(0.5, 0.5, w - 1.0, h - 1.0), 8.5, 8.5)
        p.fillPath(path, QColor(int(18 + hv * 10), int(19 + hv * 12), int(23 + hv * 8), 255))
        rim_col = QColor(
            int(255 * (1.0 - hv) + 163 * hv),
            int(255 * (1.0 - hv) + 230 * hv),
            int(255 * (1.0 - hv) + 53 * hv),
            int(26 + hv * 120),
        )
        p.setPen(QPen(rim_col, 1.0))
        p.drawPath(path)

        pix = _render_lucide_pix("take_snap", "#a3e635" if hv > 0.2 else "#E4E4E7", 15, dpr=_native_dpr(self))
        p.drawPixmap(10, int(round((h - 15) * 0.5)), pix)

        f = QFont("Segoe UI Variable")
        f.setStyleName("Text Semibold")
        f.setPointSizeF(8.8)
        _draw_crisp_text(
            p, QRectF(30.0, 0.0, w - 38.0, h), False, f,
            QColor("#FFFFFF") if hv > 0.3 else QColor("#E4E4E7"), "Take Snap",
        )
        p.restore()
        p.end()


class _FormatModeBar(QWidget):
    """
    Minimalist borderless view toggle (invisible icon slots, original 16px vector icons,
    subtle active indicator underline — zero boxy neon outlines!):
      - 'complete': Complete Show (grid view of all snaps nicely)
      - 'oneline':  One-Line Scroll (each date renders in one horizontal scrollable row)
    """
    mode_changed = Signal(str)

    def __init__(self, initial_mode="complete", parent=None):
        super().__init__(parent)
        self.mode = initial_mode
        self._hover = None
        self.setFixedSize(68, 34)
        self.setCursor(Qt.PointingHandCursor)
        self.setMouseTracking(True)

    def _rect_complete(self):
        return QRectF(0.0, 1.0, 32.0, 32.0)

    def _rect_oneline(self):
        return QRectF(36.0, 1.0, 32.0, 32.0)

    def mouseMoveEvent(self, e):
        pos = e.position()
        nh = "complete" if self._rect_complete().contains(pos) else ("oneline" if self._rect_oneline().contains(pos) else None)
        if nh != self._hover:
            self._hover = nh
            if nh == "complete":
                self.setToolTip("Complete Show — display all Snaps nicely")
            elif nh == "oneline":
                self.setToolTip("One-Line Scroll — horizontal row per date")
            self.update()

    def leaveEvent(self, e):
        self._hover = None
        self.update()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            pos = e.position()
            nm = "complete" if self._rect_complete().contains(pos) else ("oneline" if self._rect_oneline().contains(pos) else None)
            if nm and nm != self.mode:
                _play_asmr_tick()
                self.mode = nm
                self.update()
                self.mode_changed.emit(nm)
            e.accept()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        dpr = _native_dpr(self)
        for key, rect, ico in (
            ("complete", self._rect_complete(), "grid"),
            ("oneline", self._rect_oneline(), "oneline"),
        ):
            active = self.mode == key
            hov = self._hover == key
            if hov and not active:
                hp = QPainterPath()
                hp.addRoundedRect(rect.adjusted(2.0, 2.0, -2.0, -2.0), 8.0, 8.0)
                p.fillPath(hp, QColor(255, 255, 255, 16))
            col = "#FFFFFF" if active else ("#D4D4D8" if hov else "#71717A")
            pix = _render_lucide_pix(ico, col, 16, dpr=dpr)
            p.drawPixmap(int(round(rect.center().x() - 8.0)), int(round(rect.center().y() - 9.0)), pix)
            if active:
                bar = QPainterPath()
                bar.addRoundedRect(QRectF(rect.center().x() - 6.0, rect.bottom() - 4.0, 12.0, 2.0), 1.0, 1.0)
                p.fillPath(bar, QColor("#a3e635"))
        p.end()


class _HorizontalSnapStrip(QScrollArea):
    """Smooth wheel-enabled single-row horizontal container for One-Line Scroll format."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.NoFrame)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.setFixedHeight(208)
        self.setStyleSheet(SLIM_SCROLLBAR_QSS)
        self.inner = QWidget()
        self.row_lay = QHBoxLayout(self.inner)
        self.row_lay.setContentsMargins(0, 0, 0, 8)
        self.row_lay.setSpacing(18)
        self.row_lay.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        self.setWidget(self.inner)

    def wheelEvent(self, e):
        sb = self.horizontalScrollBar()
        if sb.maximum() > 0:
            delta = e.angleDelta().y() or e.angleDelta().x()
            sb.setValue(sb.value() - delta)
            e.accept()
            return
        super().wheelEvent(e)


class _FramelessSnapTile(QWidget):
    """
    Open-Canvas Native-DPR Sharp Showcase Tile inside MY BOX (ZERO outer grey box container!):
      - Exact 1:1 native-DPR single-pass QImage sharp rounded thumbnail (zero 2x->1x blur)
      - Filled hover pill dock with Copy, SuperShare & Delete
      - Crisp '#X' snap number badge + logical editable name + filled pencil Edit button + timestamp
    """
    clicked = Signal(str, str)
    copy_clicked = Signal(str)
    supershare_clicked = Signal(str)
    delete_clicked = Signal(str)
    renamed = Signal(str, str)

    TILE_W = 224
    IMG_H = 132
    TILE_H = 188

    def __init__(self, image_path, dt, snap_num, snap_name, title_label, parent=None):
        super().__init__(parent)
        self.image_path = image_path
        self.dt = dt
        self.snap_num = snap_num
        self.snap_name = snap_name
        self.title_label = title_label
        self.time_str = dt.strftime("%I:%M %p").lstrip("0")

        self.setFixedSize(self.TILE_W, self.TILE_H)
        self.setCursor(Qt.PointingHandCursor)
        self.setMouseTracking(True)

        self._h = 0.0
        self._target = 0.0
        self._hover_btn = None  # 'copy' | 'share' | 'delete' | 'edit' | None
        self._timer = QTimer(self)
        self._timer.setInterval(16)
        self._timer.timeout.connect(self._step)

        # Inline name editor (hidden until pencil clicked / double click on title)
        self._edit_box = QLineEdit(self)
        self._edit_box.setVisible(False)
        self._edit_box.setMaxLength(44)
        self._edit_box.setStyleSheet(
            "QLineEdit { background-color: #111610; color: #FFFFFF; border: 1px solid #a3e635; "
            "border-radius: 6px; padding: 1px 6px; font-size: 11px; font-weight: 600; "
            "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; }"
        )
        self._edit_box.textEdited.connect(lambda _t: _play_asmr_tick())
        self._edit_box.returnPressed.connect(self._commit_rename)
        self._edit_box.editingFinished.connect(self._commit_rename)

        # Native display DPR 1:1 thumbnail (avoids bilinear 2x -> 1x downsampling blur)
        self._dpr = _native_dpr(self)
        self._rendered_img = self._build_sharp_pixmap(image_path, self._dpr)

    def _build_sharp_pixmap(self, fp, dpr=1.0):
        src_img = QImage(fp)
        if src_img.isNull():
            return QPixmap()
        tw = max(1, int(round(self.TILE_W * dpr)))
        th = max(1, int(round(self.IMG_H * dpr)))
        out = QImage(tw, th, QImage.Format_ARGB32_Premultiplied)
        out.fill(QColor(8, 9, 11))

        sw, sh = src_img.width(), src_img.height()
        src_ratio = sw / max(1.0, float(sh))
        tgt_ratio = self.TILE_W / float(self.IMG_H)
        rel = src_ratio / tgt_ratio
        p = QPainter(out)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        if sw <= tw and sh <= th and 0.65 <= rel <= 1.85:
            # Small snap: draw cleanly centered at 1:1 without upscaling blur
            dx = (tw - sw) // 2
            dy = (th - sh) // 2
            p.drawImage(dx, dy, src_img)
        elif 0.62 <= rel <= 1.9:
            scaled = src_img.scaled(tw, th, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
            sx = max(0, (scaled.width() - tw) // 2)
            sy = max(0, (scaled.height() - th) // 2)
            p.drawImage(0, 0, scaled, sx, sy, tw, th)
        else:
            scaled = src_img.scaled(tw, th, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            dx = (tw - scaled.width()) // 2
            dy = (th - scaled.height()) // 2
            p.drawImage(dx, dy, scaled)
        p.end()

        pix = QPixmap.fromImage(out)
        pix.setDevicePixelRatio(dpr)
        return pix

    def _action_rects(self):
        # Strictly placed in the BOTTOM metadata strip below the image (never overlapping image!)
        bw, bh, gap = 26.0, 24.0, 2.0
        x0 = float(self.width()) - (bw * 3.0 + gap * 2.0)
        y0 = float(self.IMG_H) + 30.0
        return (
            QRectF(x0, y0, bw, bh),
            QRectF(x0 + bw + gap, y0, bw, bh),
            QRectF(x0 + (bw + gap) * 2.0, y0, bw, bh),
        )

    def _rect_edit(self):
        return QRectF(self.width() - 24.0, float(self.IMG_H) + 6.0, 24.0, 22.0)

    def _begin_rename(self):
        self._edit_box.setGeometry(40, self.IMG_H + 6, self.width() - 44, 22)
        self._edit_box.setText(self.snap_name)
        self._edit_box.setVisible(True)
        self._edit_box.selectAll()
        self._edit_box.setFocus()

    def _commit_rename(self):
        if not self._edit_box.isVisible():
            return
        new_txt = self._edit_box.text().strip()
        self._edit_box.setVisible(False)
        if new_txt and new_txt != self.snap_name:
            self.snap_name = new_txt
            rename_snap_meta(self.image_path, new_txt)
            self.title_label = f"#{self.snap_num} · {new_txt}"
            self.renamed.emit(self.image_path, new_txt)
        self.update()

    def _step(self):
        if abs(self._target - self._h) < 0.008:
            self._h = self._target
            self._timer.stop()
        else:
            self._h += (self._target - self._h) * 0.25
        self.update()

    def enterEvent(self, e):
        self._target = 1.0
        if not self._timer.isActive():
            self._timer.start()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._target = 0.0
        self._hover_btn = None
        if not self._timer.isActive():
            self._timer.start()
        super().leaveEvent(e)

    def mouseMoveEvent(self, e):
        pos = e.position()
        nh = None
        if self._rect_edit().contains(pos):
            nh = "edit"
        elif self._h > 0.22 and pos.y() >= self.IMG_H:
            rc, rs, rd = self._action_rects()
            if rc.contains(pos):
                nh = "copy"
            elif rs.contains(pos):
                nh = "share"
            elif rd.contains(pos):
                nh = "delete"
        if nh != self._hover_btn:
            self._hover_btn = nh
            tips = {
                "copy": "Copy Snap",
                "share": "SuperShare (Coming Soon)",
                "delete": "Delete Snap",
                "edit": "Rename Snap",
            }
            self.setToolTip(tips.get(nh, ""))
            self.update()
        super().mouseMoveEvent(e)

    def mouseDoubleClickEvent(self, e):
        if e.button() == Qt.LeftButton and e.position().y() >= self.IMG_H:
            self._begin_rename()
            e.accept()
            return
        super().mouseDoubleClickEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            pos = e.position()
            if self._rect_edit().contains(pos):
                self._begin_rename()
                e.accept()
                return
            if self._h > 0.18 and pos.y() >= self.IMG_H:
                rc, rs, rd = self._action_rects()
                if rc.contains(pos):
                    _play_asmr_tick()
                    self.copy_clicked.emit(self.image_path)
                    e.accept()
                    return
                if rs.contains(pos):
                    _play_asmr_tick()
                    self.supershare_clicked.emit(self.image_path)
                    e.accept()
                    return
                if rd.contains(pos):
                    _play_asmr_tick()
                    self.delete_clicked.emit(self.image_path)
                    e.accept()
                    return
            if pos.y() <= self.IMG_H:
                self.clicked.emit(self.image_path, self.title_label)
                e.accept()
                return

    def paintEvent(self, e):
        cur_dpr = _native_dpr(self)
        if abs(cur_dpr - self._dpr) > 0.05:
            self._dpr = cur_dpr
            self._rendered_img = self._build_sharp_pixmap(self.image_path, cur_dpr)

        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        w = float(self.width())
        hv = self._h

        # 1. Pure Unobstructed Crystal-Clear Image Surface (ZERO overlay icons, ZERO neon box!)
        img_rect = QRectF(0.5, 0.5, w - 1.0, self.IMG_H - 1.0)
        img_path = QPainterPath()
        img_path.addRoundedRect(img_rect, 11.0, 11.0)

        p.save()
        p.setClipPath(img_path)
        if not self._rendered_img.isNull():
            p.drawPixmap(0, 0, self._rendered_img)
        p.restore()

        # Cyber-lime hover border perimeter
        rim_col = QColor(163, 230, 53, int(150 * hv)) if hv > 0.1 else QColor(255, 255, 255, 20)
        p.setPen(QPen(rim_col, 1.0))
        p.drawPath(img_path)

        # 2. Restrained Neutral Index Tag ('#4' calm slate/zinc — zero bright green glare!)
        num_txt = f"#{self.snap_num}"
        f_num = QFont("Segoe UI Variable Text", 8)
        f_num.setStyleName("Text Semibold")
        f_num.setStyleStrategy(QFont.PreferQuality)
        num_w = max(28.0, float(QFontMetrics(f_num).horizontalAdvance(num_txt)) + 10.0)
        nr = QRectF(1.0, float(self.IMG_H) + 8.0, num_w, 17.0)
        np = QPainterPath()
        np.addRoundedRect(nr, 4.5, 4.5)
        p.fillPath(np, QColor(255, 255, 255, int(11 + hv * 11)))
        p.setPen(QPen(QColor(255, 255, 255, int(18 + hv * 24)), 0.75))
        p.drawPath(np)
        _draw_crisp_text(p, nr, True, f_num, QColor("#D4D4D8") if hv > 0.35 else QColor("#8E94A0"), num_txt)

        if not self._edit_box.isVisible():
            f_name = QFont("Segoe UI Variable Text", 9)
            f_name.setStyleName("Text Semibold")
            f_name.setStyleStrategy(QFont.PreferQuality)
            name_x = int(round(nr.right() + 7))
            name_rect = QRectF(float(name_x), float(self.IMG_H) + 6.5, w - name_x - 26.0, 20.0)
            elided = QFontMetrics(f_name).elidedText(self.snap_name, Qt.ElideRight, int(name_rect.width()))
            _draw_crisp_text(
                p, name_rect, False, f_name,
                QColor("#FFFFFF") if hv > 0.3 else QColor("#F4F4F5"), elided,
            )

            # Borderless Pencil Rename Icon inside invisible 24x22 hit-box
            er = self._rect_edit()
            ecol = "#FFFFFF" if self._hover_btn == "edit" else ("#B4BAC5" if hv > 0.25 else "#6E737D")
            epix = _render_lucide_pix("pencil", ecol, 13, dpr=cur_dpr)
            p.drawPixmap(int(round(er.center().x() - 6.5)), int(round(er.center().y() - 6.5)), epix)

        # 3. Bottom Strip Below Image: Calm Timestamp Left + Hover Action Icons Right
        f_time = QFont("Segoe UI Variable Text", 8)
        f_time.setStyleName("Text Semibold")
        f_time.setStyleStrategy(QFont.PreferQuality)
        _draw_crisp_text(
            p, QRectF(2.0, float(self.IMG_H) + 32.0, w - 92.0, 18.0), False, f_time,
            QColor("#9CA3AF") if hv > 0.3 else QColor("#686D76"), self.time_str,
        )

        if hv > 0.02:
            p.save()
            p.setOpacity(hv)
            rc, rs, rd = self._action_rects()
            for key, rect, ico, col_idle, col_hov in (
                ("copy",   rc, "copy",       "#9CA3AF", "#a3e635"),
                ("share",  rs, "supershare", "#9CA3AF", "#FFFFFF"),
                ("delete", rd, "trash",      "#9CA3AF", "#F87171"),
            ):
                active = self._hover_btn == key
                col = col_hov if active else col_idle
                pix = _render_lucide_pix(ico, col, 14, dpr=cur_dpr)
                p.drawPixmap(int(round(rect.center().x() - 7.0)), int(round(rect.center().y() - 7.0)), pix)
            p.restore()
        p.end()


class MyBoxWindow(QWidget):
    """
    Sharp Pure-Black 'MY BOX' Showcase Window:
      - Header navigation: Back, Main Menu, vector 'MY BOX' brand, Take Snap, '{n} SNAP's', Close X
      - Dynamic real-time Search Bar + Icon-Only Format Switcher (Complete Show vs One-Line Scroll)
      - Frameless sharp images with '#XXXX' logical snap number, inline pencil rename & hover dock (Copy/SuperShare/Delete)
    """

    def __init__(
        self,
        status_popup=None,
        on_count_changed=None,
        on_back=None,
        on_main_menu=None,
        on_take_snap=None,
        parent=None,
    ):
        super().__init__(parent)
        self.status_popup = status_popup or _StatusPopup()
        self.on_count_changed = on_count_changed
        self.on_back = on_back
        self.on_main_menu = on_main_menu
        self.on_take_snap = on_take_snap
        self.view_mode = "complete"  # 'complete' | 'oneline'

        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Window | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.resize(766, 588)
        from ui_theme import apply_window_identity
        apply_window_identity(self, "TheSuperMouse - My Box")

        ensure_box_dir()
        self._dragging = False
        self._drag_offset = QPoint()

        base_assets = os.path.join(BASE_DIR, "thesupermouse", "assets")
        logo_fp = os.path.join(base_assets, "supermouse_app_logo_cropped.png")
        if not os.path.exists(logo_fp):
            logo_fp = os.path.join(base_assets, "supermouse_app_logo_trans.png")
        self._raw_logo = QImage(logo_fp) if os.path.exists(logo_fp) else None
        if self._raw_logo and not self._raw_logo.isNull():
            ldpr = _native_dpr(self)
            l_img = self._raw_logo.scaledToHeight(max(20, int(round(20 * ldpr))), Qt.SmoothTransformation)
            self.logo_pix = QPixmap.fromImage(l_img)
            self.logo_pix.setDevicePixelRatio(ldpr)
        else:
            self.logo_pix = None

        self._build_ui()
        self.refresh_gallery()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # 1. Header Navigation Bar (Brand on left, tools & navigation on right, Cross last!)
        header = QWidget(self)
        header.setFixedHeight(54)
        header.setCursor(Qt.OpenHandCursor)
        hdr = QHBoxLayout(header)
        hdr.setContentsMargins(16, 0, 14, 0)
        hdr.setSpacing(4)

        self.brand_title = _MyBoxBrandTitle(self.logo_pix, header)
        hdr.addWidget(self.brand_title, alignment=Qt.AlignVCenter)

        hdr.addStretch(1)

        self.lbl_total = QLabel("0 Snaps", header)
        self.lbl_total.setStyleSheet(
            "color: #848A95; background: transparent; border: none; "
            "padding: 2px 6px; font-size: 11px; font-weight: 600; "
            "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        hdr.addWidget(self.lbl_total, alignment=Qt.AlignVCenter)
        hdr.addSpacing(2)

        self.btn_take_snap = _HeaderTakeSnapBtn(header)
        self.btn_take_snap.clicked.connect(self._trigger_take_snap)
        hdr.addWidget(self.btn_take_snap, alignment=Qt.AlignVCenter)
        hdr.addSpacing(2)

        self.btn_dir = _HeaderIconBtn("folder", "Open Folder in Explorer", header)
        self.btn_dir.clicked.connect(lambda: os.startfile(ensure_box_dir()))
        hdr.addWidget(self.btn_dir, alignment=Qt.AlignVCenter)
        hdr.addSpacing(2)

        self.btn_back = _HeaderIconBtn("back", "Back", header)
        self.btn_back.clicked.connect(self._go_back)
        hdr.addWidget(self.btn_back, alignment=Qt.AlignVCenter)

        self.btn_menu = _HeaderIconBtn("home", "Main Menu", header)
        self.btn_menu.clicked.connect(self._go_main_menu)
        hdr.addWidget(self.btn_menu, alignment=Qt.AlignVCenter)

        self.btn_close = _CloseCircleBtn("Close My Box", header)
        self.btn_close.clicked.connect(self.close_with_pull_animation)
        hdr.addWidget(self.btn_close, alignment=Qt.AlignVCenter)
        root.addWidget(header)

        # 2. Search + Borderless View Mode Icons Row
        ctrl_wrap = QWidget(self)
        ctrl_wrap.setFixedHeight(50)
        cw_lay = QHBoxLayout(ctrl_wrap)
        cw_lay.setContentsMargins(18, 4, 18, 10)
        cw_lay.setSpacing(10)

        self.search_box = QFrame(ctrl_wrap)
        self.search_box.setFixedHeight(38)
        self.search_box.setAttribute(Qt.WA_StyledBackground, True)
        self.search_box.setStyleSheet(
            "QFrame { "
            "  background: #0E1013; "
            "  border: 1px solid rgba(255, 255, 255, 0.08); "
            "  border-radius: 19px; "
            "} "
            "QFrame:focus-within { "
            "  border-color: rgba(163, 230, 53, 0.55); "
            "}"
        )
        sb_lay = QHBoxLayout(self.search_box)
        sb_lay.setContentsMargins(4, 0, 8, 0)
        sb_lay.setSpacing(8)

        # Device Hub style circular green badge at start (left) with crisp dark search icon
        self.search_circle = QLabel(self.search_box)
        self.search_circle.setFixedSize(30, 30)
        self.search_circle.setAlignment(Qt.AlignCenter)
        self.search_circle.setStyleSheet("background-color: #a3e635; border-radius: 15px; border: none;")
        s_pix = _render_lucide_pix("search", "#040405", 14, dpr=_native_dpr(self))
        self.search_circle.setPixmap(s_pix)
        sb_lay.addWidget(self.search_circle, alignment=Qt.AlignVCenter)

        self.search_input = QLineEdit(self.search_box)
        self.search_input.setAttribute(Qt.WA_StyledBackground, True)
        self.search_input.setPlaceholderText("Search Snaps by name, #number, Today, Yesterday...")
        f_in = QFont("Segoe UI Variable Text", 9)
        f_in.setStyleStrategy(QFont.PreferQuality)
        self.search_input.setFont(f_in)
        self.search_input.setStyleSheet(
            "QLineEdit { "
            "  background: transparent; "
            "  border: none; "
            "  color: #FFFFFF; "
            "  font-size: 11.5px; "
            "  font-weight: 600; "
            "  font-family: 'Segoe UI Variable Text', 'Segoe UI', sans-serif; "
            "} "
            "QLineEdit::placeholder { "
            "  color: #A1A1AA; "
            "  font-weight: 500; "
            "}"
        )
        self.search_input.textEdited.connect(lambda _t: _play_asmr_tick())
        self.search_input.textChanged.connect(self._on_search_changed)
        sb_lay.addWidget(self.search_input, stretch=1)

        self.btn_clear_search = QPushButton("", self.search_box)
        self.btn_clear_search.setFixedSize(22, 22)
        self.btn_clear_search.setIcon(QIcon(_render_lucide_pix("close", "#A1A7B3", 12, dpr=_native_dpr(self))))
        self.btn_clear_search.setIconSize(QSize(12, 12))
        self.btn_clear_search.setCursor(Qt.PointingHandCursor)
        self.btn_clear_search.setVisible(False)
        self.btn_clear_search.setStyleSheet(
            "QPushButton { background: rgba(255, 255, 255, 0.08); border: none; border-radius: 11px; } "
            "QPushButton:hover { background: rgba(255, 255, 255, 0.18); }"
        )
        self.btn_clear_search.clicked.connect(self.search_input.clear)
        sb_lay.addWidget(self.btn_clear_search, alignment=Qt.AlignVCenter)

        cw_lay.addWidget(self.search_box, stretch=1)

        self.format_bar = _FormatModeBar(initial_mode=self.view_mode, parent=ctrl_wrap)
        self.format_bar.mode_changed.connect(self._on_mode_changed)
        cw_lay.addWidget(self.format_bar)
        root.addWidget(ctrl_wrap)

        div = QFrame(self)
        div.setFixedHeight(1)
        div.setStyleSheet("background-color: rgba(255, 255, 255, 0.06); margin: 0px 18px;")
        root.addWidget(div)

        # 3. Date Showcase Scroll Canvas (Slim Translucent Pill Scrollbar)
        self.scroll = QScrollArea(self)
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll.setStyleSheet(SLIM_SCROLLBAR_QSS)
        self.content = QWidget()
        self.content_lay = QVBoxLayout(self.content)
        self.content_lay.setContentsMargins(18, 14, 18, 18)
        self.content_lay.setSpacing(24)
        self.content_lay.setAlignment(Qt.AlignTop)
        self.scroll.setWidget(self.content)
        root.addWidget(self.scroll, stretch=1)

    def _go_back(self):
        if callable(self.on_back):
            self.switch_out_asmr_animation(on_finished=self.on_back)
        else:
            self.close_with_pull_animation()

    def _go_main_menu(self):
        if callable(self.on_main_menu):
            self.switch_out_asmr_animation(on_finished=self.on_main_menu)
        elif callable(self.on_back):
            self.switch_out_asmr_animation(on_finished=self.on_back)
        else:
            self.close_with_pull_animation()

    def _trigger_take_snap(self):
        if callable(self.on_take_snap):
            self.switch_out_asmr_animation(on_finished=lambda: QTimer.singleShot(55, self.on_take_snap))

    def _on_mode_changed(self, mode):
        self.view_mode = mode
        self.refresh_gallery(self.search_input.text())

    def _on_search_changed(self, text):
        self.btn_clear_search.setVisible(bool(text.strip()))
        self.refresh_gallery(text)

    @staticmethod
    def _group_label_for_dt(dt, now_dt=None):
        now_dt = now_dt or datetime.now()
        d = dt.date()
        today = now_dt.date()
        yesterday = today - timedelta(days=1)
        if d == today:
            return "Today"
        if d == yesterday:
            return "Yesterday"
        return dt.strftime("%b %d, %Y")

    def _fit_window_height_for_complete(self, groups, group_map):
        scr = (QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()).availableGeometry()
        max_h = int(scr.height() * 0.85)
        if not groups:
            target_h = 440
        elif self.view_mode == "oneline":
            target_h = min(max_h, max(440, 126 + len(groups) * 234))
        else:
            total_h = 126
            for gl in groups:
                rows = max(1, (len(group_map[gl]) + 2) // 3)
                total_h += 38 + rows * (_FramelessSnapTile.TILE_H + 16)
            target_h = min(max_h, max(420, total_h))
        self.resize(766, 588)

    def refresh_gallery(self, query=""):
        while self.content_lay.count():
            it = self.content_lay.takeAt(0)
            w = it.widget()
            if w:
                w.setParent(None)
                w.deleteLater()

        entries = list_box_entries()
        self.lbl_total.setText(format_count_label(len(entries), "Snap", "Snaps"))

        q = (query or "").strip().lower()
        now_dt = datetime.now()
        groups = []
        group_map = {}

        for item in entries:
            dt = item["dt"]
            glabel = self._group_label_for_dt(dt, now_dt=now_dt)
            snum = item["snap_num"]
            sname = item["snap_name"]
            searchable = " ".join([
                glabel.lower(),
                dt.strftime("%B %d %Y %A %I:%M %p %H:%M").lower(),
                f"#{snum}",
                str(snum),
                sname.lower(),
                "snap",
            ])
            if q and q not in searchable:
                continue

            if glabel not in group_map:
                group_map[glabel] = []
                groups.append(glabel)
            group_map[glabel].append((
                item["path"],
                dt,
                snum,
                sname,
                f"#{snum} · {sname}  ({glabel} {dt.strftime('%I:%M %p').lstrip('0')})",
            ))

        self._fit_window_height_for_complete(groups, group_map)

        if not groups:
            empty = QWidget(self.content)
            el = QVBoxLayout(empty)
            el.setContentsMargins(0, 76, 0, 40)
            el.setAlignment(Qt.AlignCenter)
            el.setSpacing(10)
            ico = QLabel(empty)
            ico.setPixmap(_render_lucide_pix("my_box", "#787E88", 38, dpr=_native_dpr(self)))
            ico.setAlignment(Qt.AlignCenter)
            el.addWidget(ico)
            msg = QLabel("No matching Snaps found" if q else "Your Box has 0 Snaps yet", empty)
            msg.setStyleSheet(
                "color: #F4F4F5; font-size: 14px; font-weight: 700; "
                "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; background: transparent;"
            )
            msg.setAlignment(Qt.AlignCenter)
            sub = QLabel(
                "Try '#number', snap name, 'Today', 'Yesterday', or clear search."
                if q else "Click Take Snap above to capture & store Snaps cleanly here.",
                empty,
            )
            sub.setStyleSheet(
                "color: #848A95; font-size: 11.5px; "
                "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; background: transparent;"
            )
            sub.setAlignment(Qt.AlignCenter)
            el.addWidget(msg)
            el.addWidget(sub)
            self.content_lay.addWidget(empty)
            return

        for glabel in groups:
            items = group_map[glabel]
            sec = QWidget(self.content)
            sl = QVBoxLayout(sec)
            sl.setContentsMargins(0, 8, 0, 12)
            sl.setSpacing(12)

            # Clean Editorial Date Header (Today / Yesterday / Date)
            hdr_row = QHBoxLayout()
            hdr_row.setSpacing(8)
            lbl_g = QLabel(glabel, sec)
            lbl_g.setStyleSheet(
                "color: #F4F4F5; font-size: 13px; font-weight: 700; letter-spacing: 0.35px; "
                "font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif; background: transparent;"
            )
            hdr_row.addWidget(lbl_g)

            cnt_lbl = QLabel(f"·  {format_count_label(len(items), 'snap', 'snaps')}", sec)
            cnt_lbl.setStyleSheet(
                "color: #71717A; background: transparent; border: none; "
                "font-size: 11.5px; font-weight: 500; "
                "font-family: 'Segoe UI Variable Text', 'Segoe UI', sans-serif;"
            )
            hdr_row.addWidget(cnt_lbl)

            line = QFrame(sec)
            line.setFixedHeight(1)
            line.setStyleSheet("background-color: rgba(255, 255, 255, 0.08);")
            hdr_row.addWidget(line, stretch=1)
            sl.addLayout(hdr_row)

            if self.view_mode == "oneline":
                strip = _HorizontalSnapStrip(sec)
                for fp, dt, snum, sname, title_lbl in items:
                    tile = _FramelessSnapTile(fp, dt, snum, sname, title_lbl, parent=strip.inner)
                    self._connect_tile(tile)
                    strip.row_lay.addWidget(tile)
                sl.addWidget(strip)
            else:
                grid_w = QWidget(sec)
                grid = QGridLayout(grid_w)
                grid.setContentsMargins(0, 0, 0, 0)
                grid.setHorizontalSpacing(18)
                grid.setVerticalSpacing(16)
                grid.setAlignment(Qt.AlignTop | Qt.AlignLeft)
                for idx, (fp, dt, snum, sname, title_lbl) in enumerate(items):
                    tile = _FramelessSnapTile(fp, dt, snum, sname, title_lbl, parent=grid_w)
                    self._connect_tile(tile)
                    grid.addWidget(tile, idx // 3, idx % 3)
                sl.addWidget(grid_w)

            self.content_lay.addWidget(sec)

    def _connect_tile(self, tile: _FramelessSnapTile):
        tile.clicked.connect(self._open_preview)
        tile.copy_clicked.connect(self._copy_pin)
        tile.supershare_clicked.connect(self._on_supershare)
        tile.delete_clicked.connect(self._delete_pin)
        tile.renamed.connect(self._on_snap_renamed)

    def _on_snap_renamed(self, fp, new_name):
        c = self.mapToGlobal(QPoint(self.width() // 2, self.height() // 2))
        self.status_popup.show_message(
            new_name.upper(), _LUCIDE_PIN_ICONS["pencil_fill"], c, badge_text="SNAP RENAMED", duration_ms=1400
        )

    def _on_supershare(self, fp):
        c = self.mapToGlobal(QPoint(self.width() // 2, self.height() // 2))
        self.status_popup.show_message(
            "SUPERSHARE", _LUCIDE_PIN_ICONS["supershare_fill"], c, badge_text="COMING SOON", duration_ms=1700
        )

    def _open_preview(self, fp, title_lbl):
        if os.path.exists(fp):
            dlg = _PinLightboxDialog(fp, title_lbl, parent=self)
            dlg.exec()

    def _copy_pin(self, fp):
        if os.path.exists(fp):
            px = QPixmap(fp)
            copy_pixmap_to_clipboard(px, int(self.winId()) if self.winId() else None)
            c = self.mapToGlobal(QPoint(self.width() // 2, self.height() // 2))
            self.status_popup.show_message(
                "SNAP COPIED", _LUCIDE_PIN_ICONS["copy_fill"], c, badge_text="COPIED TO CLIPBOARD", duration_ms=1500
            )

    def _delete_pin(self, fp):
        try:
            if os.path.exists(fp) and os.path.dirname(os.path.abspath(fp)) == os.path.abspath(BOX_DIR):
                os.remove(fp)
            delete_snap_meta(fp)
        except Exception:
            pass
        self.refresh_gallery(self.search_input.text())
        if self.on_count_changed:
            self.on_count_changed()

    def open_window(self):
        self.open_with_spring_animation()

    def open_asmr_switch(self):
        """Quick, silky normal fade-in at center when switching from menus (no vertical slide)."""
        self.refresh_gallery(self.search_input.text())
        screen = QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()
        avail = screen.availableGeometry()
        w, h = self.width(), self.height()
        tx = avail.center().x() - w // 2
        ty = avail.center().y() - h // 2

        self.setGeometry(QRect(tx, ty, w, h))
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.activateWindow()
        try:
            ctypes.windll.user32.SetForegroundWindow(int(self.winId()))
        except Exception:
            pass

        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(135)
        af.setStartValue(0.0)
        af.setEndValue(1.0)
        af.setEasingCurve(QEasingCurve.OutCubic)
        self.anim_in = af
        self.anim_in.start()

    def switch_out_asmr_animation(self, on_finished=None):
        """Quick, silky normal fade-out when returning to menus (no vertical bounce)."""
        if not self.isVisible():
            if on_finished:
                on_finished()
            return
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(110)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        af.setEasingCurve(QEasingCurve.OutCubic)

        def _done():
            self.hide()
            if on_finished:
                on_finished()

        af.finished.connect(_done)
        self.anim_out = af
        self.anim_out.start()

    def open_with_spring_animation(self):
        self.refresh_gallery(self.search_input.text())
        screen = QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()
        avail = screen.availableGeometry()
        full = screen.geometry()

        w, h = self.width(), self.height()
        tx = avail.center().x() - w // 2
        ty = avail.center().y() - h // 2
        target_geom = QRect(tx, ty, w, h)
        start_geom = QRect(tx, full.bottom() + 20, w, h)

        self.setGeometry(start_geom)
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.activateWindow()
        try:
            ctypes.windll.user32.SetForegroundWindow(int(self.winId()))
        except Exception:
            pass

        ag = QPropertyAnimation(self, b"geometry")
        ag.setDuration(400)
        ag.setStartValue(start_geom)
        ag.setEndValue(target_geom)
        ag.setEasingCurve(QEasingCurve.OutCubic)

        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(330)
        af.setStartValue(0.0)
        af.setEndValue(1.0)
        af.setEasingCurve(QEasingCurve.OutCubic)

        self.anim_in = QParallelAnimationGroup(self)
        self.anim_in.addAnimation(ag)
        self.anim_in.addAnimation(af)
        self.anim_in.start()

    def close_with_pull_animation(self, on_finished=None):
        if not self.isVisible():
            if on_finished:
                on_finished()
            return
        screen = QApplication.screenAt(self.pos()) or QApplication.primaryScreen()
        full = screen.geometry()
        curr = self.geometry()
        end_geom = QRect(curr.x(), full.bottom() + 20, curr.width(), curr.height())

        ag = QPropertyAnimation(self, b"geometry")
        ag.setDuration(320)
        ag.setStartValue(curr)
        ag.setEndValue(end_geom)
        ag.setEasingCurve(QEasingCurve.InCubic)

        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(280)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        af.setEasingCurve(QEasingCurve.InCubic)

        self.anim_out = QParallelAnimationGroup(self)
        self.anim_out.addAnimation(ag)
        self.anim_out.addAnimation(af)

        def _done():
            self.hide()
            if on_finished:
                on_finished()

        self.anim_out.finished.connect(_done)
        self.anim_out.start()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton and e.position().y() <= 54.0:
            self._dragging = True
            self._drag_offset = e.globalPosition().toPoint() - self.pos()
            self.setCursor(Qt.ClosedHandCursor)
            e.accept()
            return
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        if self._dragging:
            self.move(e.globalPosition().toPoint() - self._drag_offset)
            e.accept()
            return
        super().mouseMoveEvent(e)

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self._dragging:
            self._dragging = False
            self.setCursor(Qt.ArrowCursor)
            e.accept()
            return
        super().mouseReleaseEvent(e)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.close_with_pull_animation()
            e.accept()
        else:
            super().keyPressEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        w, h = float(self.width()), float(self.height())
        rect = QRectF(0.5, 0.5, w - 1.0, h - 1.0)
        card = QPainterPath()
        card.addRoundedRect(rect, 14.0, 14.0)

        p.fillPath(card, QColor(4, 4, 5, 254))
        p.setPen(QPen(QColor(255, 255, 255, 32), 1.0))
        p.drawPath(card)
        p.end()


# ──────────────────────────────────────────────────────────────────────────────
#  THE SUPER PIN - 4-ITEM HUB WINDOW (Matched 100% to Style #1 / Quick Menu)
# ──────────────────────────────────────────────────────────────────────────────

