# -*- coding: utf-8 -*-
from .common import *

class _ToolIconBtn(QWidget):
    """
    Minimalist borderless iOS/Win11 icon button (invisible at rest):
      - Renders crisp filled or bold vector icon at clean size
      - Optional 'color_dot' bar shows loaded ink/highlighter color without cluttering bar
      - Clicking active tool / right-click / dropdown cue emits 'configure_requested'
    """
    clicked = Signal()
    configure_requested = Signal()

    def __init__(
        self,
        icon_key,
        tip_text="",
        coming_soon=False,
        accent="#a3e635",
        size_px=34,
        icon_px=17,
        configurable=False,
        color_dot=None,
        parent=None,
    ):
        super().__init__(parent)
        self.icon_key = icon_key
        self.coming_soon = coming_soon
        self.accent = accent
        self.icon_px = icon_px
        self.configurable = configurable
        self.color_dot = color_dot
        self.active = False
        self.enabled_btn = True
        self.setToolTip(tip_text)
        self.setFixedSize(size_px, size_px)
        self.setCursor(Qt.PointingHandCursor)
        self._h = 0.0
        self._t = 0.0
        self._press = 0.0
        self._timer = QTimer(self)
        self._timer.setInterval(16)
        self._timer.timeout.connect(self._step)

    def set_color_dot(self, hex_col: str | None):
        self.color_dot = hex_col
        self.update()

    def set_active(self, flag: bool):
        self.active = bool(flag)
        self.update()

    def set_enabled_btn(self, flag: bool):
        self.enabled_btn = bool(flag)
        self.setCursor(Qt.PointingHandCursor if flag else Qt.ArrowCursor)
        self.update()

    def _step(self):
        act = False
        if abs(self._t - self._h) >= 0.008:
            self._h += (self._t - self._h) * 0.25
            act = True
        else:
            self._h = self._t
        if self._press > 0.01:
            self._press *= 0.80
            act = True
        else:
            self._press = 0.0
        self.update()
        if not act:
            self._timer.stop()

    def enterEvent(self, e):
        if self.enabled_btn:
            self._t = 1.0
            if not self._timer.isActive():
                self._timer.start()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._t = 0.0
        if not self._timer.isActive():
            self._timer.start()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if not self.enabled_btn:
            return
        if e.button() == Qt.RightButton and self.configurable:
            _play_asmr_tick()
            self.configure_requested.emit()
            e.accept()
            return
        if e.button() == Qt.LeftButton:
            _play_asmr_tick()
            self._press = 1.0
            if not self._timer.isActive():
                self._timer.start()
            was_active = self.active
            self.clicked.emit()
            if was_active and self.configurable:
                self.configure_requested.emit()
            e.accept()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        w, h = float(self.width()), float(self.height())
        hv = 1.0 if self.active else self._h
        sc = 1.0 - self._press * 0.06
        isz = self.icon_px

        p.save()
        p.translate(w * 0.5, h * 0.5)
        p.scale(sc, sc)
        p.translate(-w * 0.5, -h * 0.5)

        if not self.enabled_btn:
            pix = _render_lucide_pix(self.icon_key, "#464952", isz, dpr=native_dpr(self))
            p.drawPixmap(int(round((w - isz) * 0.5)), int(round((h - isz) * 0.5)), pix)
            p.restore()
            p.end()
            return

        path = QPainterPath()
        path.addRoundedRect(QRectF(1.0, 1.0, w - 2.0, h - 2.0), 8.5, 8.5)
        if self.active:
            p.fillPath(path, QColor(255, 255, 255, 26))
        elif hv > 0.02:
            p.fillPath(path, QColor(255, 255, 255, int(15 * hv)))

        ico_col = "#FFFFFF" if self.active else ("#FFFFFF" if hv > 0.35 else ("#9CA3AF" if self.coming_soon else "#C8CCD4"))
        iy_shift = -2.0 if self.color_dot else 0.0
        pix = _render_lucide_pix(self.icon_key, ico_col, isz, dpr=native_dpr(self))
        p.drawPixmap(int(round((w - isz) * 0.5)), int(round((h - isz) * 0.5 + iy_shift)), pix)

        # Clean Windows-11 Snipping Tool ink color indicator pill beneath configurable icon
        if self.color_dot:
            dot_col = QColor(self.color_dot)
            dp = QPainterPath()
            bar_w = 12.0 if self.active else 9.0
            dp.addRoundedRect(QRectF((w - bar_w) * 0.5, h - 6.0, bar_w, 2.5), 1.25, 1.25)
            p.fillPath(dp, dot_col)
            if self.configurable and self.active:
                # Subtle micro caret bottom-right indicating click-again opens colors & size flyout
                p.setBrush(QColor("#A1A7B3"))
                p.setPen(Qt.NoPen)
                tri = QPainterPath(QPointF(w - 6.5, h - 6.2))
                tri.lineTo(w - 3.3, h - 6.2)
                tri.lineTo(w - 4.9, h - 4.0)
                tri.closeSubpath()
                p.fillPath(tri, QColor(255, 255, 255, 165))
        p.restore()
        p.end()


class _ColorSwatch(QWidget):
    """Big, clear iOS circular color swatch (24x24) with subtle ring highlight."""
    selected = Signal(str)

    def __init__(self, hex_col, parent=None):
        super().__init__(parent)
        self.hex_col = hex_col
        self.active = False
        self.setFixedSize(24, 24)
        self.setCursor(Qt.PointingHandCursor)

    def set_active(self, flag: bool):
        self.active = bool(flag)
        self.update()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            _play_asmr_tick()
            self.selected.emit(self.hex_col)
            e.accept()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = float(self.width()), float(self.height())
        if self.active:
            p.setPen(QPen(QColor("#FFFFFF"), 1.8))
            p.setBrush(Qt.NoBrush)
            p.drawEllipse(QRectF(1.5, 1.5, w - 3.0, h - 3.0))
        p.setBrush(QColor(self.hex_col))
        p.setPen(QPen(QColor(255, 255, 255, 58), 0.9))
        p.drawEllipse(QRectF(4.2, 4.2, w - 8.4, h - 8.4))
        p.end()


class _ToolConfigFlyout(QFrame):
    """
    Windows 11 Snipping Tool / iOS Markup Floating Popover:
      - Revealed cleanly on demand right under Pen, Highlighter, Type, Arrow, Shape, or Eraser
      - Houses 12 curated color circles (6x2 grid), live thickness preview slider, & Rect/Circle picker
    """
    color_picked = Signal(str)
    size_changed = Signal(int)
    shape_picked = Signal(str)

    def __init__(self, palette_colors, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setFixedWidth(214)
        self.setStyleSheet(
            "QFrame { background-color: rgba(12, 13, 16, 250); "
            "border: 1px solid rgba(255, 255, 255, 0.12); border-radius: 14px; }"
        )

        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 12, 14, 12)
        lay.setSpacing(10)

        # Shape picker strip (only visible for Shape tool)
        self.shape_row = QWidget(self)
        self.shape_row.setStyleSheet("background: transparent; border: none;")
        sh_l = QHBoxLayout(self.shape_row)
        sh_l.setContentsMargins(0, 0, 0, 2)
        sh_l.setSpacing(6)
        self.btn_rect = _ToolIconBtn("square", "Rectangle", size_px=32, icon_px=15, parent=self.shape_row)
        self.btn_circle = _ToolIconBtn("circle", "Circle", size_px=32, icon_px=15, parent=self.shape_row)
        self.btn_rect.set_active(True)
        self.btn_rect.clicked.connect(lambda: self.shape_picked.emit("rect"))
        self.btn_circle.clicked.connect(lambda: self.shape_picked.emit("ellipse"))
        sh_lbl = QLabel("SHAPE", self.shape_row)
        sh_lbl.setStyleSheet(
            "color: #71717A; font-size: 9px; font-weight: 700; letter-spacing: 0.9px; "
            "border: none; background: transparent; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        sh_l.addWidget(sh_lbl)
        sh_l.addStretch(1)
        sh_l.addWidget(self.btn_rect)
        sh_l.addWidget(self.btn_circle)
        self.shape_row.setVisible(False)
        lay.addWidget(self.shape_row)

        # 12 Colors 6x2 Grid
        self.colors_wrap = QWidget(self)
        self.colors_wrap.setStyleSheet("background: transparent; border: none;")
        cw_l = QVBoxLayout(self.colors_wrap)
        cw_l.setContentsMargins(0, 0, 0, 0)
        cw_l.setSpacing(6)
        hdr_c = QLabel("COLORS", self.colors_wrap)
        hdr_c.setStyleSheet(
            "color: #71717A; font-size: 9px; font-weight: 700; letter-spacing: 0.9px; "
            "border: none; background: transparent; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        cw_l.addWidget(hdr_c)

        grid = QGridLayout()
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setHorizontalSpacing(7)
        grid.setVerticalSpacing(7)
        self.swatches = []
        for idx, col in enumerate(palette_colors):
            sw = _ColorSwatch(col, self.colors_wrap)
            sw.selected.connect(self.color_picked.emit)
            grid.addWidget(sw, idx // 6, idx % 6)
            self.swatches.append(sw)
        cw_l.addLayout(grid)
        lay.addWidget(self.colors_wrap)

        # Size Slider + Live Stroke Preview Dot
        self.size_wrap = QWidget(self)
        self.size_wrap.setStyleSheet("background: transparent; border: none;")
        sz_l = QVBoxLayout(self.size_wrap)
        sz_l.setContentsMargins(0, 2, 0, 0)
        sz_l.setSpacing(6)

        top_sz = QHBoxLayout()
        top_sz.setContentsMargins(0, 0, 0, 0)
        lbl_t = QLabel("SIZE", self.size_wrap)
        lbl_t.setStyleSheet(
            "color: #71717A; font-size: 9px; font-weight: 700; letter-spacing: 0.9px; "
            "border: none; background: transparent; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        self.lbl_px = QLabel("4px", self.size_wrap)
        self.lbl_px.setStyleSheet(
            "color: #E4E4E7; font-size: 10px; font-weight: 700; border: none; background: transparent; "
            "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        top_sz.addWidget(lbl_t)
        top_sz.addStretch(1)
        top_sz.addWidget(self.lbl_px)
        sz_l.addLayout(top_sz)

        sl_row = QHBoxLayout()
        sl_row.setContentsMargins(0, 0, 0, 0)
        sl_row.setSpacing(8)
        self.preview_dot = QLabel(self.size_wrap)
        self.preview_dot.setFixedSize(18, 18)
        self.preview_dot.setAlignment(Qt.AlignCenter)
        self.preview_dot.setStyleSheet("border: none; background: transparent;")
        sl_row.addWidget(self.preview_dot)

        self.slider = QSlider(Qt.Horizontal, self.size_wrap)
        self.slider.setRange(2, 26)
        self.slider.setValue(4)
        self.slider.setStyleSheet(
            "QSlider::groove:horizontal { height: 4px; background: rgba(255,255,255,0.12); border-radius: 2px; }"
            "QSlider::sub-page:horizontal { background: #a3e635; border-radius: 2px; }"
            "QSlider::handle:horizontal { width: 13px; height: 13px; margin: -4.5px 0; border-radius: 6.5px; "
            "background: #FFFFFF; border: 2px solid #a3e635; }"
        )
        self.slider.valueChanged.connect(self._on_val)
        sl_row.addWidget(self.slider, stretch=1)
        sz_l.addLayout(sl_row)
        lay.addWidget(self.size_wrap)

        self._cur_color = palette_colors[0]
        self._cur_size = 4
        self._refresh_dot()

    def _on_val(self, v):
        self._cur_size = int(v)
        self.lbl_px.setText(f"{v}px")
        self._refresh_dot()
        self.size_changed.emit(int(v))

    def _refresh_dot(self):
        dpr = native_dpr(self)
        px = max(1, int(round(18 * dpr)))
        pm = QPixmap(px, px)
        pm.fill(Qt.transparent)
        pt = QPainter(pm)
        pt.setRenderHint(QPainter.Antialiasing, True)
        d = max(3.5, min(15.0, 2.5 + (self._cur_size / 26.0) * 12.5)) * dpr
        r = QRectF((px - d) * 0.5, (px - d) * 0.5, d, d)
        pt.setBrush(QColor(self._cur_color))
        pt.setPen(QPen(QColor(255, 255, 255, 80), 0.9 * dpr))
        pt.drawEllipse(r)
        pt.end()
        pm.setDevicePixelRatio(dpr)
        self.preview_dot.setPixmap(pm)

    def sync_state(self, tool_id: str, color_hex: str, size_px: int, shape_kind: str):
        self._cur_color = color_hex
        self._cur_size = int(size_px)
        self.shape_row.setVisible(tool_id == "shape")
        self.colors_wrap.setVisible(tool_id != "eraser")
        self.btn_rect.set_active(shape_kind == "rect")
        self.btn_circle.set_active(shape_kind == "ellipse")
        for sw in self.swatches:
            sw.set_active(sw.hex_col.lower() == color_hex.lower())
        self.slider.blockSignals(True)
        self.slider.setValue(int(size_px))
        self.slider.blockSignals(False)
        self.lbl_px.setText(f"{int(size_px)}px")
        self._refresh_dot()
        self.adjustSize()


class _SnapEditorCanvas(QWidget):
    """
    Full-resolution annotated snap canvas:
      - Tools: doodle, marker, eraser, crop, arrow, shape ('rect'|'ellipse')
      - Supports drawing BOTH inside & outside the snap boundary (saved cleanly expanded)
      - Smooth wheel/button zoom (50%..400%) & subtle light-visible green border
    """
    state_changed = Signal()
    crop_rect_changed = Signal(bool)
    zoom_changed = Signal(int)
    interacted = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMouseTracking(True)
        self.setCursor(Qt.CrossCursor)

        self._base_pix = QPixmap()
        self._strokes = []
        self._undo_stack = []
        self._redo_stack = []

        self.tool = "doodle"
        self.pen_color = "#a3e635"
        self.pen_size = 4
        self.shape_kind = "rect"

        self._zoom = 1.0
        self._pan = QPointF(0.0, 0.0)
        self._panning = False
        self._pan_start = QPointF()

        self._drawing = False
        self._active_stroke = None
        self._crop_start = None
        self._crop_end = None
        self._img_draw_rect = QRectF()
        self._text_norm_pt = None
        self._text_pulse = 0.0

        self._text_box = QLineEdit(self)
        self._text_box.setVisible(False)
        self._text_box.setMaxLength(120)
        self._text_box.setPlaceholderText("Type here...")
        self._text_box.textEdited.connect(self._on_asmr_type)
        self._text_box.returnPressed.connect(self._commit_text)
        self._text_box.editingFinished.connect(self._commit_text)

        self._pulse_tm = QTimer(self)
        self._pulse_tm.setInterval(16)
        self._pulse_tm.timeout.connect(self._step_pulse)

    def _step_pulse(self):
        if self._text_pulse > 0.02:
            self._text_pulse *= 0.84
            self.update()
        else:
            self._text_pulse = 0.0
            self._pulse_tm.stop()

    def _on_asmr_type(self, _txt):
        _play_asmr_tick()
        self._text_pulse = 1.0
        if not self._pulse_tm.isActive():
            self._pulse_tm.start()
        if self._text_box.isVisible():
            fm = QFontMetrics(self._text_box.font())
            nw = max(130, min(420, fm.horizontalAdvance(self._text_box.text() or "Type here...") + 34))
            self._text_box.setFixedWidth(nw)
        self.update()

    def _begin_text_at(self, wpos: QPointF, npt: QPointF):
        self._commit_text()
        self._text_norm_pt = npt
        fpt = 11 + int(self.pen_size * 0.75)
        self._text_box.setStyleSheet(
            f"QLineEdit {{ background: rgba(10, 14, 10, 238); color: {self.pen_color}; "
            f"border: 1.5px solid #a3e635; border-radius: 8px; padding: 4px 10px; "
            f"font-size: {fpt}px; font-weight: 700; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; }}"
        )
        self._text_box.setText("")
        self._text_box.setFixedSize(160, fpt + 20)
        tx = max(8, min(self.width() - 170, int(wpos.x())))
        ty = max(8, min(self.height() - (fpt + 26), int(wpos.y() - 14)))
        self._text_box.move(tx, ty)
        self._text_box.setVisible(True)
        self._text_box.setFocus()

    def _commit_text(self):
        if not self._text_box.isVisible():
            return
        txt = self._text_box.text().strip()
        self._text_box.setVisible(False)
        if txt and self._text_norm_pt is not None:
            self._push_undo()
            self._strokes.append({
                "type": "text",
                "color": self.pen_color,
                "size": self.pen_size,
                "pts": [self._text_norm_pt],
                "text": txt,
            })
            self.update()
        self._text_norm_pt = None

    def set_source_pixmap(self, pix: QPixmap):
        self._base_pix = pix.copy() if pix and not pix.isNull() else QPixmap()
        self._strokes = []
        self._undo_stack = []
        self._redo_stack = []
        self._zoom = 1.0
        self._pan = QPointF(0.0, 0.0)
        self._active_stroke = None
        self._crop_start = None
        self._crop_end = None
        self.zoom_changed.emit(100)
        self.state_changed.emit()
        self.crop_rect_changed.emit(False)
        self.update()

    def set_zoom(self, z: float):
        nz = max(0.5, min(4.0, float(z)))
        if abs(nz - 1.0) < 0.02:
            nz = 1.0
            self._pan = QPointF(0.0, 0.0)
        self._zoom = nz
        self.zoom_changed.emit(int(round(nz * 100)))
        self.update()

    def zoom_by(self, step: float):
        self.set_zoom(self._zoom + step)

    def can_undo(self):
        return len(self._undo_stack) > 0

    def can_redo(self):
        return len(self._redo_stack) > 0

    def _snapshot_state(self):
        return (self._base_pix.copy(), [dict(s, pts=list(s.get("pts", []))) for s in self._strokes])

    def _push_undo(self):
        self._undo_stack.append(self._snapshot_state())
        if len(self._undo_stack) > 30:
            self._undo_stack.pop(0)
        self._redo_stack.clear()
        self.state_changed.emit()

    def undo(self):
        if not self._undo_stack:
            return
        self._redo_stack.append(self._snapshot_state())
        base, strokes = self._undo_stack.pop()
        self._base_pix = base
        self._strokes = strokes
        self._crop_start = None
        self._crop_end = None
        self.crop_rect_changed.emit(False)
        self.state_changed.emit()
        self.update()

    def redo(self):
        if not self._redo_stack:
            return
        self._undo_stack.append(self._snapshot_state())
        base, strokes = self._redo_stack.pop()
        self._base_pix = base
        self._strokes = strokes
        self._crop_start = None
        self._crop_end = None
        self.crop_rect_changed.emit(False)
        self.state_changed.emit()
        self.update()

    def clear_crop_selection(self):
        self._crop_start = None
        self._crop_end = None
        self.crop_rect_changed.emit(False)
        self.update()

    def apply_crop(self):
        if not self._crop_start or not self._crop_end or self._base_pix.isNull():
            return False
        nx0 = min(self._crop_start.x(), self._crop_end.x())
        ny0 = min(self._crop_start.y(), self._crop_end.y())
        nx1 = max(self._crop_start.x(), self._crop_end.x())
        ny1 = max(self._crop_start.y(), self._crop_end.y())
        if (nx1 - nx0) < 0.03 or (ny1 - ny0) < 0.03:
            self.clear_crop_selection()
            return False

        self._push_undo()
        baked = self.render_final_pixmap()
        bw, bh = baked.width(), baked.height()
        rx = max(0, int(round(nx0 * bw)))
        ry = max(0, int(round(ny0 * bh)))
        rw = max(12, min(bw - rx, int(round((nx1 - nx0) * bw))))
        rh = max(12, min(bh - ry, int(round((ny1 - ny0) * bh))))
        cropped = baked.copy(rx, ry, rw, rh)
        cropped.setDevicePixelRatio(baked.devicePixelRatio())
        self._base_pix = cropped
        self._strokes = []
        self._crop_start = None
        self._crop_end = None
        self.crop_rect_changed.emit(False)
        self.state_changed.emit()
        self.update()
        return True

    def _compute_draw_rect(self) -> QRectF:
        if self._base_pix.isNull():
            return QRectF()
        dpr = max(1.0, float(self._base_pix.devicePixelRatio() or 1.0))
        lw = self._base_pix.width() / dpr
        lh = self._base_pix.height() / dpr
        # Leave clean outer canvas breathing room at 1.0x so users can annotate outside the image edge
        avw = max(80.0, float(self.width()) - 48.0)
        avh = max(60.0, float(self.height()) - 32.0)
        base_sc = min(avw / max(1.0, lw), avh / max(1.0, lh), 1.0)
        sc = base_sc * self._zoom
        dw = lw * sc
        dh = lh * sc
        cx = (self.width() - dw) * 0.5 + self._pan.x()
        cy = (self.height() - dh) * 0.5 + self._pan.y()
        return QRectF(cx, cy, dw, dh)

    def _widget_to_norm(self, pt: QPointF, clamp=False) -> QPointF:
        r = self._img_draw_rect
        if r.width() <= 1 or r.height() <= 1:
            return QPointF(0.5, 0.5)
        nx = (pt.x() - r.x()) / r.width()
        ny = (pt.y() - r.y()) / r.height()
        if clamp:
            nx = max(0.0, min(1.0, nx))
            ny = max(0.0, min(1.0, ny))
        return QPointF(nx, ny)

    def wheelEvent(self, e):
        delta = e.angleDelta().y()
        if delta != 0:
            self.zoom_by(0.15 if delta > 0 else -0.15)
            e.accept()
            return
        super().wheelEvent(e)

    def _erase_near(self, npt: QPointF):
        r = self._img_draw_rect
        thresh = max(0.018, (self.pen_size * 2.2) / max(80.0, r.width()))
        removed = False
        kept = []
        for s in self._strokes:
            hit = False
            pts = s.get("pts", [])
            for sp in pts:
                if math.hypot(sp.x() - npt.x(), sp.y() - npt.y()) <= thresh:
                    hit = True
                    break
            if not hit and s["type"] in ("arrow", "rect", "ellipse") and len(pts) == 2:
                x0, x1 = min(pts[0].x(), pts[1].x()) - thresh, max(pts[0].x(), pts[1].x()) + thresh
                y0, y1 = min(pts[0].y(), pts[1].y()) - thresh, max(pts[0].y(), pts[1].y()) + thresh
                if x0 <= npt.x() <= x1 and y0 <= npt.y() <= y1:
                    hit = True
            if hit:
                if not removed:
                    self._push_undo()
                    removed = True
            else:
                kept.append(s)
        if removed:
            self._strokes = kept
            self.update()

    def mousePressEvent(self, e):
        self.interacted.emit()
        if e.button() == Qt.MiddleButton:
            self._panning = True
            self._pan_start = e.position()
            self.setCursor(Qt.ClosedHandCursor)
            e.accept()
            return
        if e.button() == Qt.LeftButton and not self._base_pix.isNull():
            self._img_draw_rect = self._compute_draw_rect()
            npt = self._widget_to_norm(e.position(), clamp=(self.tool == "crop"))
            if self.tool == "type":
                self._begin_text_at(e.position(), npt)
                e.accept()
                return
            self._commit_text()
            self._drawing = True
            if self.tool == "eraser":
                self._erase_near(npt)
            elif self.tool == "crop":
                self._crop_start = npt
                self._crop_end = npt
                self.crop_rect_changed.emit(False)
                self.update()
            elif self.tool in ("doodle", "marker"):
                self._push_undo()
                self._active_stroke = {
                    "type": self.tool,
                    "color": self.pen_color,
                    "size": self.pen_size,
                    "pts": [npt],
                }
                self._strokes.append(self._active_stroke)
                self.update()
            elif self.tool in ("arrow", "shape"):
                self._push_undo()
                stype = "arrow" if self.tool == "arrow" else self.shape_kind
                self._active_stroke = {
                    "type": stype,
                    "color": self.pen_color,
                    "size": self.pen_size,
                    "pts": [npt, npt],
                }
                self._strokes.append(self._active_stroke)
                self.update()
            e.accept()

    def mouseMoveEvent(self, e):
        if self._panning:
            diff = e.position() - self._pan_start
            self._pan += diff
            self._pan_start = e.position()
            self.update()
            e.accept()
            return
        if not self._drawing:
            return
        npt = self._widget_to_norm(e.position(), clamp=(self.tool == "crop"))
        if self.tool == "eraser":
            self._erase_near(npt)
        elif self.tool == "crop":
            self._crop_end = npt
            self.crop_rect_changed.emit(True)
            self.update()
        elif self._active_stroke:
            if self.tool in ("doodle", "marker"):
                self._active_stroke["pts"].append(npt)
            else:
                self._active_stroke["pts"][1] = npt
            self.update()

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.MiddleButton and self._panning:
            self._panning = False
            self.setCursor(Qt.CrossCursor)
            e.accept()
            return
        if e.button() == Qt.LeftButton and self._drawing:
            self._drawing = False
            self._active_stroke = None
            if self.tool == "crop" and self._crop_start and self._crop_end:
                has_box = abs(self._crop_end.x() - self._crop_start.x()) > 0.03 and abs(self._crop_end.y() - self._crop_start.y()) > 0.03
                self.crop_rect_changed.emit(has_box)
            self.update()
            e.accept()

    @staticmethod
    def _paint_strokes(p: QPainter, target_rect: QRectF, strokes, scale_factor=1.0):
        rx, ry, rw, rh = target_rect.x(), target_rect.y(), target_rect.width(), target_rect.height()

        def mp(npt: QPointF) -> QPointF:
            return QPointF(rx + npt.x() * rw, ry + npt.y() * rh)

        for s in strokes:
            pts = s.get("pts", [])
            if not pts:
                continue
            stype = s["type"]
            col = QColor(s["color"])
            sz = float(s["size"]) * scale_factor

            if stype == "marker":
                col.setAlpha(98)
                p.setPen(QPen(col, sz * 2.5, Qt.SolidLine, Qt.FlatCap, Qt.RoundJoin))
                p.setBrush(Qt.NoBrush)
                path = QPainterPath(mp(pts[0]))
                for pt in pts[1:]:
                    path.lineTo(mp(pt))
                p.drawPath(path)
            elif stype == "doodle":
                p.setPen(QPen(col, sz, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
                p.setBrush(Qt.NoBrush)
                if len(pts) == 1:
                    p.drawPoint(mp(pts[0]))
                else:
                    path = QPainterPath(mp(pts[0]))
                    for i in range(1, len(pts)):
                        prev = mp(pts[i - 1])
                        cur = mp(pts[i])
                        mid = QPointF((prev.x() + cur.x()) * 0.5, (prev.y() + cur.y()) * 0.5)
                        path.quadTo(prev, mid)
                    path.lineTo(mp(pts[-1]))
                    p.drawPath(path)
            elif stype == "rect" and len(pts) >= 2:
                p.setPen(QPen(col, max(2.0, sz), Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
                p.setBrush(Qt.NoBrush)
                r = QRectF(mp(pts[0]), mp(pts[1])).normalized()
                p.drawRoundedRect(r, 5.0 * scale_factor, 5.0 * scale_factor)
            elif stype == "ellipse" and len(pts) >= 2:
                p.setPen(QPen(col, max(2.0, sz), Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
                p.setBrush(Qt.NoBrush)
                r = QRectF(mp(pts[0]), mp(pts[1])).normalized()
                p.drawEllipse(r)
            elif stype == "arrow" and len(pts) >= 2:
                a = mp(pts[0])
                b = mp(pts[1])
                dx = b.x() - a.x()
                dy = b.y() - a.y()
                dist = math.hypot(dx, dy)
                if dist > 4.0:
                    ux, uy = dx / dist, dy / dist
                    lw = max(2.2, sz)
                    hlen = min(dist * 0.65, max(13.0 * scale_factor, lw * 3.1))
                    half_w = hlen * 0.44
                    px_u, py_u = -uy, ux
                    # End shaft cleanly inside the arrowhead triangle so RoundCap never protrudes ahead of tip b
                    base_center = QPointF(b.x() - ux * (hlen * 0.78), b.y() - uy * (hlen * 0.78))
                    p1 = QPointF(base_center.x() + px_u * half_w, base_center.y() + py_u * half_w)
                    p2 = QPointF(base_center.x() - px_u * half_w, base_center.y() - py_u * half_w)
                    p.setPen(QPen(col, lw, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
                    p.setBrush(Qt.NoBrush)
                    p.drawLine(a, base_center)
                    poly = QPainterPath(b)
                    poly.lineTo(p1)
                    poly.lineTo(p2)
                    poly.closeSubpath()
                    p.setPen(Qt.NoPen)
                    p.fillPath(poly, col)
            elif stype == "text" and pts:
                txt = str(s.get("text") or "")
                if not txt:
                    continue
                pt0 = mp(pts[0])
                f_txt = QFont("Segoe UI Variable")
                f_txt.setStyleName("Display Bold")
                f_txt.setPixelSize(max(13, int(round((11.0 + float(s.get("size", 4)) * 0.75) * scale_factor))))
                f_txt.setStyleStrategy(QFont.PreferAntialias | QFont.NoSubpixelAntialias)
                p.setFont(f_txt)
                off = max(1.2, 1.5 * scale_factor)
                p.setPen(QColor(0, 0, 0, 175))
                p.drawText(QPointF(pt0.x() + off, pt0.y() + off), txt)
                p.setPen(col)
                p.drawText(pt0, txt)

    def render_final_pixmap(self) -> QPixmap:
        if self._base_pix.isNull():
            return QPixmap()
        bw = float(self._base_pix.width())
        bh = float(self._base_pix.height())
        if not self._strokes:
            return self._base_pix.copy()

        disp_w = max(80.0, self._img_draw_rect.width() or bw)
        sf = bw / disp_w

        min_x, min_y = 0.0, 0.0
        max_x, max_y = bw, bh
        for s in self._strokes:
            pad = max(14.0, float(s.get("size", 4)) * sf * 2.5)
            pts = s.get("pts", [])
            if s.get("type") == "text" and pts:
                f_txt = QFont("Segoe UI Variable")
                f_txt.setStyleName("Display Bold")
                f_txt.setPixelSize(max(13, int(round((11.0 + float(s.get("size", 4)) * 0.75) * sf))))
                fm = QFontMetrics(f_txt)
                px, py = pts[0].x() * bw, pts[0].y() * bh
                tw = fm.horizontalAdvance(str(s.get("text") or "")) + 18.0
                th = fm.height() + 10.0
                min_x = min(min_x, px - 12.0)
                min_y = min(min_y, py - th)
                max_x = max(max_x, px + tw)
                max_y = max(max_y, py + 14.0)
                continue
            for pt in pts:
                px, py = pt.x() * bw, pt.y() * bh
                min_x = min(min_x, px - pad)
                min_y = min(min_y, py - pad)
                max_x = max(max_x, px + pad)
                max_y = max(max_y, py + pad)

        # Expand output canvas cleanly if user drew outside the image
        out_w = min(6000, max(int(round(bw)), int(math.ceil(max_x - min_x))))
        out_h = min(6000, max(int(round(bh)), int(math.ceil(max_y - min_y))))
        out = QPixmap(out_w, out_h)
        out.setDevicePixelRatio(self._base_pix.devicePixelRatio())
        out.fill(QColor(8, 9, 11))

        ox = -min_x
        oy = -min_y
        p = QPainter(out)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        p.drawPixmap(int(round(ox)), int(round(oy)), self._base_pix)
        self._paint_strokes(p, QRectF(ox, oy, bw, bh), self._strokes, scale_factor=sf)
        p.end()
        return out

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        # Studio matte background stage (supports annotations outside image)
        stage_path = QPainterPath()
        stage_path.addRoundedRect(QRectF(0.6, 0.6, self.width() - 1.2, self.height() - 1.2), 10.0, 10.0)
        p.fillPath(stage_path, QColor(8, 9, 11, 255))
        p.setPen(QPen(QColor(255, 255, 255, 16), 0.9))
        p.drawPath(stage_path)

        self._img_draw_rect = self._compute_draw_rect()
        dr = self._img_draw_rect
        if dr.isEmpty():
            p.end()
            return

        p.save()
        p.setClipPath(stage_path)

        clip_path = QPainterPath()
        clip_path.addRoundedRect(dr, 8.0, 8.0)
        p.save()
        p.setClipPath(clip_path)
        p.drawPixmap(dr.toRect(), self._base_pix)

        # Crop selection overlay
        if self.tool == "crop" and self._crop_start and self._crop_end:
            cr = QRectF(
                QPointF(dr.x() + self._crop_start.x() * dr.width(), dr.y() + self._crop_start.y() * dr.height()),
                QPointF(dr.x() + self._crop_end.x() * dr.width(), dr.y() + self._crop_end.y() * dr.height()),
            ).normalized()
            if cr.width() > 3 and cr.height() > 3:
                ov = QPainterPath()
                ov.addRect(dr)
                hole = QPainterPath()
                hole.addRect(cr)
                p.fillPath(ov.subtracted(hole), QColor(4, 4, 5, 145))
                p.setPen(QPen(QColor("#a3e635"), 1.6, Qt.DashLine))
                p.drawRect(cr)
        p.restore()

        # Subtle light-visible green border around original image area
        p.setPen(QPen(QColor(163, 230, 53, 62), 1.0))
        p.drawPath(clip_path)

        # Paint strokes unclipped across full studio canvas (both inside AND outside image!)
        self._paint_strokes(p, dr, self._strokes, scale_factor=self._zoom)
        p.restore()
        p.end()


class _SnipResultWindow(QWidget):
    """
    SUPER SNAP iOS-Minimalist Studio Editor (Windows 11 Snipping Tool Command Logic):
      - Header Tier 1: Vector 'SUPER SNAP' brand + Inline Name Bar | Save, Copy, Put in Box | Back, Home, Close (ZERO top-right #number!)
      - Header Tier 2: Floating Top Command Pill -> Pen, Highlighter, Type, Arrow, Shape, Eraser, Crop | Undo, Redo | AI, Re-Take, Share, SuperShare | Zoom
      - On-Demand Anchored Flyout Popover (_ToolConfigFlyout): 12 Curated Colors + Live Size Slider + Rect/Circle Switcher (Zero static color clutter!)
      - Canvas: Expansive full-height unobstructed studio stage (annotations inside & outside edge + wheel zoom + crisp non-protruding arrowheads)
    """
    retake_requested = Signal()

    PALETTE_COLORS = [
        "#a3e635", "#22C55E", "#06B6D4", "#3B82F6", "#8B5CF6", "#EC4899",
        "#EF4444", "#F97316", "#FACC15", "#FFFFFF", "#94A3B8", "#18181B",
    ]

    def __init__(self, status_popup, edge_popup, on_box_updated=None, on_back=None, on_main_menu=None, parent=None):
        super().__init__(
            parent,
            Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool | Qt.NoDropShadowWindowHint,
        )
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.status_popup = status_popup
        self.edge_popup = edge_popup
        self.on_box_updated = on_box_updated
        self.on_back = on_back
        self.on_main_menu = on_main_menu

        self._snap_pix = None
        self._screen = None
        self._snap_num = 1024
        self._flyer = _FlyingSnapImage()
        self._dragging = False
        self._drag_offset = QPoint()
        self._flyout_tool = None

        self._tool_prefs = {
            "doodle": {"color": "#a3e635", "size": 4},
            "marker": {"color": "#FACC15", "size": 10},
            "type":   {"color": "#FFFFFF", "size": 5},
            "arrow":  {"color": "#EF4444", "size": 4},
            "shape":  {"color": "#a3e635", "size": 4},
            "eraser": {"color": "#FFFFFF", "size": 8},
        }

        base_assets = os.path.join(BASE_DIR, "thesupermouse", "assets")
        logo_fp = os.path.join(base_assets, "supermouse_app_logo_cropped.png")
        if not os.path.exists(logo_fp):
            logo_fp = os.path.join(base_assets, "supermouse_app_logo_trans.png")
        self._raw_logo = QImage(logo_fp) if os.path.exists(logo_fp) else None
        if self._raw_logo and not self._raw_logo.isNull():
            ldpr = _native_dpr(self)
            li = self._raw_logo.scaledToHeight(max(20, int(round(20 * ldpr))), Qt.SmoothTransformation)
            self.logo_pix = QPixmap.fromImage(li)
            self.logo_pix.setDevicePixelRatio(ldpr)
        else:
            self.logo_pix = None

        self._build_ui()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(14, 0, 14, 14)
        root.setSpacing(6)

        # ─── 1. Tier-1 Minimalist Top Chrome: Brand + Name | Primary Actions | Back, Home, Close ─
        header = QWidget(self)
        header.setFixedHeight(50)
        header.setCursor(Qt.OpenHandCursor)
        hdr = QHBoxLayout(header)
        hdr.setContentsMargins(136, 0, 0, 0)
        hdr.setSpacing(6)

        # Sleek inline Name capsule (no heavy outer box clutter)
        name_pill = QFrame(header)
        name_pill.setFixedHeight(30)
        name_pill.setFixedWidth(196)
        name_pill.setStyleSheet(
            "QFrame { background-color: #0B0C10; border: 1px solid rgba(255,255,255,0.08); border-radius: 9px; }"
            "QFrame:focus-within { border-color: rgba(163,230,53,0.45); background-color: #0F1115; }"
        )
        np_l = QHBoxLayout(name_pill)
        np_l.setContentsMargins(9, 0, 8, 0)
        np_l.setSpacing(6)
        np_ico = QLabel(name_pill)
        np_ico.setPixmap(render_common_icon("pencil", "#848A95", 13, dpr=native_dpr(self)))
        np_ico.setStyleSheet("border: none; background: transparent;")
        np_l.addWidget(np_ico)

        self.name_input = QLineEdit(name_pill)
        self.name_input.setPlaceholderText("Snap name...")
        self.name_input.setMaxLength(44)
        self.name_input.setStyleSheet(
            "QLineEdit { background: transparent; border: none; color: #F4F4F5; "
            "font-size: 11px; font-weight: 600; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; }"
        )
        self.name_input.textEdited.connect(lambda _: _play_asmr_tick())
        np_l.addWidget(self.name_input, stretch=1)
        hdr.addWidget(name_pill, alignment=Qt.AlignVCenter)

        hdr.addStretch(1)

        self.btn_save = _ActionPillButton("Save", _LUCIDE_PIN_ICONS["save"], compact=True, parent=header)
        self.btn_copy = _ActionPillButton("Copy", _LUCIDE_PIN_ICONS["copy"], compact=True, parent=header)
        self.btn_box = _ActionPillButton("Put in Box", _LUCIDE_PIN_ICONS["package_plus"], primary=True, compact=True, parent=header)
        self.btn_save.clicked.connect(self._on_save_desktop)
        self.btn_copy.clicked.connect(self._on_copy)
        self.btn_box.clicked.connect(self._on_put_in_box)
        hdr.addWidget(self.btn_save, alignment=Qt.AlignVCenter)
        hdr.addWidget(self.btn_copy, alignment=Qt.AlignVCenter)
        hdr.addWidget(self.btn_box, alignment=Qt.AlignVCenter)

        hdr.addSpacing(4)
        hdr.addWidget(self._vdiv(16), alignment=Qt.AlignVCenter)
        hdr.addSpacing(2)

        # NO #number! Clean borderless Back, Home & Close right at top-right!
        self.btn_back = CleanHeaderIconButton("back", "Back to Super Snap & Pin", box_size=30, icon_size=15, on_press_tick=_play_asmr_tick, parent=header)
        self.btn_menu = CleanHeaderIconButton("home", "Main Menu", box_size=30, icon_size=15, on_press_tick=_play_asmr_tick, parent=header)
        self.btn_win_close = CleanCloseButton("Close Super Snap", box_size=30, icon_size=15, parent=header)
        self.btn_back.clicked.connect(self._go_back)
        self.btn_menu.clicked.connect(self._go_menu)
        self.btn_win_close.clicked.connect(self.hide)
        hdr.addWidget(self.btn_back, alignment=Qt.AlignVCenter)
        hdr.addWidget(self.btn_menu, alignment=Qt.AlignVCenter)
        hdr.addWidget(self.btn_win_close, alignment=Qt.AlignVCenter)
        root.addWidget(header)

        # ─── 2. Tier-2 Centered Top Floating Markup Command Bar (All Tools Above Canvas!) ─
        cmd_wrap = QWidget(self)
        cmd_wrap.setFixedHeight(44)
        cw_l = QHBoxLayout(cmd_wrap)
        cw_l.setContentsMargins(0, 0, 0, 2)
        cw_l.setAlignment(Qt.AlignCenter)

        self.cmd_bar = QFrame(cmd_wrap)
        self.cmd_bar.setFixedHeight(42)
        self.cmd_bar.setStyleSheet(
            "QFrame { background-color: #0B0C10; border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 13px; }"
        )
        cb_l = QHBoxLayout(self.cmd_bar)
        cb_l.setContentsMargins(8, 0, 10, 0)
        cb_l.setSpacing(3)

        self._tool_btns = {}
        for tid, ikey, tip, cfg in (
            ("doodle", "pen_line",       "Pen (Click again for 12 Colors & Size)",         True),
            ("marker", "highlighter",    "Highlighter (Click again for 12 Colors & Size)", True),
            ("type",   "type",           "Text (Click again for 12 Colors & Size)",        True),
            ("arrow",  "move_up_right",  "Arrow (Click again for 12 Colors & Size)",       True),
            ("shape",  "shapes",         "Shapes (Click again for Rect/Circle & Colors)",  True),
            ("eraser", "eraser",         "Eraser (Click again for Size)",                  True),
            ("crop",   "crop",           "Crop Frame",                                     False),
        ):
            dot = self._tool_prefs[tid]["color"] if tid in self._tool_prefs and tid != "eraser" else None
            btn = _ToolIconBtn(ikey, tip, size_px=34, icon_px=17, configurable=cfg, color_dot=dot, parent=self.cmd_bar)
            btn.clicked.connect(lambda k=tid: self._select_tool(k))
            if cfg:
                btn.configure_requested.connect(lambda k=tid: self._toggle_flyout_for(k))
            cb_l.addWidget(btn, alignment=Qt.AlignVCenter)
            self._tool_btns[tid] = btn

        cb_l.addSpacing(3)
        cb_l.addWidget(self._vdiv(18), alignment=Qt.AlignVCenter)
        cb_l.addSpacing(3)

        self.btn_undo = _ToolIconBtn("undo", "Undo (Ctrl+Z)", size_px=32, icon_px=16, parent=self.cmd_bar)
        self.btn_redo = _ToolIconBtn("redo", "Redo (Ctrl+Y)", size_px=32, icon_px=16, parent=self.cmd_bar)
        self.btn_undo.clicked.connect(self.canvas.undo if hasattr(self, "canvas") else lambda: None)
        self.btn_redo.clicked.connect(self.canvas.redo if hasattr(self, "canvas") else lambda: None)
        cb_l.addWidget(self.btn_undo, alignment=Qt.AlignVCenter)
        cb_l.addWidget(self.btn_redo, alignment=Qt.AlignVCenter)

        cb_l.addSpacing(3)
        cb_l.addWidget(self._vdiv(18), alignment=Qt.AlignVCenter)
        cb_l.addSpacing(3)

        self.btn_bg_remove = _ToolIconBtn("sparkles", "BG Remove (Coming Soon)", coming_soon=True, size_px=32, icon_px=16, parent=self.cmd_bar)
        self.btn_scan_text = _ToolIconBtn("text_extractor", "Scan Text (Coming Soon)", coming_soon=True, size_px=32, icon_px=16, parent=self.cmd_bar)
        self.btn_retake = _ToolIconBtn("rotate_ccw", "Re-Take Snap", size_px=32, icon_px=16, parent=self.cmd_bar)
        self.btn_share = _ToolIconBtn("share", "Share Snap", size_px=32, icon_px=16, parent=self.cmd_bar)
        self.btn_supershare = _ToolIconBtn("supershare", "SuperShare (Coming Soon)", coming_soon=True, size_px=32, icon_px=16, parent=self.cmd_bar)

        self.btn_bg_remove.clicked.connect(lambda: (self._hide_flyout(), self._show_coming_soon("BG REMOVE", "sparkles")))
        self.btn_scan_text.clicked.connect(lambda: (self._hide_flyout(), self._show_coming_soon("SCAN TEXT", "text_extractor")))
        self.btn_retake.clicked.connect(self._on_retake)
        self.btn_share.clicked.connect(self._on_share)
        self.btn_supershare.clicked.connect(lambda: (self._hide_flyout(), self._show_coming_soon("SUPERSHARE", "supershare")))

        for b in (self.btn_bg_remove, self.btn_scan_text, self.btn_retake, self.btn_share, self.btn_supershare):
            cb_l.addWidget(b, alignment=Qt.AlignVCenter)

        cb_l.addSpacing(3)
        cb_l.addWidget(self._vdiv(18), alignment=Qt.AlignVCenter)
        cb_l.addSpacing(4)

        # Minimalist Inline Zoom Controls (- 100% +) right inside Top Command Pill
        z_btn_qss = (
            "QPushButton { background: transparent; color: #9CA3AF; border: none; font-size: 13px; font-weight: 700; min-width: 20px; }"
            "QPushButton:hover { color: #FFFFFF; }"
        )
        btn_z_out = QPushButton("−", self.cmd_bar)
        btn_z_out.setCursor(Qt.PointingHandCursor)
        btn_z_out.setStyleSheet(z_btn_qss)
        btn_z_out.setToolTip("Zoom Out (Mouse Wheel Down)")
        btn_z_out.clicked.connect(lambda: self.canvas.zoom_by(-0.2))

        self.btn_z_pct = QPushButton("100%", self.cmd_bar)
        self.btn_z_pct.setCursor(Qt.PointingHandCursor)
        self.btn_z_pct.setStyleSheet(
            "QPushButton { background: transparent; color: #D4D4D8; border: none; font-size: 10.5px; font-weight: 700; min-width: 36px; }"
            "QPushButton:hover { color: #a3e635; }"
        )
        self.btn_z_pct.setToolTip("Reset Zoom & Pan to 100%")
        self.btn_z_pct.clicked.connect(lambda: self.canvas.set_zoom(1.0))

        btn_z_in = QPushButton("+", self.cmd_bar)
        btn_z_in.setCursor(Qt.PointingHandCursor)
        btn_z_in.setStyleSheet(z_btn_qss)
        btn_z_in.setToolTip("Zoom In (Mouse Wheel Up)")
        btn_z_in.clicked.connect(lambda: self.canvas.zoom_by(0.2))

        cb_l.addWidget(btn_z_out, alignment=Qt.AlignVCenter)
        cb_l.addWidget(self.btn_z_pct, alignment=Qt.AlignVCenter)
        cb_l.addWidget(btn_z_in, alignment=Qt.AlignVCenter)

        cw_l.addWidget(self.cmd_bar)
        root.addWidget(cmd_wrap)

        # ─── 3. Big Uncluttered Studio Canvas (Occupies Full Remaining Space!) ─
        self.canvas = _SnapEditorCanvas(self)
        self.canvas.state_changed.connect(self._sync_undo_redo)
        self.canvas.crop_rect_changed.connect(self._on_crop_ready)
        self.canvas.zoom_changed.connect(lambda pct: self.btn_z_pct.setText(f"{pct}%"))
        self.canvas.interacted.connect(self._hide_flyout)
        self.btn_undo.clicked.disconnect()
        self.btn_redo.clicked.disconnect()
        self.btn_undo.clicked.connect(lambda: (self._hide_flyout(), self.canvas.undo()))
        self.btn_redo.clicked.connect(lambda: (self._hide_flyout(), self.canvas.redo()))
        root.addWidget(self.canvas, stretch=1)

        # Floating Crop Confirmation Pill inside Canvas (only shown while Crop box drawn)
        self._crop_box = QFrame(self.canvas)
        self._crop_box.setStyleSheet(
            "QFrame { background-color: rgba(12, 13, 16, 244); border: 1px solid rgba(255,255,255,0.12); border-radius: 10px; }"
        )
        cr_l = QHBoxLayout(self._crop_box)
        cr_l.setContentsMargins(6, 5, 6, 5)
        cr_l.setSpacing(6)
        self.btn_crop_apply = _ActionPillButton("Apply Crop", _LUCIDE_PIN_ICONS["check"], primary=True, compact=True, parent=self._crop_box)
        self.btn_crop_apply.clicked.connect(self.canvas.apply_crop)
        self.btn_crop_cancel = _ToolIconBtn("x", "Clear Crop Selection", size_px=28, icon_px=14, parent=self._crop_box)
        self.btn_crop_cancel.clicked.connect(self.canvas.clear_crop_selection)
        cr_l.addWidget(self.btn_crop_apply)
        cr_l.addWidget(self.btn_crop_cancel)
        self._crop_box.adjustSize()
        self._crop_box.setVisible(False)

        # ─── 4. Windows 11 Snipping Tool Floating Flyout (12 Colors + Size + Shape) ─
        self.flyout = _ToolConfigFlyout(self.PALETTE_COLORS, parent=self)
        self.flyout.color_picked.connect(self._select_color)
        self.flyout.size_changed.connect(self._on_size_changed)
        self.flyout.shape_picked.connect(self._select_shape)
        self.flyout.setVisible(False)

        self._select_tool("doodle")
        self._sync_undo_redo()

    def _vdiv(self, h=18):
        d = QFrame(self)
        d.setFixedSize(1, h)
        d.setStyleSheet("background-color: rgba(255,255,255,0.09); border: none;")
        return d

    def resizeEvent(self, e):
        super().resizeEvent(e)
        if hasattr(self, "_crop_box") and hasattr(self, "canvas"):
            self._crop_box.adjustSize()
            self._crop_box.move(max(12, self.canvas.width() - self._crop_box.width() - 14), 12)
        if hasattr(self, "flyout") and self.flyout.isVisible() and self._flyout_tool:
            self._position_flyout(self._flyout_tool)

    def _hide_flyout(self):
        if hasattr(self, "flyout") and self.flyout.isVisible():
            self.flyout.setVisible(False)
            self._flyout_tool = None

    def _position_flyout(self, tid: str):
        btn = self._tool_btns.get(tid)
        if not btn:
            return
        pt = btn.mapTo(self, QPoint(btn.width() // 2, btn.height()))
        self.flyout.adjustSize()
        fx = max(16, min(self.width() - self.flyout.width() - 16, pt.x() - self.flyout.width() // 2))
        fy = pt.y() + 8
        self.flyout.move(fx, fy)
        self.flyout.raise_()

    def _toggle_flyout_for(self, tid: str):
        if self.flyout.isVisible() and self._flyout_tool == tid:
            self._hide_flyout()
            return
        self._flyout_tool = tid
        pref = self._tool_prefs.get(tid, {"color": self.canvas.pen_color, "size": self.canvas.pen_size})
        self.flyout.sync_state(tid, pref["color"], pref["size"], self.canvas.shape_kind)
        self._position_flyout(tid)
        self.flyout.setVisible(True)
        self.flyout.raise_()

    def _select_color(self, hex_col):
        tid = self._flyout_tool or self.canvas.tool
        if tid in self._tool_prefs:
            self._tool_prefs[tid]["color"] = hex_col
        self.canvas.pen_color = hex_col
        if tid in self._tool_btns and tid != "eraser":
            self._tool_btns[tid].set_color_dot(hex_col)
        if hasattr(self, "flyout"):
            self.flyout.sync_state(
                tid,
                hex_col,
                self._tool_prefs.get(tid, {}).get("size", self.canvas.pen_size),
                self.canvas.shape_kind,
            )

    def _select_shape(self, kind):
        self.canvas.shape_kind = kind
        if hasattr(self, "flyout"):
            tid = self._flyout_tool or self.canvas.tool
            pref = self._tool_prefs.get(tid, {"color": self.canvas.pen_color, "size": self.canvas.pen_size})
            self.flyout.sync_state("shape", pref["color"], pref["size"], kind)

    def _on_size_changed(self, val):
        tid = self._flyout_tool or self.canvas.tool
        if tid in self._tool_prefs:
            self._tool_prefs[tid]["size"] = int(val)
        self.canvas.pen_size = int(val)

    def _select_tool(self, tid):
        if self._flyout_tool and self._flyout_tool != tid:
            self._hide_flyout()
        self.canvas.tool = tid
        self.canvas.setCursor(Qt.IBeamCursor if tid == "type" else Qt.CrossCursor)
        for k, b in self._tool_btns.items():
            b.set_active(k == tid)
        if tid in self._tool_prefs:
            pref = self._tool_prefs[tid]
            self.canvas.pen_color = pref["color"]
            self.canvas.pen_size = pref["size"]
        if tid != "crop":
            self.canvas.clear_crop_selection()

    def _on_crop_ready(self, ready):
        self._crop_box.adjustSize()
        self._crop_box.move(max(12, self.canvas.width() - self._crop_box.width() - 14), 12)
        self._crop_box.setVisible(bool(ready))
        if ready:
            self._crop_box.raise_()

    def _sync_undo_redo(self):
        self.btn_undo.set_enabled_btn(self.canvas.can_undo())
        self.btn_redo.set_enabled_btn(self.canvas.can_redo())

    def _show_coming_soon(self, title, ico_key):
        c = self.mapToGlobal(QPoint(self.width() // 2, self.height() // 2))
        self.status_popup.show_message(title, _LUCIDE_PIN_ICONS[ico_key], c, badge_text="COMING SOON", duration_ms=1700)

    def _fade_switch_out(self, cb=None):
        self._hide_flyout()
        if not self.isVisible():
            if callable(cb):
                cb()
            return
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(110)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        af.setEasingCurve(QEasingCurve.OutCubic)
        def _done():
            self.hide()
            self.setWindowOpacity(1.0)
            if callable(cb):
                cb()
        af.finished.connect(_done)
        self._fade_anim = af
        af.start()

    def _go_back(self):
        self._fade_switch_out(self.on_back)

    def _go_menu(self):
        self._fade_switch_out(self.on_main_menu)

    def show_snap(self, snap_pix, sel_global_rect, screen):
        self._hide_flyout()
        self.setWindowOpacity(1.0)
        self._snap_pix = snap_pix
        self._screen = screen or QApplication.primaryScreen()
        avail = self._screen.availableGeometry()

        self.canvas.set_source_pixmap(snap_pix)
        self._snap_num = next_snap_number()
        self.name_input.setText(_logical_snap_name(datetime.now(), ""))

        dpr = max(1.0, float(snap_pix.devicePixelRatio() or 1.0))
        img_w = snap_pix.width() / dpr
        img_h = snap_pix.height() / dpr

        win_w = max(920, min(int(avail.width() * 0.86), int(img_w + 90)))
        win_h = max(470, min(int(avail.height() * 0.84), int(img_h + 150)))
        self.setFixedSize(win_w, win_h)

        cx, cy = sel_global_rect.center().x(), sel_global_rect.center().y()
        x = max(avail.left() + 14, min(avail.right() - win_w - 14, cx - win_w // 2))
        y = max(avail.top() + 14, min(avail.bottom() - win_h - 14, cy - win_h // 2))

        self.move(x, y)
        self.show()
        self.raise_()
        self.activateWindow()

    def _baked_pix(self) -> QPixmap:
        pix = self.canvas.render_final_pixmap()
        return pix if not pix.isNull() else (self._snap_pix or QPixmap())

    def _on_retake(self):
        self._hide_flyout()
        self.hide()
        self.retake_requested.emit()

    def _on_share(self):
        self._hide_flyout()
        pix = self._baked_pix()
        copy_pixmap_to_clipboard(pix, hwnd=int(self.winId()) if self.winId() else None)
        c = self.mapToGlobal(QPoint(self.width() // 2, self.height() // 2))
        self.status_popup.show_message(
            "READY TO SHARE", _LUCIDE_PIN_ICONS["share"], c, badge_text="COPIED FOR SHARING", duration_ms=1700
        )

    def _on_copy(self):
        self._hide_flyout()
        pix = self._baked_pix()
        copy_pixmap_to_clipboard(pix, hwnd=int(self.winId()) if self.winId() else None)
        c = self.mapToGlobal(QPoint(self.width() // 2, self.height() // 2))
        self.hide()
        self.status_popup.show_message(
            "SNAP COPIED", _LUCIDE_PIN_ICONS["copy"], c, badge_text="COPIED TO CLIPBOARD", duration_ms=1700
        )

    def _on_save_desktop(self):
        self._hide_flyout()
        pix = self._baked_pix()
        if pix.isNull():
            self.hide()
            return
        desk = get_desktop_dir()
        safe_nm = "".join(c for c in self.name_input.text().strip() if c.isalnum() or c in (" ", "-", "_")).strip().replace(" ", "_")
        prefix = f"SuperSnap_{safe_nm}" if safe_nm else f"SuperSnap_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        fname = f"{prefix}.png"
        out_fp = os.path.join(desk, fname)
        if os.path.exists(out_fp):
            fname = f"{prefix}_{datetime.now().strftime('%H%M%S')}.png"
            out_fp = os.path.join(desk, fname)
        pix.save(out_fp, "PNG")
        c = self.mapToGlobal(QPoint(self.width() // 2, self.height() // 2))
        self.hide()
        self.status_popup.show_message(
            "SAVED TO DESKTOP", _LUCIDE_PIN_ICONS["save"], c, badge_text=fname, duration_ms=2000
        )

    def _on_put_in_box(self):
        self._hide_flyout()
        snap = self._baked_pix()
        if snap.isNull():
            self.hide()
            return
        ensure_box_dir()
        fname = f"BoxSnap_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        out_fp = os.path.join(BOX_DIR, fname)
        snap.save(out_fp, "PNG")

        custom_name = self.name_input.text().strip() or _logical_snap_name(datetime.now(), out_fp)
        save_custom_snap_meta(out_fp, self._snap_num, custom_name)
        if self.on_box_updated:
            self.on_box_updated()

        tl = self.canvas.mapToGlobal(QPoint(0, 0))
        img_rect = QRect(tl.x(), tl.y(), self.canvas.width(), self.canvas.height())
        scr = self._screen
        snap_lbl = f"#{self._snap_num} · {custom_name}"

        self.hide()
        self._flyer.fly_into_right_edge(
            snap,
            img_rect,
            scr,
            on_fully_inside=lambda yc: self.edge_popup.show_from_right(
                yc, out_fp, snap_pix=snap, screen=scr, snap_label=snap_lbl
            ),
        )

    def keyPressEvent(self, e):
        if e.modifiers() & Qt.ControlModifier:
            if e.key() == Qt.Key_Z:
                self.canvas.undo()
                e.accept()
                return
            if e.key() == Qt.Key_Y:
                self.canvas.redo()
                e.accept()
                return
        if e.key() == Qt.Key_Escape:
            if self.flyout.isVisible():
                self._hide_flyout()
            else:
                self.hide()
            e.accept()
        else:
            super().keyPressEvent(e)

    def mousePressEvent(self, e):
        if self.flyout.isVisible() and not self.flyout.geometry().contains(e.position().toPoint()):
            self._hide_flyout()
        if e.button() == Qt.LeftButton and e.position().y() <= 50.0:
            self._dragging = True
            self._drag_offset = e.globalPosition().toPoint() - self.pos()
            self.setCursor(Qt.ClosedHandCursor)
            e.accept()
        elif e.button() == Qt.RightButton:
            self.hide()
        else:
            super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        if self._dragging:
            self.move(e.globalPosition().toPoint() - self._drag_offset)
            e.accept()
        else:
            super().mouseMoveEvent(e)

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self._dragging:
            self._dragging = False
            self.setCursor(Qt.ArrowCursor)
            e.accept()
        else:
            super().mouseReleaseEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        w, h = float(self.width()), float(self.height())
        rect = QRectF(0.6, 0.6, w - 1.2, h - 1.2)
        path = QPainterPath()
        path.addRoundedRect(rect, 14.0, 14.0)
        p.fillPath(path, QColor(4, 4, 5, 254))
        p.setPen(QPen(QColor(255, 255, 255, 26), 1.0))
        p.drawPath(path)

        _draw_vector_brand(p, 16.0, 25.0, self.logo_pix, "SUPER", "SNAP", font_pt=11.4)
        p.end()


