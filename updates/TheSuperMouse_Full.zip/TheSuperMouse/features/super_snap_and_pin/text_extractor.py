# -*- coding: utf-8 -*-
"""Super Snap & Pin - Text Extractor Module."""
from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QWidget, QLabel, QVBoxLayout
from ui_theme import ACCENT_LIME, TEXT_PRIMARY, TEXT_MUTED

class TextExtractorWindow(QWidget):
    """Text Extractor OCR tool window."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Text Extractor")
        self.setFixedSize(360, 480)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.SubWindow)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
