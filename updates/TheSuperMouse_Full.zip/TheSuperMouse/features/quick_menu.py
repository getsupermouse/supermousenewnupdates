# -*- coding: utf-8 -*-
"""
THE SUPER MOUSE - SEAMLESS OBSIDIAN QUICK MENU
==============================================
Ultra-clean open-canvas obsidian switcher matched to SuperMouseHUD:
  - Pure #040405 OLED matte canvas with generous right-side breathing room (288x402)
  - Vector-crisp QPainterPath 'THE SUPERMOUSE' display font (#FFFFFF + #FFFF00 -> #00FF85)
  - Seamless top header flowing straight into 'MENU' (no dividing line below title)
  - Boxless floating rows on open obsidian canvas; crisp un-blurred single-row hover:
      * Active Tools: razor-sharp #121A0F glass pill + crisp #a3e635 rim & gliding chevron
      * Coming Soon: calm frosted slate pill + slow silky left-to-right pearl shimmer
  - Sharp single-pass Studio footer badge with 'STUDIO' tag & Lucide arrow-up-right
"""

import os
import io
import math
import struct
import wave
import ctypes
import webbrowser

try:
    import winsound
except Exception:
    winsound = None

from PySide6.QtSvg import QSvgRenderer
from PySide6.QtCore import (
    Qt, QByteArray, QPoint, QPointF, QRect, QRectF, QSize, QTimer, Signal,
    QPropertyAnimation, QParallelAnimationGroup, QEasingCurve, QUrl
)
from PySide6.QtGui import (
    QPainter, QPainterPath, QColor, QPen, QBrush,
    QLinearGradient, QPixmap, QImage, QCursor, QFont, QFontMetrics,
    QDesktopServices, QIcon
)
from PySide6.QtWidgets import (
    QApplication, QWidget, QFrame, QLabel, QHBoxLayout, QVBoxLayout, QPushButton, QScrollArea
)
from ui_theme import COMMON_ICONS, CleanBackButton, CleanCloseButton, render_common_icon, format_count_label, ASSETS_DIR, BASE_DIR, get_app_logo_pixmap


STUDIO_WEBSITE_LOCAL = os.path.join(BASE_DIR, "thesupermouse", "studio_website", "index.html")

_CLOSE_FILL_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="{col}" d="M6.28 5.22a.75.75 0 0 0-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 1 0 1.06 1.06L10 11.06l3.72 3.72a.75.75 0 1 0 1.06-1.06L11.06 10l3.72-3.72a.75.75 0 0 0-1.06-1.06L10 8.94z"/></svg>'

_ASMR_TICK_WAV = None


def _play_asmr_tick():
    global _ASMR_TICK_WAV
    if winsound is None:
        return
    if _ASMR_TICK_WAV is None:
        try:
            sr = 22050
            n = int(sr * 0.020)
            frames = bytearray()
            for i in range(n):
                t = i / sr
                env = math.exp(-t * 175.0)
                s = (math.sin(2.0 * math.pi * 1950.0 * t) * 0.55 + math.sin(2.0 * math.pi * 3400.0 * t) * 0.25) * env
                frames += struct.pack("<h", max(-32767, min(32767, int(s * 5400))))
            buf = io.BytesIO()
            with wave.open(buf, "wb") as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(sr)
                wf.writeframes(bytes(frames))
            _ASMR_TICK_WAV = buf.getvalue()
        except Exception:
            _ASMR_TICK_WAV = b""
    if _ASMR_TICK_WAV:
        try:
            winsound.PlaySound(_ASMR_TICK_WAV, winsound.SND_MEMORY | winsound.SND_ASYNC | winsound.SND_NOSTOP)
        except Exception:
            pass


def _native_dpr(widget=None):
    try:
        if widget is not None:
            d = float(widget.devicePixelRatioF())
            if d > 0.5:
                return d
        scr = QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()
        if scr is not None:
            return max(1.0, float(scr.devicePixelRatio()))
    except Exception:
        pass
    return 1.0


def _render_svg_dpr(svg_tpl, color_hex, size_px=16, dpr=None):
    if dpr is None:
        dpr = _native_dpr()
    svg = svg_tpl.replace("{col}", color_hex)
    px = max(1, int(round(size_px * dpr)))
    pix = QPixmap(px, px)
    pix.fill(Qt.transparent)
    p = QPainter(pix)
    p.setRenderHint(QPainter.Antialiasing, True)
    p.setRenderHint(QPainter.SmoothPixmapTransform, True)
    QSvgRenderer(QByteArray(svg.encode("utf-8"))).render(p)
    p.end()
    pix.setDevicePixelRatio(dpr)
    return pix


def _draw_crisp_text(p, rect, centered, font, color, text):
    """Draw sharp filled vector glyph paths so Windows ClearType never drops pixels on #040405."""
    f = QFont(font)
    f.setHintingPreference(QFont.PreferNoHinting)
    fm = QFontMetrics(f)
    tx = (rect.center().x() - fm.horizontalAdvance(text) * 0.5) if centered else float(rect.left())
    ty = rect.center().y() + (fm.ascent() - fm.descent()) * 0.5
    tp = QPainterPath()
    tp.addText(tx, ty, f, text)
    p.fillPath(tp, color)


class ComingSoonPopup(QFrame):
    """Pure #050505 Obsidian popup notification matching HUD modal aesthetics."""

    def __init__(self, parent=None):
        super().__init__(None, Qt.ToolTip | Qt.FramelessWindowHint | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_ShowWithoutActivating, False)
        self.setFixedSize(316, 68)

        lay = QHBoxLayout(self)
        lay.setContentsMargins(12, 10, 14, 10)
        lay.setSpacing(11)

        self.ico_lbl = QLabel(self)
        self.ico_lbl.setFixedSize(36, 36)
        self.ico_lbl.setAlignment(Qt.AlignCenter)
        self.ico_lbl.setStyleSheet("""
            background-color: #0E0E0E;
            border: 1px solid rgba(163, 230, 53, 0.55);
            border-radius: 18px;
        """)
        lay.addWidget(self.ico_lbl)

        txt_col = QVBoxLayout()
        txt_col.setSpacing(3)
        txt_col.setAlignment(Qt.AlignVCenter)

        self.lbl_title = QLabel("SUPER SHARE", self)
        self.lbl_title.setStyleSheet(
            "color: #FFFFFF; font-size: 11.5px; font-weight: 700; "
            "font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif; background: transparent;"
        )
        txt_col.addWidget(self.lbl_title)

        badge_row = QHBoxLayout()
        badge_row.setContentsMargins(0, 0, 0, 0)
        self.lbl_badge = QLabel("COMING SOON", self)
        self.lbl_badge.setFixedHeight(17)
        self.lbl_badge.setAlignment(Qt.AlignCenter)
        self.lbl_badge.setStyleSheet("""
            color: #a3e635;
            background-color: #121C10;
            border: 1px solid rgba(163, 230, 53, 0.50);
            border-radius: 5px;
            font-size: 8.5px;
            font-weight: 700;
            letter-spacing: 0.7px;
            font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif;
            padding: 0px 7px;
        """)
        badge_row.addWidget(self.lbl_badge)
        badge_row.addStretch()
        txt_col.addLayout(badge_row)

        lay.addLayout(txt_col, stretch=1)

        self._hide_timer = QTimer(self)
        self._hide_timer.setSingleShot(True)
        self._hide_timer.timeout.connect(self.close)

    def mousePressEvent(self, e):
        self._hide_timer.stop()
        self.close()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = float(self.width()), float(self.height())
        rect = QRectF(0.6, 0.6, w - 1.2, h - 1.2)
        path = QPainterPath()
        path.addRoundedRect(rect, 12.0, 12.0)

        p.fillPath(path, QColor(5, 5, 5, 250))
        p.setPen(QPen(QColor(255, 255, 255, 32), 1.0))
        p.drawPath(path)
        p.end()

    def show_option(self, title, svg_tpl, center_pos, badge_text="COMING SOON"):
        self.lbl_title.setText(title)
        self.lbl_badge.setText(badge_text)
        self.ico_lbl.setPixmap(_render_svg_dpr(svg_tpl, "#a3e635", 18, dpr=_native_dpr(self)))

        x = center_pos.x() - self.width() // 2
        y = center_pos.y() - self.height() // 2
        screen = QApplication.screenAt(center_pos) or QApplication.primaryScreen()
        if screen:
            ag = screen.availableGeometry()
            x = max(ag.left() + 10, min(ag.right() - self.width() - 10, x))
            y = max(ag.top() + 10, min(ag.bottom() - self.height() - 10, y))
        self.move(x, y)
        self.show()
        self.raise_()
        self._hide_timer.start(2200)


class _TopCloseButton(CleanCloseButton):
    """Unified borderless common Cross ('X') close button across QuickMenu / Access / Info."""

    def __init__(self, parent=None):
        super().__init__(tip="Close Menu (Esc)", box_size=30, icon_size=15, parent=parent)


class _MenuItemRow(QWidget):
    """
    Open-Canvas Boxless Row (ZERO individual item boxes at rest!):
      - Active Leaf Tools: sleek #141E10->#0D140A moss pill + crisp #a3e635 rim & left bar (NO chevron!)
      - Submenu Triggers ('has_submenu'): persistent Win11-style '>' chevron lighting to #a3e635
      - Coming Soon: calm frosted slate pill + slow silky left-to-right pearl shimmer
    """
    clicked = Signal(dict)
    hovered_in = Signal(dict)
    hovered_out = Signal(dict)

    def __init__(self, item_data, idx=0, compact=False, parent=None):
        super().__init__(parent)
        self.item = item_data
        self.idx = idx
        self._compact = bool(compact)
        self._badge_text = ""
        self._mouse_over = False
        self._force_active = False
        self.setFixedHeight(36)
        self.setCursor(Qt.PointingHandCursor)
        self.setMouseTracking(True)
        self.setAttribute(Qt.WA_Hover, True)
        self.setMouseTracking(True)
        self.setAttribute(Qt.WA_Hover, True)

        self._h = 0.0
        self._target = 0.0
        self._press = 0.0
        self._shimmer = -0.25
        self._reveal = 1.0
        self._timer = QTimer(self)
        self._timer.setInterval(16)
        self._timer.timeout.connect(self._step)

    def set_badge_text(self, text: str):
        self._badge_text = str(text or "").strip()
        self.update()

    def set_force_active(self, active: bool):
        self._force_active = bool(active)
        self._target = 1.0 if (self._mouse_over or self._force_active) else 0.0
        if not self._timer.isActive():
            self._timer.start()

    def start_reveal_animation(self):
        self._reveal = 1.0
        self._h = 0.0
        self._target = 0.0
        self._press = 0.0
        self.update()

    def _begin_reveal(self):
        self._reveal = 1.0
        self.update()

    def _step(self):
        active = False
        if self._reveal < 1.0:
            self._reveal = min(1.0, self._reveal + 0.11)
            active = True

        if abs(self._target - self._h) >= 0.005:
            self._h += (self._target - self._h) * 0.23
            active = True
        elif self._h != self._target:
            self._h = self._target

        if self._press > 0.01:
            self._press *= 0.80
            active = True
        else:
            self._press = 0.0

        is_soon = bool(self.item.get("coming_soon"))
        if is_soon and (self._target > 0.0 or self._h > 0.02):
            self._shimmer += 0.011
            if self._shimmer > 1.35:
                self._shimmer = -0.25
            active = True
        elif is_soon:
            self._shimmer = -0.25

        self.update()
        if not active and self._reveal >= 1.0 and self._h == self._target and self._press == 0.0:
            self._timer.stop()

    def enterEvent(self, e):
        self._mouse_over = True
        self._target = 1.0
        if not self._timer.isActive():
            self._timer.start()
        self.hovered_in.emit(self.item)
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._mouse_over = False
        self._target = 1.0 if self._force_active else 0.0
        if not self._timer.isActive():
            self._timer.start()
        self.hovered_out.emit(self.item)
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._press = 1.0
            if not self._timer.isActive():
                self._timer.start()
            self.clicked.emit(self.item)
            e.accept()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)

        rev = self._reveal
        if rev <= 0.01:
            p.end()
            return

        w, h = float(self.width()), float(self.height())
        hv = self._h
        is_soon = bool(self.item.get("coming_soon"))
        sc = 1.0 - self._press * 0.016

        p.save()
        p.setOpacity(rev)
        p.translate(0.0, (1.0 - rev) * 7.0)
        p.translate(w * 0.5, h * 0.5)
        p.scale(sc, sc)
        p.translate(-w * 0.5, -h * 0.5)

        pill_rect = QRectF(10.0, 1.5, w - 20.0, h - 3.0)
        pill_path = QPainterPath()
        pill_path.addRoundedRect(pill_rect, 8.5, 8.5)

        if not is_soon:
            has_sub = bool(self.item.get("has_submenu"))
            pad_x = 7.0 if self._compact else 10.0
            pill_rect = QRectF(pad_x, 1.5, w - pad_x * 2.0, h - 3.0)
            pill_path = QPainterPath()
            pill_path.addRoundedRect(pill_rect, 8.5, 8.5)

            # ─── IDLE: Clean Open Canvas -> HOVER: Sleek Dual-Tone Moss Pill + #a3e635 Rim (NO Leaf Arrows!) ───
            if hv > 0.008:
                grad_hv = QLinearGradient(pill_rect.left(), pill_rect.top(), pill_rect.right(), pill_rect.bottom())
                grad_hv.setColorAt(0.0, QColor(22, 33, 16, int(242 * hv)))
                grad_hv.setColorAt(1.0, QColor(12, 18, 10, int(235 * hv)))
                p.fillPath(pill_path, grad_hv)
                p.setPen(QPen(QColor(163, 230, 53, int(190 * hv)), 1.08))
                p.drawPath(pill_path)

                bar_h = 16.0 * hv
                bp = QPainterPath()
                bp.addRoundedRect(QRectF(pad_x, (h - bar_h) * 0.5, 2.8, bar_h), 1.4, 1.4)
                p.fillPath(bp, QColor(163, 230, 53, int(250 * hv)))

            # Official Lucide Outline Icon: #E4E4E7 crisp off-white -> #a3e635 on hover
            r_c = int(228 * (1.0 - hv) + 163 * hv)
            g_c = int(228 * (1.0 - hv) + 230 * hv)
            b_c = int(231 * (1.0 - hv) + 53 * hv)
            col_hex = f"#{r_c:02x}{g_c:02x}{b_c:02x}"

            ico_s = 15.5 if self._compact else 16.0
            ix = (15.0 if self._compact else 18.0) + hv * 2.0
            iy = (h - ico_s) * 0.5
            QSvgRenderer(QByteArray(self.item["svg"].replace("{col}", col_hex).encode("utf-8"))).render(
                p, QRectF(ix, iy, ico_s, ico_s)
            )

            f = QFont()
            f.setFamilies(["Segoe UI Variable Display", "Segoe UI Variable Text", "Segoe UI", "Arial", "sans-serif"])
            wt = QFont.Weight.Bold if hv >= 0.45 else QFont.Weight.DemiBold
            f.setWeight(wt)
            f.setBold(hv >= 0.45)
            f.setPointSizeF(9.3 if self._compact else 9.6)
            f.setHintingPreference(QFont.PreferNoHinting)
            base_tx = 39.0 if self._compact else 44.0
            text_x = base_tx + hv * 2.5
            right_reserve = 32.0 if has_sub else (38.0 if self._badge_text else 16.0)
            _draw_crisp_text(
                p,
                QRectF(text_x, 0.0, w - text_x - right_reserve, h),
                False,
                f,
                QColor("#FFFFFF") if hv > 0.3 else QColor("#EDEDEF"),
                self.item["label"],
            )

            # Win11-style persistent '>' chevron ONLY for items with a flyout submenu
            if has_sub:
                cr = int(124 * (1.0 - hv) + 163 * hv)
                cg = int(130 * (1.0 - hv) + 230 * hv)
                cb = int(142 * (1.0 - hv) + 53 * hv)
                chev_col = f"#{cr:02x}{cg:02x}{cb:02x}"
                p.save()
                p.setOpacity((0.76 + 0.24 * hv) * rev)
                chev_x = int(round((w - 28.0) + hv * 2.0))
                chev_svg = (
                    f'<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" '
                    f'viewBox="0 0 24 24" fill="none" stroke="{chev_col}" stroke-width="2.2" '
                    f'stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>'
                )
                QSvgRenderer(QByteArray(chev_svg.encode("utf-8"))).render(
                    p, QRect(chev_x, int((h - 12) / 2), 12, 12)
                )
                p.restore()
            elif self._badge_text:
                bw = max(20.0, len(self._badge_text) * 6.5 + 14.0)
                bh = 15.5
                br = QRectF(w - pad_x - 8.0 - bw, (h - bh) * 0.5, bw, bh)
                bp_pill = QPainterPath()
                bp_pill.addRoundedRect(br, 4.5, 4.5)
                p.fillPath(bp_pill, QColor(163, 230, 53, int(18 + 18 * hv)) if hv > 0.2 else QColor(255, 255, 255, 10))
                p.setPen(QPen(QColor(163, 230, 53, int(65 + 95 * hv)) if hv > 0.2 else QColor(255, 255, 255, 24), 0.8))
                p.drawPath(bp_pill)
                bf = QFont("Segoe UI Variable")
                bf.setStyleName("Display Bold")
                bf.setPointSizeF(5.8)
                _draw_crisp_text(p, br, True, bf, QColor("#a3e635") if hv > 0.2 else QColor("#A1A7B3"), self._badge_text)
            elif self.item.get("id") == "update_checker":
                pending_n = int(getattr(self, "_update_pending_count", 0) or 0)
                if pending_n > 0:
                    utxt = f"{pending_n} Update Pending"
                    uf = QFont("Segoe UI Variable")
                    uf.setStyleName("Display Bold")
                    uf.setPointSizeF(6.8)
                    fm_u = QFontMetrics(uf)
                    uw = fm_u.horizontalAdvance(utxt) + 14.0
                    uh = 17.0
                    ur = QRectF(w - pad_x - 8.0 - uw, (h - uh) * 0.5, uw, uh)
                    up_pill = QPainterPath()
                    up_pill.addRoundedRect(ur, 6.0, 6.0)
                    p.fillPath(up_pill, QColor(249, 115, 22, int(26 + 22 * hv)))
                    p.setPen(QPen(QColor(249, 115, 22, int(115 + 75 * hv)), 0.85))
                    p.drawPath(up_pill)
                    _draw_crisp_text(p, ur, True, uf, QColor("#FB923C"), utxt)
                else:
                    utxt = "You are up-to-date"
                    uf = QFont("Segoe UI Variable")
                    uf.setStyleName("Text Semibold")
                    uf.setPointSizeF(7.0)
                    fm_u = QFontMetrics(uf)
                    uw = fm_u.horizontalAdvance(utxt) + 4.0
                    ur = QRectF(w - pad_x - 8.0 - uw, 0.0, uw, h)
                    _draw_crisp_text(p, ur, False, uf, QColor(163, 230, 53, int(155 + 75 * hv)) if hv > 0.2 else QColor(255, 255, 255, 115), utxt)
            elif self.item.get("version_badge"):
                ver = str(self.item["version_badge"])
                bw = max(34.0, len(ver) * 6.5 + 12.0)
                bh = 16.0
                br = QRectF(w - pad_x - 8.0 - bw, (h - bh) * 0.5, bw, bh)
                vp = QPainterPath()
                vp.addRoundedRect(br, 6.0, 6.0)
                p.fillPath(vp, QColor(255, 255, 255, int(12 + 16 * hv)))
                p.setPen(QPen(QColor(255, 255, 255, int(36 + 50 * hv)), 0.85))
                p.drawPath(vp)
                vf = QFont("Segoe UI Variable")
                vf.setStyleName("Display Bold")
                vf.setPointSizeF(6.8)
                _draw_crisp_text(p, br, True, vf, QColor(255, 255, 255, int(135 + 65 * hv)), ver)
        else:
            # ─── COMING SOON: Boxless Canvas -> Calm Brushed Graphite Hover + Slow Shimmer Tag ───
            if hv > 0.008:
                p.fillPath(pill_path, QColor(255, 255, 255, int(11 * hv)))
                p.setPen(QPen(QColor(255, 255, 255, int(28 * hv)), 0.9))
                p.drawPath(pill_path)

            v_ico = int(146 + hv * 58)
            col_hex = f"#{v_ico:02x}{v_ico:02x}{min(255, v_ico + 5):02x}"
            ico_s = 15.0 if self._compact else 15.5
            ix = 15.0 if self._compact else 18.0
            QSvgRenderer(QByteArray(self.item["svg"].replace("{col}", col_hex).encode("utf-8"))).render(
                p, QRectF(ix, (h - ico_s) * 0.5, ico_s, ico_s)
            )

            f = QFont("Segoe UI Variable")
            f.setStyleName("Text Semibold")
            f.setPointSizeF(9.1 if self._compact else 9.4)
            v_txt = int(172 + hv * 48)
            text_x = 39.0 if self._compact else 44.0
            _draw_crisp_text(
                p,
                QRectF(text_x, 0.0, w - text_x - 84.0, h),
                False,
                f,
                QColor(v_txt, v_txt, v_txt + 4),
                self.item["label"],
            )

            pill_w, pill_h = 62.0, 15.5
            pill_rm = 15.0 if self._compact else 18.0
            pr = QRectF(w - pill_rm - pill_w, (h - pill_h) * 0.5, pill_w, pill_h)
            pp = QPainterPath()
            pp.addRoundedRect(pr, 4.5, 4.5)

            p.fillPath(pp, QColor(255, 255, 255, int(8 + hv * 8)))

            beam = self._shimmer
            if hv > 0.02:
                p.save()
                p.setClipPath(pp)
                sh_grad = QLinearGradient(pr.left(), pr.top(), pr.right(), pr.bottom())
                c0 = max(0.0, min(1.0, beam - 0.28))
                c1 = max(0.0, min(1.0, beam))
                c2 = max(0.0, min(1.0, beam + 0.28))
                sh_grad.setColorAt(0.0, QColor(255, 255, 255, 0))
                if c0 > 0.0:
                    sh_grad.setColorAt(c0, QColor(255, 255, 255, 0))
                sh_grad.setColorAt(c1, QColor(255, 255, 255, int(52 * hv)))
                if c2 < 1.0:
                    sh_grad.setColorAt(c2, QColor(255, 255, 255, 0))
                sh_grad.setColorAt(1.0, QColor(255, 255, 255, 0))
                p.fillRect(pr, sh_grad)
                p.restore()

            p.setPen(QPen(QColor(255, 255, 255, int(20 + hv * 32)), 0.8))
            p.drawPath(pp)

            pf = QFont("Segoe UI Variable")
            pf.setStyleName("Display Bold")
            pf.setPointSizeF(5.5)
            pf.setLetterSpacing(QFont.AbsoluteSpacing, 0.35)
            p.setFont(pf)

            if hv > 0.02:
                tg = QLinearGradient(pr.left(), 0.0, pr.right(), 0.0)
                base_t = QColor(142, 146, 154)
                peak_t = QColor(255, 255, 255)
                tg.setColorAt(0.0, base_t)
                c0 = max(0.0, min(1.0, beam - 0.26))
                c1 = max(0.0, min(1.0, beam))
                c2 = max(0.0, min(1.0, beam + 0.26))
                if c0 > 0.0:
                    tg.setColorAt(c0, base_t)
                tg.setColorAt(c1, peak_t)
                if c2 < 1.0:
                    tg.setColorAt(c2, base_t)
                tg.setColorAt(1.0, base_t)
                p.setPen(QPen(QBrush(tg), 1.0))
            else:
                p.setPen(QColor(134, 138, 146))
            p.drawText(pr, Qt.AlignCenter, "COMING SOON")

        p.restore()
        p.end()


class _ProfileFooterButton(QWidget):
    """
    Razor-sharp Studio Dock Footer (ZERO blurry green box!):
      - Crisp single-pass full-res SuperMouse emblem inside dark titanium squircle
      - 'SUPERMOUSE' + frosted 'STUDIO' pill + 'Official Web Portal'
      - Crisp translucent dark obsidian hover + white hairline rim + subtle lime arrow-up-right
    """
    clicked = Signal()

    def __init__(self, raw_logo_pix=None, parent=None):
        super().__init__(parent)
        dpr = _native_dpr(self)
        if raw_logo_pix and not raw_logo_pix.isNull():
            qi = raw_logo_pix.toImage().scaled(max(18, int(round(18 * dpr))), max(18, int(round(18 * dpr))), Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.badge_logo = QPixmap.fromImage(qi)
            self.badge_logo.setDevicePixelRatio(dpr)
        else:
            self.badge_logo = get_app_logo_pixmap(18, dpr)
        self.setFixedHeight(52)
        self.setCursor(Qt.PointingHandCursor)
        self.setMouseTracking(True)
        self.setAttribute(Qt.WA_Hover, True)
        self._h = 0.0
        self._target = 0.0
        self._press = 0.0
        self._timer = QTimer(self)
        self._timer.setInterval(16)
        self._timer.timeout.connect(self._step)

    def _step(self):
        active = False
        if abs(self._target - self._h) >= 0.005:
            self._h += (self._target - self._h) * 0.23
            active = True
        else:
            self._h = self._target
        if self._press > 0.01:
            self._press *= 0.80
            active = True
        else:
            self._press = 0.0
        self.update()
        if not active:
            self._timer.stop()

    def enterEvent(self, e):
        self._target = 1.0
        if not self._timer.isActive():
            self._timer.start()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._target = 0.0
        if not self._timer.isActive():
            self._timer.start()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._press = 1.0
            if not self._timer.isActive():
                self._timer.start()
            self.clicked.emit()
            e.accept()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        w, h = float(self.width()), float(self.height())
        hv = self._h
        sc = 1.0 - self._press * 0.015

        p.save()
        p.translate(w * 0.5, h * 0.5)
        p.scale(sc, sc)
        p.translate(-w * 0.5, -h * 0.5)

        # Ultra-crisp brushed dark obsidian hover surface (zero blurry neon-green box!)
        bg_path = QPainterPath()
        bg_path.addRoundedRect(QRectF(10.0, 3.0, w - 20.0, h - 6.0), 10.0, 10.0)
        bg_v = int(11 + hv * 11)
        p.fillPath(bg_path, QColor(bg_v, bg_v + 1, bg_v + 2, 255))
        p.setPen(QPen(QColor(255, 255, 255, int(18 + hv * 36)), 0.95))
        p.drawPath(bg_path)

        # Rounded squircle icon emblem aligned cleanly on x=18 grid
        sq = QRectF(18.0, (h - 32.0) * 0.5, 32.0, 32.0)
        sqp = QPainterPath()
        sqp.addRoundedRect(sq, 9.0, 9.0)
        p.fillPath(sqp, QColor(18, 19, 20, 255))
        p.setPen(QPen(QColor(255, 255, 255, int(26 + hv * 36)), 1.0))
        p.drawPath(sqp)

        if self.badge_logo and not self.badge_logo.isNull():
            bdpr = max(1.0, float(self.badge_logo.devicePixelRatio() or 1.0))
            bw = self.badge_logo.width() / bdpr
            bh = self.badge_logo.height() / bdpr
            p.drawPixmap(
                int(round(sq.center().x() - bw * 0.5)),
                int(round(sq.center().y() - bh * 0.5)),
                self.badge_logo,
            )

        # 'SUPERMOUSE' + sleek crisp 'STUDIO' micro-tag on exact top text line
        f_name = QFont("Segoe UI Variable")
        f_name.setStyleName("Display Bold")
        f_name.setPointSizeF(9.4)
        name_txt = "SUPERMOUSE"
        nw = QFontMetrics(f_name).horizontalAdvance(name_txt)
        _draw_crisp_text(p, QRectF(58.0, 9.0, nw + 4.0, 17.0), False, f_name, QColor("#F4F5F7") if hv < 0.3 else QColor("#FFFFFF"), name_txt)

        # Micro 'STUDIO' tag right beside SUPERMOUSE
        st_rect = QRectF(58.0 + nw + 7.0, 10.5, 44.0, 14.0)
        st_path = QPainterPath()
        st_path.addRoundedRect(st_rect, 4.0, 4.0)
        p.fillPath(st_path, QColor(163, 230, 53, int(24 + hv * 28)))
        p.setPen(QPen(QColor(163, 230, 53, int(90 + hv * 90)), 0.75))
        p.drawPath(st_path)
        pf = QFont("Segoe UI Variable")
        pf.setStyleName("Display Bold")
        pf.setPointSizeF(5.5)
        pf.setLetterSpacing(QFont.AbsoluteSpacing, 0.4)
        _draw_crisp_text(p, st_rect, True, pf, QColor("#a3e635"), "STUDIO")

        # Subtitle
        f_sub = QFont("Segoe UI Variable")
        f_sub.setStyleName("Text Semibold")
        f_sub.setPointSizeF(7.6)
        sub_v = int(146 + hv * 60)
        _draw_crisp_text(p, QRectF(58.0, 26.0, w - 94.0, 15.0), False, f_sub, QColor(sub_v, sub_v + 3, sub_v + 8), "Official Web Portal")

        # Crisp Lucide diagonal arrow-up-right moving cleanly up-right on hover
        arr_col = "#a3e635" if hv > 0.35 else "#7C828C"
        ax = int(round(w - 31.0 + hv * 2.0))
        ay = int(round((h - 14.0) * 0.5 - hv * 1.5))
        arr_svg = (
            f'<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" '
            f'viewBox="0 0 24 24" fill="none" stroke="{arr_col}" stroke-width="2.1" '
            f'stroke-linecap="round" stroke-linejoin="round"><path d="M7 7h10v10"/><path d="M7 17 17 7"/></svg>'
        )
        QSvgRenderer(QByteArray(arr_svg.encode("utf-8"))).render(p, QRect(ax, ay, 14, 14))
        p.restore()
        p.end()


class _BaseSubMenuPopup(QWidget):
    """
    Shared Windows 11-Style Flyout Submenu base:
      - Pure #040405 obsidian card + razor-sharp white/28 rim
      - Auto-flips horizontally near screen edges without stealing window focus
    """
    action_triggered = Signal(str)
    hovered_changed = Signal(bool)
    SUB_ITEMS = []
    POPUP_WIDTH = 256
    BADGE_ROW_ID = ""
    BADGE_SINGULAR = "Item"
    BADGE_PLURAL = "Items"

    def __init__(self, parent=None):
        super().__init__(parent, Qt.Tool | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_ShowWithoutActivating, True)
        popup_h = 12 + 36 * len(self.SUB_ITEMS)
        self.setFixedSize(self.POPUP_WIDTH, popup_h)
        self._is_hovered = False

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 6, 0, 6)
        lay.setSpacing(0)

        self._rows = []
        self._row_map = {}
        for idx, item in enumerate(self.SUB_ITEMS):
            r = _MenuItemRow(item, idx=idx, compact=True, parent=self)
            r.clicked.connect(lambda it: self._on_row_clicked(it["id"]))
            lay.addWidget(r)
            self._rows.append(r)
            self._row_map[item["id"]] = r

        self.anim_fade = QPropertyAnimation(self, b"windowOpacity", self)
        self.anim_fade.setDuration(150)
        self.anim_fade.setEasingCurve(QEasingCurve.OutCubic)

    def _on_row_clicked(self, oid: str):
        self.hide()
        self.action_triggered.emit(oid)

    def refresh_count(self, cnt: int):
        if not self.BADGE_ROW_ID:
            return
        badge_row = self._row_map.get(self.BADGE_ROW_ID)
        if badge_row is not None:
            badge_row.set_badge_text(format_count_label(cnt, self.BADGE_SINGULAR, self.BADGE_PLURAL))

    def open_for_row(self, anchor_row: QWidget, parent_menu: QWidget, item_count: int = 0):
        self.refresh_count(item_count)
        screen = QApplication.screenAt(parent_menu.pos()) or QApplication.primaryScreen()
        avail = screen.availableGeometry()
        w, h = self.width(), self.height()

        gap = 10
        right_x = parent_menu.x() + parent_menu.width() + gap
        if right_x + w <= avail.right() - 8:
            tx = right_x
        else:
            tx = max(avail.left() + 8, parent_menu.x() - w - gap)

        row_top = anchor_row.mapToGlobal(QPoint(0, 0)).y()
        ty = max(avail.top() + 8, min(avail.bottom() - h - 8, row_top - 6))

        for r in self._rows:
            r._reveal = 1.0
            r._mouse_over = False
            r._target = 0.0
            r._h = 0.0
            r.update()

        self.move(tx, ty)
        self.anim_fade.stop()
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.anim_fade.setStartValue(0.0)
        self.anim_fade.setEndValue(1.0)
        self.anim_fade.start()

    def enterEvent(self, e):
        self._is_hovered = True
        self.hovered_changed.emit(True)
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._is_hovered = False
        self.hovered_changed.emit(False)
        super().leaveEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = float(self.width()), float(self.height())
        card = QPainterPath()
        card.addRoundedRect(QRectF(0.6, 0.6, w - 1.2, h - 1.2), 12.0, 12.0)
        p.fillPath(card, QColor(4, 4, 5, 253))
        p.setPen(QPen(QColor(255, 255, 255, 30), 1.0))
        p.drawPath(card)
        p.end()


class _PinSubMenuPopup(_BaseSubMenuPopup):
    """Flyout submenu anchored beside 'Super Snap & Pin >'."""
    BADGE_ROW_ID = "my_box"
    BADGE_SINGULAR = "Snap"
    BADGE_PLURAL = "Snaps"
    SUB_ITEMS = [
        {
            "id": "take_snap",
            "label": "Take Snap",
            "coming_soon": False,
            "svg": COMMON_ICONS["take_snap"],
        },
        {
            "id": "text_extractor",
            "label": "Text Extractor",
            "coming_soon": True,
            "svg": COMMON_ICONS["text_extractor"],
        },
        {
            "id": "store_text",
            "label": "Store Text",
            "coming_soon": True,
            "svg": COMMON_ICONS["store_text"],
        },
        {
            "id": "my_box",
            "label": "My Box",
            "coming_soon": False,
            "svg": COMMON_ICONS["my_box"],
        },
    ]


class _ShareSubMenuPopup(_BaseSubMenuPopup):
    """Flyout submenu anchored beside 'Super Share >': Device Hub, Memory Space & Settings."""
    BADGE_ROW_ID = "share_memory_space"
    BADGE_SINGULAR = "File"
    BADGE_PLURAL = "Files"
    SUB_ITEMS = [
        {
            "id": "share_device_hub",
            "label": "Device Hub",
            "coming_soon": False,
            "svg": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><rect x="2" y="4" width="13" height="10" rx="2"/><rect x="16" y="10" width="6" height="10" rx="1.5"/><path d="M6 18h5m-2.5-4v4"/></g></svg>',
        },
        {
            "id": "share_memory_space",
            "label": "Memory Space",
            "coming_soon": False,
            "svg": COMMON_ICONS["my_box"],
        },
        {
            "id": "share_settings",
            "label": "Share Settings",
            "coming_soon": False,
            "svg": COMMON_ICONS["settings"],
        },
    ]


class _IosSwitch(QWidget):
    """Silky-smooth iOS pill toggle switch (cyber-lime active / obsidian rest)."""
    toggled = Signal(bool)

    def __init__(self, checked=True, parent=None):
        super().__init__(parent)
        self._checked = bool(checked)
        self._pos = 1.0 if self._checked else 0.0
        self.setFixedSize(40, 22)
        self.setCursor(Qt.PointingHandCursor)
        self.setMouseTracking(True)
        self.setAttribute(Qt.WA_Hover, True)
        self._tm = QTimer(self)
        self._tm.setInterval(16)
        self._tm.timeout.connect(self._step)

    def isChecked(self):
        return self._checked

    def setChecked(self, val, animate=True):
        val = bool(val)
        if self._checked == val and not animate:
            return
        self._checked = val
        if not animate:
            self._pos = 1.0 if val else 0.0
            self.update()
        elif not self._tm.isActive():
            self._tm.start()

    def _step(self):
        tgt = 1.0 if self._checked else 0.0
        if abs(tgt - self._pos) < 0.015:
            self._pos = tgt
            self._tm.stop()
        else:
            self._pos += (tgt - self._pos) * 0.28
        self.update()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            _play_asmr_tick()
            self._checked = not self._checked
            if not self._tm.isActive():
                self._tm.start()
            self.toggled.emit(self._checked)
            e.accept()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = float(self.width()), float(self.height())
        t = self._pos
        tr = QRectF(0.5, 0.5, w - 1.0, h - 1.0)
        tp = QPainterPath()
        tp.addRoundedRect(tr, (h - 1.0) * 0.5, (h - 1.0) * 0.5)

        bg = QColor(
            int(28 + (163 - 28) * t),
            int(30 + (230 - 30) * t),
            int(34 + (53 - 34) * t),
            255,
        )
        p.fillPath(tp, bg)
        rim = QColor(255, 255, 255, int(30 * (1.0 - t) + 0 * t))
        if rim.alpha() > 2:
            p.setPen(QPen(rim, 1.0))
            p.drawPath(tp)

        kx = 3.0 + t * (w - 22.0)
        knob_col = QColor("#060706") if t > 0.55 else QColor("#E4E4E7")
        p.setBrush(QBrush(knob_col))
        p.setPen(Qt.NoPen)
        p.drawEllipse(QRectF(kx, 3.0, 16.0, 16.0))
        p.end()


class _AccessSettingRow(QWidget):
    """Boxless iOS-smooth editable row for ACCESS (switch / live keybind / action)."""
    toggled = Signal(str, bool)
    hotkey_changed = Signal(str)
    action_clicked = Signal(str)

    def __init__(self, key, title, subtitle, svg_tpl, mode="switch", value=True, btn_label="", show_divider=True, parent=None):
        super().__init__(parent)
        self.key = key
        self.title = title
        self.subtitle = subtitle
        self.svg_tpl = svg_tpl
        self.mode = mode  # 'switch' | 'hotkey' | 'action'
        self.show_divider = show_divider
        self._h = 0.0
        self._target = 0.0
        self._capturing_key = False
        self.setFixedHeight(52)
        self.setFocusPolicy(Qt.StrongFocus if mode == "hotkey" else Qt.NoFocus)

        self._tm = QTimer(self)
        self._tm.setInterval(16)
        self._tm.timeout.connect(self._step)

        self.switch = None
        self.btn_right = None

        if mode in ("switch", "hotkey"):
            self.switch = _IosSwitch(bool(value), self)
            self.switch.toggled.connect(lambda v: self.toggled.emit(self.key, v))

        if mode == "hotkey":
            self.btn_right = QPushButton(str(btn_label or "Win+Shift+M"), self)
            self.btn_right.setFixedHeight(24)
            self.btn_right.setCursor(Qt.PointingHandCursor)
            self.btn_right.setToolTip("Click to record a new shortcut keybind")
            self.btn_right.clicked.connect(self._start_capture)
            self._style_hotkey_pill(False)
        elif mode == "action":
            self.btn_right = QPushButton(str(btn_label or "Apply"), self)
            self.btn_right.setFixedHeight(25)
            self.btn_right.setCursor(Qt.PointingHandCursor)
            self.btn_right.setStyleSheet(
                "QPushButton { background: rgba(163,230,53,0.14); color: #a3e635; border: 1px solid rgba(163,230,53,0.48); "
                "border-radius: 7px; padding: 0px 12px; font-size: 9.5px; font-weight: 700; "
                "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; }"
                "QPushButton:hover { background: rgba(163,230,53,0.28); color: #FFFFFF; border-color: #a3e635; }"
            )
            self.btn_right.clicked.connect(lambda: (_play_asmr_tick(), self.action_clicked.emit(self.key)))

    def _style_hotkey_pill(self, recording):
        if not self.btn_right:
            return
        if recording:
            self.btn_right.setText("Press Keys...")
            self.btn_right.setStyleSheet(
                "QPushButton { background: #1E2E14; color: #FFFFFF; border: 1px solid #a3e635; "
                "border-radius: 7px; padding: 0px 10px; font-size: 9px; font-weight: 700; "
                "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; }"
            )
        else:
            self.btn_right.setStyleSheet(
                "QPushButton { background: rgba(255,255,255,0.06); color: #E4E4E7; border: 1px solid rgba(255,255,255,0.16); "
                "border-radius: 7px; padding: 0px 10px; font-size: 9px; font-weight: 700; "
                "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; }"
                "QPushButton:hover { border-color: #a3e635; color: #a3e635; background: rgba(163,230,53,0.12); }"
            )

    def _start_capture(self):
        _play_asmr_tick()
        self._capturing_key = True
        self._style_hotkey_pill(True)
        self.setFocus()

    def set_hotkey_label(self, txt):
        self._capturing_key = False
        if self.btn_right:
            self.btn_right.setText(txt)
            self._style_hotkey_pill(False)

    def flash_action(self, msg, restore_msg):
        if self.btn_right:
            self.btn_right.setText(msg)
            QTimer.singleShot(1600, lambda: self.btn_right.setText(restore_msg))

    def keyPressEvent(self, e):
        if self._capturing_key:
            k = e.key()
            if k in (Qt.Key_Shift, Qt.Key_Control, Qt.Key_Alt, Qt.Key_Meta, Qt.Key_Super_L, Qt.Key_Super_R):
                return
            if k == Qt.Key_Escape:
                self._capturing_key = False
                self._style_hotkey_pill(False)
                return
            mods = e.modifiers()
            parts = []
            if mods & Qt.MetaModifier:
                parts.append("Win")
            if mods & Qt.ControlModifier:
                parts.append("Ctrl")
            if mods & Qt.AltModifier:
                parts.append("Alt")
            if mods & Qt.ShiftModifier:
                parts.append("Shift")
            key_name = None
            if Qt.Key_A <= k <= Qt.Key_Z:
                key_name = chr(k)
            elif Qt.Key_0 <= k <= Qt.Key_9:
                key_name = chr(k)
            elif Qt.Key_F1 <= k <= Qt.Key_F12:
                key_name = f"F{k - Qt.Key_F1 + 1}"
            elif k == Qt.Key_Space:
                key_name = "Space"
            if parts and key_name:
                combo = "+".join(parts + [key_name])
                _play_asmr_tick()
                self.set_hotkey_label(combo)
                self.hotkey_changed.emit(combo)
            e.accept()
            return
        super().keyPressEvent(e)

    def focusOutEvent(self, e):
        if self._capturing_key:
            self._capturing_key = False
            self._style_hotkey_pill(False)
        super().focusOutEvent(e)

    def resizeEvent(self, e):
        w, h = self.width(), self.height()
        if self.mode == "hotkey" and self.switch and self.btn_right:
            self.switch.move(w - 18 - self.switch.width(), (h - self.switch.height()) // 2)
            bw = max(84, self.btn_right.sizeHint().width() + 8)
            self.btn_right.setFixedWidth(bw)
            self.btn_right.move(self.switch.x() - 10 - bw, (h - self.btn_right.height()) // 2)
        elif self.mode == "switch" and self.switch:
            self.switch.move(w - 18 - self.switch.width(), (h - self.switch.height()) // 2)
        elif self.mode == "action" and self.btn_right:
            bw = max(72, self.btn_right.sizeHint().width() + 4)
            self.btn_right.setFixedWidth(bw)
            self.btn_right.move(w - 18 - bw, (h - self.btn_right.height()) // 2)
        super().resizeEvent(e)

    def _step(self):
        if abs(self._target - self._h) < 0.008:
            self._h = self._target
            self._tm.stop()
        else:
            self._h += (self._target - self._h) * 0.24
        self.update()

    def enterEvent(self, e):
        self._target = 1.0
        if not self._tm.isActive():
            self._tm.start()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._target = 0.0
        if not self._tm.isActive():
            self._tm.start()
        super().leaveEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        w, h = float(self.width()), float(self.height())
        hv = self._h

        pad_x = 12.0
        pill = QPainterPath()
        pill.addRoundedRect(QRectF(pad_x, 2.0, w - pad_x * 2.0, h - 4.0), 9.0, 9.0)
        if hv > 0.008:
            grad_hv = QLinearGradient(pad_x, 0.0, w - pad_x, h)
            grad_hv.setColorAt(0.0, QColor(18, 28, 14, int(225 * hv)))
            grad_hv.setColorAt(1.0, QColor(11, 17, 9, int(220 * hv)))
            p.fillPath(pill, grad_hv)
            p.setPen(QPen(QColor(163, 230, 53, int(145 * hv)), 0.95))
            p.drawPath(pill)

        rc = int(218 * (1.0 - hv) + 163 * hv)
        gc = int(222 * (1.0 - hv) + 230 * hv)
        bc = int(228 * (1.0 - hv) + 53 * hv)
        ico_col = f"#{rc:02x}{gc:02x}{bc:02x}"
        QSvgRenderer(QByteArray(self.svg_tpl.replace("{col}", ico_col).encode("utf-8"))).render(
            p, QRectF(22.0 + hv * 1.5, (h - 16.0) * 0.5, 16.0, 16.0)
        )

        tx = 48.0 + hv * 2.0
        right_res = 158.0 if self.mode == "hotkey" else 96.0
        f_title = QFont("Segoe UI Variable")
        f_title.setStyleName("Display Bold" if hv > 0.45 else "Text Semibold")
        f_title.setPointSizeF(9.6)
        _draw_crisp_text(p, QRectF(tx, 8.0, w - tx - right_res, 18.0), False, f_title, QColor("#FFFFFF") if hv > 0.3 else QColor("#F4F4F5"), self.title)

        f_sub = QFont("Segoe UI Variable")
        f_sub.setStyleName("Text Semibold")
        f_sub.setPointSizeF(8.0)
        _draw_crisp_text(p, QRectF(tx, 27.0, w - tx - right_res, 16.0), False, f_sub, QColor("#B4BAC5") if hv > 0.3 else QColor("#888E99"), self.subtitle)

        if self.show_divider and hv < 0.05:
            p.setPen(QPen(QColor(255, 255, 255, 14), 1.0))
            p.drawLine(QPointF(48.0, h - 0.5), QPointF(w - 20.0, h - 0.5))
        p.end()


class SuperAccessSettingsWindow(QWidget):
    """
    ACCESS / SETTINGS / SHORTCUTS Unified Control Sheet:
      - Boxless iOS-smooth toggles + inline editable Shortcut Keybind + one-click system integration
      - Pure #040405 obsidian + white + cyber-lime (#a3e635) matched 1:1 to Main Menu
    """

    def __init__(self, on_back=None, on_settings_changed=None, parent=None):
        super().__init__(parent)
        self.on_back = on_back
        self.on_settings_changed = on_settings_changed
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Window | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(840, 620)
        from ui_theme import apply_window_identity
        apply_window_identity(self, "TheSuperMouse - Settings")
        self._dragging = False
        self._drag_offset = QPoint()
        self._setting_rows = {}

        base_assets = ASSETS_DIR
        logo_fp = os.path.join(base_assets, "supermouse_app_logo_cropped.png")
        if not os.path.exists(logo_fp):
            logo_fp = os.path.join(base_assets, "supermouse_app_logo_trans.png")
        if os.path.exists(logo_fp):
            li = QImage(logo_fp)
            if not li.isNull():
                dpr = _native_dpr(self)
                li = li.scaledToHeight(max(20, int(round(20 * dpr))), Qt.SmoothTransformation)
                self.logo_pix = QPixmap.fromImage(li)
                self.logo_pix.setDevicePixelRatio(dpr)
            else:
                self.logo_pix = None
        else:
            self.logo_pix = None

        self._load_cfg()
        self._build_ui()

    def _load_cfg(self):
        try:
            from global_triggers import load_access_settings
            self.cfg = load_access_settings()
        except Exception:
            self.cfg = {
                "hotkey_enabled": True, "master_hotkey": "Win+Shift+M",
                "mouse_combo_enabled": True, "touchpad_gesture_enabled": True,
                "selection_theme_enabled": True, "autostart_enabled": True,
            }

    def _save_and_notify(self):
        try:
            from global_triggers import save_access_settings
            self.cfg = save_access_settings(self.cfg)
        except Exception:
            pass
        if callable(self.on_settings_changed):
            self.on_settings_changed(dict(self.cfg))

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        header = QWidget(self)
        header.setFixedHeight(52)
        header.setCursor(Qt.OpenHandCursor)
        hdr = QHBoxLayout(header)
        hdr.setContentsMargins(12, 0, 14, 0)
        self.btn_back = CleanBackButton("Back to Quick Menu", box_size=30, icon_size=15, on_press_tick=_play_asmr_tick, parent=header)
        self.btn_back.clicked.connect(lambda: self.switch_out_asmr_animation(on_finished=self.on_back))
        hdr.addWidget(self.btn_back, alignment=Qt.AlignVCenter)
        hdr.addStretch()
        btn_x = _TopCloseButton(header)
        btn_x.clicked.connect(self.close_with_pull_animation)
        hdr.addWidget(btn_x, alignment=Qt.AlignVCenter)
        root.addWidget(header)

        eyebrow = QWidget(self)
        eyebrow.setFixedHeight(18)
        eb = QHBoxLayout(eyebrow)
        eb.setContentsMargins(18, 0, 18, 0)
        l_sec = QLabel("ACCESS · SETTINGS & SHORTCUTS", eyebrow)
        l_sec.setStyleSheet(
            "color: rgba(255, 255, 255, 0.44); font-size: 8px; font-weight: 700; "
            "letter-spacing: 1.2px; background: transparent; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        eb.addWidget(l_sec)
        eb.addStretch()
        l_cnt = QLabel("Live Controls", eyebrow)
        l_cnt.setStyleSheet(
            "color: rgba(255, 255, 255, 0.28); font-size: 8px; font-weight: 600; "
            "background: transparent; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        eb.addWidget(l_cnt)
        root.addWidget(eyebrow)
        root.addSpacing(4)

        rows_spec = [
            ("hotkey_enabled", "Master Keyboard Shortcut", "Click badge to edit keybind · toggle active", "hotkey", self.cfg.get("hotkey_enabled", True), self.cfg.get("master_hotkey", "Win+Shift+M"),
             '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0" d="M15 6v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3V6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3"/></svg>'),
            ("mouse_combo_enabled", "Mouse Chord Trigger", "Hold Left+Right Click & press Tab or S", "switch", self.cfg.get("mouse_combo_enabled", True), "",
             '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0" d="M4.037 4.688a.495.495 0 0 1 .651-.651l16 6.5a.5.5 0 0 1-.063.947l-6.124 1.58a2 2 0 0 0-1.438 1.435l-1.579 6.126a.5.5 0 0 1-.947.063z"/></svg>'),
            ("touchpad_gesture_enabled", "Laptop Touchpad Gesture", "Hold Shift + Win + double-tap touchpad", "switch", self.cfg.get("touchpad_gesture_enabled", True), "",
             '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0" d="M20 16V7a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v9m16 0H4m16 0 1.28 2.55a1 1 0 0 1-.9 1.45H3.62a1 1 0 0 1-.9-1.45L4 16"/></svg>'),
            ("selection_theme_enabled", "Cyber-Lime Text Selection", "Apply green-lime selection across Windows", "switch", self.cfg.get("selection_theme_enabled", True), "",
             '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0" d="M12 4v16M4 7V5a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v2M9 20h6"/></svg>'),
            ("autostart_enabled", "Launch at Windows Login", "Start silently in taskbar tray automatically", "switch", self.cfg.get("autostart_enabled", True), "",
             '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M3 15h18"/></g></svg>'),
            ("win11_menus", "Win11 Right-Click Menus", "Refresh Desktop, Folder & File context entries", "action", True, "Apply",
             '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><rect width="20" height="14" x="2" y="3" rx="2"/><path d="M8 21h8m-4-4v4"/></g></svg>'),
            ("browser_ext", "Browser Extension Folder", "Copy Chrome / Edge companion folder path", "action", True, "Copy Path",
             '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20M2 12h20"/></g></svg>'),
        ]

        wrap = QWidget(self)
        wl = QVBoxLayout(wrap)
        wl.setContentsMargins(0, 2, 0, 4)
        wl.setSpacing(0)

        for idx, (key, title, sub, mode, val, lbl, svg) in enumerate(rows_spec):
            r = _AccessSettingRow(key, title, sub, svg, mode=mode, value=val, btn_label=lbl, show_divider=(idx < len(rows_spec) - 1), parent=wrap)
            r.toggled.connect(self._on_toggled)
            r.hotkey_changed.connect(self._on_hotkey_edited)
            r.action_clicked.connect(self._on_action_clicked)
            wl.addWidget(r)
            self._setting_rows[key] = r
        root.addWidget(wrap, stretch=1)

        div = QFrame(self)
        div.setFixedHeight(1)
        div.setStyleSheet("background-color: rgba(255, 255, 255, 0.08); margin: 0 18px;")
        root.addWidget(div)

        foot = QWidget(self)
        foot.setFixedHeight(44)
        fl = QHBoxLayout(foot)
        fl.setContentsMargins(18, 0, 18, 0)
        lbl_auto = QLabel("Changes apply automatically", foot)
        lbl_auto.setStyleSheet(
            "color: rgba(255, 255, 255, 0.34); font-size: 8.5px; font-weight: 500; "
            "background: transparent; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        fl.addWidget(lbl_auto)
        fl.addStretch()

        self.btn_reset = QPushButton("Reset Defaults", foot)
        self.btn_reset.setCursor(Qt.PointingHandCursor)
        self.btn_reset.setStyleSheet(
            "QPushButton { background: rgba(255,255,255,0.04); color: #D4D4D8; border: 1px solid rgba(255,255,255,0.12); "
            "border-radius: 8px; padding: 5px 12px; font-size: 9.5px; font-weight: 600; "
            "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif; }"
            "QPushButton:hover { border-color: rgba(163,230,53,0.75); color: #FFFFFF; background: rgba(163,230,53,0.12); }"
        )
        self.btn_reset.clicked.connect(lambda: (_play_asmr_tick(), self._reset_defaults()))
        fl.addWidget(self.btn_reset)
        root.addWidget(foot)

        lbl_ver = QLabel("THE SUPERMOUSE v1.0", self)
        lbl_ver.setAlignment(Qt.AlignCenter)
        lbl_ver.setFixedHeight(18)
        lbl_ver.setStyleSheet(
            "color: rgba(255, 255, 255, 0.34); font-size: 8px; font-weight: 600; "
            "letter-spacing: 0.9px; background: transparent; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        root.addWidget(lbl_ver)
        root.addSpacing(5)

    def _on_toggled(self, key, val):
        self.cfg[key] = bool(val)
        self._save_and_notify()

    def _on_hotkey_edited(self, new_combo):
        self.cfg["master_hotkey"] = new_combo
        self.cfg["hotkey_enabled"] = True
        if "hotkey_enabled" in self._setting_rows and self._setting_rows["hotkey_enabled"].switch:
            self._setting_rows["hotkey_enabled"].switch.setChecked(True)
        self._save_and_notify()

    def _on_action_clicked(self, key):
        if key == "win11_menus":
            try:
                from windows_integration import register_windows_context_menus
                ok = register_windows_context_menus()
                self._setting_rows[key].flash_action("Applied ✓" if ok else "Failed", "Apply")
            except Exception:
                self._setting_rows[key].flash_action("Error", "Apply")
        elif key == "browser_ext":
            ext_dir = os.path.join(BASE_DIR, "thesupermouse", "browser_selection_theme")
            QApplication.clipboard().setText(ext_dir)
            self._setting_rows[key].flash_action("Copied ✓", "Copy Path")

    def _reset_defaults(self):
        try:
            from global_triggers import DEFAULT_ACCESS_SETTINGS
            self.cfg = dict(DEFAULT_ACCESS_SETTINGS)
        except Exception:
            pass
        for k, row in self._setting_rows.items():
            if row.switch and k in self.cfg:
                row.switch.setChecked(self.cfg[k], animate=True)
            if k == "hotkey_enabled":
                row.set_hotkey_label(self.cfg.get("master_hotkey", "Win+Shift+M"))
        self._save_and_notify()

    def open_asmr_switch(self):
        """Quick, silky normal fade-in at steady position (no vertical up/down bounce)."""
        self._load_cfg()
        if "hotkey_enabled" in self._setting_rows:
            self._setting_rows["hotkey_enabled"].set_hotkey_label(self.cfg.get("master_hotkey", "Win+Shift+M"))
        scr = (QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()).availableGeometry()
        w, h = self.width(), self.height()
        tx, ty = scr.center().x() - w // 2, scr.center().y() - h // 2
        self.setGeometry(tx, ty, w, h)
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.activateWindow()
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(135)
        af.setStartValue(0.0)
        af.setEndValue(1.0)
        af.setEasingCurve(QEasingCurve.OutCubic)
        self.anim_in = af
        self.anim_in.start()

    def switch_out_asmr_animation(self, on_finished=None):
        """Quick, silky normal fade-out back to Cursor Menu (no vertical up/down slide)."""
        if not self.isVisible():
            if on_finished:
                on_finished()
            return
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(110)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        af.setEasingCurve(QEasingCurve.OutCubic)
        def _done():
            self.hide()
            if on_finished:
                on_finished()
        af.finished.connect(_done)
        self.anim_out = af
        self.anim_out.start()

    def close_with_pull_animation(self, on_finished=None):
        if not self.isVisible():
            if on_finished:
                on_finished()
            return
        full = (QApplication.screenAt(self.pos()) or QApplication.primaryScreen()).geometry()
        curr = self.geometry()
        ag = QPropertyAnimation(self, b"geometry")
        ag.setDuration(300)
        ag.setStartValue(curr)
        ag.setEndValue(QRect(curr.x(), full.bottom() + 20, curr.width(), curr.height()))
        ag.setEasingCurve(QEasingCurve.InCubic)
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(260)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        self.anim_out = QParallelAnimationGroup(self)
        self.anim_out.addAnimation(ag)
        self.anim_out.addAnimation(af)
        def _done():
            self.hide()
            if on_finished:
                on_finished()
        self.anim_out.finished.connect(_done)
        self.anim_out.start()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton and e.position().y() <= 52.0:
            self._dragging = True
            self._drag_offset = e.globalPosition().toPoint() - self.pos()
            e.accept()
            return
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        if self._dragging:
            self.move(e.globalPosition().toPoint() - self._drag_offset)
            e.accept()

    def mouseReleaseEvent(self, e):
        self._dragging = False
        super().mouseReleaseEvent(e)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.close_with_pull_animation()
        else:
            super().keyPressEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        w, h = float(self.width()), float(self.height())
        card = QPainterPath()
        card.addRoundedRect(QRectF(0.5, 0.5, w - 1.0, h - 1.0), 14.0, 14.0)
        p.fillPath(card, QColor(4, 4, 5, 254))
        p.setPen(QPen(QColor(255, 255, 255, 28), 1.0))
        p.drawPath(card)

        bx, by_c = 48.0, 26.0
        if self.logo_pix and not self.logo_pix.isNull():
            ldpr = max(1.0, float(self.logo_pix.devicePixelRatio() or 1.0))
            lw = self.logo_pix.width() / ldpr
            lh = self.logo_pix.height() / ldpr
            p.drawPixmap(int(round(bx)), int(round(by_c - lh * 0.5)), self.logo_pix)
            bx += lw + 8.0
        fl = QFont("Segoe UI Variable")
        fl.setStyleName("Display Bold")
        fl.setPointSizeF(11.4)
        fl.setLetterSpacing(QFont.AbsoluteSpacing, 0.35)
        fl.setHintingPreference(QFont.PreferNoHinting)
        probe = QPainterPath()
        probe.addText(0.0, 0.0, fl, "ACCESS")
        br = probe.boundingRect()
        base_y = by_c - (br.top() + br.height() * 0.5)

        p1 = QPainterPath()
        p1.addText(bx, base_y, fl, "ACCESS")
        p.fillPath(p1, QColor("#FFFFFF"))
        smx = bx + p1.boundingRect().width() + 5.5
        p2 = QPainterPath()
        p2.addText(smx, base_y, fl, "& SETTINGS")
        b2 = p2.boundingRect()
        g = QLinearGradient(b2.left(), 0.0, b2.right(), 0.0)
        g.setColorAt(0.0, QColor("#FFFF00"))
        g.setColorAt(1.0, QColor("#00FF85"))
        p.fillPath(p2, g)
        p.end()


class _AccessMethodRow(QWidget):
    """Boxless iOS-smooth read-only info row matched 1:1 to SuperMouse Main Menu."""
    clicked = Signal(str)

    def __init__(self, row_id, title, subtitle, hint_text, svg_tpl, show_divider=True, parent=None):
        super().__init__(parent)
        self.row_id = row_id
        self.title = title
        self.subtitle = subtitle
        self.hint_text = hint_text
        self.svg_tpl = svg_tpl
        self.show_divider = show_divider
        self.setFixedHeight(48)

        self._h = 0.0
        self._target = 0.0
        self._tm = QTimer(self)
        self._tm.setInterval(16)
        self._tm.timeout.connect(self._step)

    def set_hint(self, txt):
        self.hint_text = str(txt)
        self.update()

    def _step(self):
        if abs(self._target - self._h) < 0.008:
            self._h = self._target
            self._tm.stop()
        else:
            self._h += (self._target - self._h) * 0.24
        self.update()

    def enterEvent(self, e):
        self._target = 1.0
        if not self._tm.isActive():
            self._tm.start()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._target = 0.0
        if not self._tm.isActive():
            self._tm.start()
        super().leaveEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        w, h = float(self.width()), float(self.height())
        hv = self._h

        pad_x = 12.0
        pill = QPainterPath()
        pill.addRoundedRect(QRectF(pad_x, 2.0, w - pad_x * 2.0, h - 4.0), 9.0, 9.0)

        if hv > 0.008:
            p.fillPath(pill, QColor(255, 255, 255, int(10 * hv)))
            p.setPen(QPen(QColor(255, 255, 255, int(24 * hv)), 0.9))
            p.drawPath(pill)

        rc = int(218 * (1.0 - hv) + 163 * hv)
        gc = int(222 * (1.0 - hv) + 230 * hv)
        bc = int(228 * (1.0 - hv) + 53 * hv)
        ico_col = f"#{rc:02x}{gc:02x}{bc:02x}"
        QSvgRenderer(QByteArray(self.svg_tpl.replace("{col}", ico_col).encode("utf-8"))).render(
            p, QRectF(22.0, (h - 16.0) * 0.5, 16.0, 16.0)
        )

        tx = 48.0
        f_hint = QFont("Segoe UI Variable")
        f_hint.setStyleName("Text Semibold")
        f_hint.setPointSizeF(7.8)
        h_adv = float(QFontMetrics(f_hint).horizontalAdvance(self.hint_text))

        f_title = QFont("Segoe UI Variable")
        f_title.setStyleName("Text Semibold" if hv < 0.45 else "Display Bold")
        f_title.setPointSizeF(9.6)
        _draw_crisp_text(p, QRectF(tx, 7.0, w - tx - h_adv - 36.0, 18.0), False, f_title, QColor("#FFFFFF") if hv > 0.3 else QColor("#F4F4F5"), self.title)

        f_sub = QFont("Segoe UI Variable")
        f_sub.setStyleName("Text Semibold")
        f_sub.setPointSizeF(8.0)
        _draw_crisp_text(p, QRectF(tx, 25.0, w - tx - h_adv - 36.0, 16.0), False, f_sub, QColor("#B4BAC5") if hv > 0.3 else QColor("#888E99"), self.subtitle)

        h_col = QColor("#a3e635") if hv > 0.45 else QColor(255, 255, 255, 118)
        _draw_crisp_text(p, QRectF(w - 20.0 - h_adv, 0.0, h_adv + 2.0, h), False, f_hint, h_col, self.hint_text)

        if self.show_divider and hv < 0.05:
            p.setPen(QPen(QColor(255, 255, 255, 14), 1.0))
            p.drawLine(QPointF(48.0, h - 0.5), QPointF(w - 20.0, h - 0.5))
        p.end()


class SuperInfoReadOnlyWindow(QWidget):
    """
    Pure READ-ONLY 'INFO' Sheet (no toggles, no edits — clean reading only!):
      - iOS-smooth boxless rows on #040405 obsidian canvas matched 1:1 to Main Menu
    """

    METHODS = [
        ("tray",       "Taskbar Tray Menu",     "Right-click tray icon for Snap, Box & Design",   "Taskbar",     '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M3 15h18"/></g></svg>'),
        ("hotkey",     "Master Keyboard Keybind", "Summon or dismiss Main Menu from any window",    "Win+Shift+M", '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0" d="M15 6v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3V6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3"/></svg>'),
        ("combo",      "Mouse Chord Trigger",   "Hold Left+Right Click & press Tab or S",     "L+R + Tab/S", '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0" d="M4.037 4.688a.495.495 0 0 1 .651-.651l16 6.5a.5.5 0 0 1-.063.947l-6.124 1.58a2 2 0 0 0-1.438 1.435l-1.579 6.126a.5.5 0 0 1-.947.063z"/></svg>'),
        ("touchpad",   "Laptop Touchpad",       "Hold Shift + Win and double-tap touchpad",        "Shift+Win",   '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0" d="M20 16V7a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v9m16 0H4m16 0 1.28 2.55a1 1 0 0 1-.9 1.45H3.62a1 1 0 0 1-.9-1.45L4 16"/></svg>'),
        ("context",    "Win11 Right-Click",     "Desktop & Folder context menus launch tools",     "Top-Level",   '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><rect width="20" height="14" x="2" y="3" rx="2"/><path d="M8 21h8m-4-4v4"/></g></svg>'),
        ("supersnap",  "Super Snap & Pin",      "Capture, zoom, annotate outside & save to Box",   "Snapshot",    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><circle cx="6" cy="6" r="3"/><path d="M8.12 8.12L12 12m8-8L8.12 15.88"/><circle cx="6" cy="18" r="3"/><path d="M14.8 14.8L20 20"/></g></svg>'),
        ("design",     "Super Get Design",      "Style Windows Folders, File Shortcuts & Cursors", "Studio",      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0" d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/></svg>'),
        ("browser",    "Browser Companion",     "Chrome/Edge bottom menu & cyber-lime highlight",  "Extension",   '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20M2 12h20"/></g></svg>'),
    ]

    def __init__(self, on_back=None, parent=None):
        super().__init__(parent)
        self.on_back = on_back
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(468, 514)
        self._dragging = False
        self._drag_offset = QPoint()
        self._row_map = {}

        base_assets = ASSETS_DIR
        logo_fp = os.path.join(base_assets, "supermouse_app_logo_cropped.png")
        if not os.path.exists(logo_fp):
            logo_fp = os.path.join(base_assets, "supermouse_app_logo_trans.png")
        if os.path.exists(logo_fp):
            li = QImage(logo_fp)
            if not li.isNull():
                dpr = _native_dpr(self)
                li = li.scaledToHeight(max(20, int(round(20 * dpr))), Qt.SmoothTransformation)
                self.logo_pix = QPixmap.fromImage(li)
                self.logo_pix.setDevicePixelRatio(dpr)
            else:
                self.logo_pix = None
        else:
            self.logo_pix = None
        self._build_ui()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        header = QWidget(self)
        header.setFixedHeight(52)
        header.setCursor(Qt.OpenHandCursor)
        hdr = QHBoxLayout(header)
        hdr.setContentsMargins(12, 0, 14, 0)
        self.btn_back = CleanBackButton("Back to Quick Menu", box_size=30, icon_size=15, on_press_tick=_play_asmr_tick, parent=header)
        self.btn_back.clicked.connect(lambda: self.switch_out_asmr_animation(on_finished=self.on_back))
        hdr.addWidget(self.btn_back, alignment=Qt.AlignVCenter)
        hdr.addStretch()
        btn_x = _TopCloseButton(header)
        btn_x.clicked.connect(self.close_with_pull_animation)
        hdr.addWidget(btn_x, alignment=Qt.AlignVCenter)
        root.addWidget(header)

        eyebrow = QWidget(self)
        eyebrow.setFixedHeight(18)
        eb = QHBoxLayout(eyebrow)
        eb.setContentsMargins(18, 0, 18, 0)
        l_sec = QLabel("OVERVIEW & GUIDE", eyebrow)
        l_sec.setStyleSheet(
            "color: rgba(255, 255, 255, 0.44); font-size: 8px; font-weight: 700; "
            "letter-spacing: 1.2px; background: transparent; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        eb.addWidget(l_sec)
        eb.addStretch()
        l_cnt = QLabel("Read Only · v1.0", eyebrow)
        l_cnt.setStyleSheet(
            "color: rgba(255, 255, 255, 0.28); font-size: 8px; font-weight: 600; "
            "background: transparent; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        eb.addWidget(l_cnt)
        root.addWidget(eyebrow)
        root.addSpacing(4)

        list_wrap = QWidget(self)
        bl = QVBoxLayout(list_wrap)
        bl.setContentsMargins(0, 2, 0, 4)
        bl.setSpacing(0)
        for idx, (rid, title, sub, hint, svg) in enumerate(self.METHODS):
            r = _AccessMethodRow(rid, title, sub, hint, svg, show_divider=(idx < len(self.METHODS) - 1), parent=list_wrap)
            bl.addWidget(r)
            self._row_map[rid] = r
        root.addWidget(list_wrap, stretch=1)

        div = QFrame(self)
        div.setFixedHeight(1)
        div.setStyleSheet("background-color: rgba(255, 255, 255, 0.08); margin: 0 18px;")
        root.addWidget(div)
        root.addSpacing(6)

        lbl_ver = QLabel("THE SUPERMOUSE v1.0", self)
        lbl_ver.setAlignment(Qt.AlignCenter)
        lbl_ver.setFixedHeight(20)
        lbl_ver.setStyleSheet(
            "color: rgba(255, 255, 255, 0.34); font-size: 8px; font-weight: 600; "
            "letter-spacing: 0.9px; background: transparent; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        root.addWidget(lbl_ver)
        root.addSpacing(8)

    def open_asmr_switch(self):
        """Quick, silky normal fade-in at steady position (no vertical bounce)."""
        try:
            from global_triggers import load_access_settings
            cfg = load_access_settings()
            if "hotkey" in self._row_map:
                self._row_map["hotkey"].set_hint(cfg.get("master_hotkey", "Win+Shift+M"))
        except Exception:
            pass
        scr = (QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()).availableGeometry()
        w, h = self.width(), self.height()
        tx, ty = scr.center().x() - w // 2, scr.center().y() - h // 2
        self.setGeometry(tx, ty, w, h)
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.activateWindow()
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(135)
        af.setStartValue(0.0)
        af.setEndValue(1.0)
        af.setEasingCurve(QEasingCurve.OutCubic)
        self.anim_in = af
        self.anim_in.start()

    def switch_out_asmr_animation(self, on_finished=None):
        """Quick, silky normal fade-out back to Cursor Menu (no vertical slide)."""
        if not self.isVisible():
            if on_finished:
                on_finished()
            return
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(110)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        af.setEasingCurve(QEasingCurve.OutCubic)
        def _done():
            self.hide()
            if on_finished:
                on_finished()
        af.finished.connect(_done)
        self.anim_out = af
        self.anim_out.start()

    def close_with_pull_animation(self, on_finished=None):
        if not self.isVisible():
            if on_finished:
                on_finished()
            return
        full = (QApplication.screenAt(self.pos()) or QApplication.primaryScreen()).geometry()
        curr = self.geometry()
        ag = QPropertyAnimation(self, b"geometry")
        ag.setDuration(300)
        ag.setStartValue(curr)
        ag.setEndValue(QRect(curr.x(), full.bottom() + 20, curr.width(), curr.height()))
        ag.setEasingCurve(QEasingCurve.InCubic)
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(260)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        self.anim_out = QParallelAnimationGroup(self)
        self.anim_out.addAnimation(ag)
        self.anim_out.addAnimation(af)
        def _done():
            self.hide()
            if on_finished:
                on_finished()
        self.anim_out.finished.connect(_done)
        self.anim_out.start()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton and e.position().y() <= 52.0:
            self._dragging = True
            self._drag_offset = e.globalPosition().toPoint() - self.pos()
            e.accept()
            return
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        if self._dragging:
            self.move(e.globalPosition().toPoint() - self._drag_offset)
            e.accept()

    def mouseReleaseEvent(self, e):
        self._dragging = False
        super().mouseReleaseEvent(e)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.close_with_pull_animation()
        else:
            super().keyPressEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        w, h = float(self.width()), float(self.height())
        card = QPainterPath()
        card.addRoundedRect(QRectF(0.5, 0.5, w - 1.0, h - 1.0), 14.0, 14.0)
        p.fillPath(card, QColor(4, 4, 5, 254))
        p.setPen(QPen(QColor(255, 255, 255, 28), 1.0))
        p.drawPath(card)

        bx, by_c = 48.0, 26.0
        if self.logo_pix and not self.logo_pix.isNull():
            ldpr = max(1.0, float(self.logo_pix.devicePixelRatio() or 1.0))
            lw = self.logo_pix.width() / ldpr
            lh = self.logo_pix.height() / ldpr
            p.drawPixmap(int(round(bx)), int(round(by_c - lh * 0.5)), self.logo_pix)
            bx += lw + 8.0
        fl = QFont("Segoe UI Variable")
        fl.setStyleName("Display Bold")
        fl.setPointSizeF(11.4)
        fl.setLetterSpacing(QFont.AbsoluteSpacing, 0.35)
        fl.setHintingPreference(QFont.PreferNoHinting)
        probe = QPainterPath()
        probe.addText(0.0, 0.0, fl, "THE INFO")
        br = probe.boundingRect()
        base_y = by_c - (br.top() + br.height() * 0.5)

        p1 = QPainterPath()
        p1.addText(bx, base_y, fl, "THE")
        p.fillPath(p1, QColor("#FFFFFF"))
        smx = bx + p1.boundingRect().width() + 5.5
        p2 = QPainterPath()
        p2.addText(smx, base_y, fl, "INFO")
        b2 = p2.boundingRect()
        g = QLinearGradient(b2.left(), 0.0, b2.right(), 0.0)
        g.setColorAt(0.0, QColor("#FFFF00"))
        g.setColorAt(1.0, QColor("#00FF85"))
        p.fillPath(p2, g)
        p.end()


class SuperNotificationWindow(QWidget):
    """Sleek obsidian notification dialog for Dynamic Island update on 30 November."""

    def __init__(self, on_back=None, parent=None):
        super().__init__(parent, Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.on_back = on_back
        self.setFixedSize(384, 256)
        self._is_animating = False
        self._dragging = False
        self._drag_offset = QPoint()
        self._build_ui()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(16, 12, 16, 16)
        root.setSpacing(10)

        header = QWidget(self)
        header.setFixedHeight(38)
        hdr = QHBoxLayout(header)
        hdr.setContentsMargins(0, 0, 0, 0)
        self.btn_back = CleanBackButton("Back to Quick Menu", box_size=30, icon_size=15, on_press_tick=_play_asmr_tick, parent=header)
        self.btn_back.clicked.connect(lambda: self.switch_out_asmr_animation(on_finished=self.on_back))
        hdr.addWidget(self.btn_back, alignment=Qt.AlignVCenter)
        hdr.addStretch()
        btn_close = _TopCloseButton(header)
        btn_close.clicked.connect(self.close_with_pull_animation)
        hdr.addWidget(btn_close, alignment=Qt.AlignVCenter)
        root.addWidget(header)

        eb = QLabel("NOTIFICATIONS · UPCOMING RELEASE", self)
        eb.setStyleSheet(
            "color: rgba(255, 255, 255, 0.44); font-size: 8px; font-weight: 700; "
            "letter-spacing: 1.2px; background: transparent; font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        root.addWidget(eb)

        card = QFrame(self)
        card.setStyleSheet(
            "background: #08090C; border: 1px solid rgba(255, 255, 255, 0.12); "
            "border-radius: 12px; padding: 12px;"
        )
        cl = QVBoxLayout(card)
        cl.setContentsMargins(12, 12, 12, 12)
        cl.setSpacing(8)

        t_row = QHBoxLayout()
        title = QLabel("Super Dynamic Island", card)
        title.setStyleSheet(
            "color: #FFFFFF; font-size: 15px; font-weight: 800; background: transparent; "
            "font-family: 'Segoe UI Variable Display', 'Segoe UI', sans-serif;"
        )
        t_row.addWidget(title)
        t_row.addStretch()
        cl.addLayout(t_row)

        desc = QLabel(
            "A major update for Dynamic Island is arriving on 30 November. "
            "Experience fluid capsule notifications, floating live task tracking, ambient controls, and zero-lag pill animations right above your workspace.",
            card
        )
        desc.setWordWrap(True)
        desc.setStyleSheet(
            "color: #B4BAC5; font-size: 11px; font-weight: 500; line-height: 1.45; background: transparent; "
            "font-family: 'Segoe UI Variable Text', 'Segoe UI', sans-serif;"
        )
        cl.addWidget(desc)
        root.addWidget(card)
        root.addStretch()

    def open_asmr_switch(self):
        scr = (QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()).availableGeometry()
        w, h = self.width(), self.height()
        tx, ty = scr.center().x() - w // 2, scr.center().y() - h // 2
        self.setGeometry(tx, ty, w, h)
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.activateWindow()
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(135)
        af.setStartValue(0.0)
        af.setEndValue(1.0)
        af.setEasingCurve(QEasingCurve.OutCubic)
        self.anim_in = af
        self.anim_in.start()

    def switch_out_asmr_animation(self, on_finished=None):
        if not self.isVisible():
            if on_finished:
                on_finished()
            return
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(110)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        af.setEasingCurve(QEasingCurve.OutCubic)
        def _done():
            self.hide()
            if on_finished:
                on_finished()
        af.finished.connect(_done)
        self.anim_out = af
        self.anim_out.start()

    def close_with_pull_animation(self, on_finished=None):
        if not self.isVisible():
            if on_finished:
                on_finished()
            return
        full = (QApplication.screenAt(self.pos()) or QApplication.primaryScreen()).geometry()
        curr = self.geometry()
        ag = QPropertyAnimation(self, b"geometry")
        ag.setDuration(300)
        ag.setStartValue(curr)
        ag.setEndValue(QRect(curr.x(), full.bottom() + 20, curr.width(), curr.height()))
        ag.setEasingCurve(QEasingCurve.InCubic)
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(260)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        self.anim_out = QParallelAnimationGroup(self)
        self.anim_out.addAnimation(ag)
        self.anim_out.addAnimation(af)
        def _done():
            self.hide()
            if on_finished:
                on_finished()
        self.anim_out.finished.connect(_done)
        self.anim_out.start()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton and e.position().y() <= 44.0:
            self._dragging = True
            self._drag_offset = e.globalPosition().toPoint() - self.pos()
            e.accept()
            return
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        if self._dragging:
            self.move(e.globalPosition().toPoint() - self._drag_offset)
            e.accept()

    def mouseReleaseEvent(self, e):
        self._dragging = False
        super().mouseReleaseEvent(e)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.close_with_pull_animation()
        else:
            super().keyPressEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = float(self.width()), float(self.height())
        card = QPainterPath()
        card.addRoundedRect(QRectF(0.5, 0.5, w - 1.0, h - 1.0), 14.0, 14.0)
        p.fillPath(card, QColor(4, 4, 5, 254))
        p.setPen(QPen(QColor(255, 255, 255, 28), 1.0))
        p.drawPath(card)
        p.end()


class SuperReadExploreWindow(QWidget):
    """Sleek obsidian blog & explore dialog for SuperMouse."""

    def __init__(self, on_back=None, parent=None):
        super().__init__(parent)
        self.on_back = on_back
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(360, 480)
        self._dragging = False
        self._drag_offset = QPoint()

        root = QVBoxLayout(self)
        root.setContentsMargins(18, 16, 18, 16)
        root.setSpacing(14)

        hdr = QHBoxLayout()
        hdr.setContentsMargins(0, 0, 0, 0)
        self.back_btn = CleanBackButton("Back to Quick Menu", box_size=30, icon_size=15, on_press_tick=_play_asmr_tick, parent=self)
        self.back_btn.clicked.connect(self._handle_back)
        hdr.addWidget(self.back_btn)
        hdr.addSpacing(8)

        lbl = QLabel("Read & Explore", self)
        lbl.setStyleSheet("color: #FFFFFF; font-size: 14px; font-weight: 800; font-family: 'Segoe UI Variable Display', sans-serif;")
        hdr.addWidget(lbl)
        hdr.addStretch()

        self.close_btn = _TopCloseButton(self)
        self.close_btn.clicked.connect(self.close_with_pull_animation)
        hdr.addWidget(self.close_btn)
        root.addLayout(hdr)

        div = QFrame(self)
        div.setFixedHeight(1)
        div.setStyleSheet("background-color: rgba(255, 255, 255, 0.08);")
        root.addWidget(div)

        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet("background: transparent; border: none;")
        scroll_content = QWidget()
        scroll_layout = QVBoxLayout(scroll_content)
        scroll_layout.setContentsMargins(0, 0, 0, 0)
        scroll_layout.setSpacing(12)

        articles = [
            ("The Art of Zero-Lag Computing", "How SuperMouse synchronizes cursor momentum across Windows and mobile displays.", "Guide"),
            ("Introducing Dynamic Island", "Floating capsule alerts, audio visualizers, and task hubs right above your workspace.", "Update"),
            ("Design Philosophy 2.0", "Obsidian minimalism, boxless accounting ledger typography, and vibrant neon accents.", "Stories"),
        ]

        for title_txt, desc_txt, tag in articles:
            card = QFrame(scroll_content)
            card.setStyleSheet("background: rgba(255, 255, 255, 0.04); border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 10px; padding: 12px;")
            cl = QVBoxLayout(card)
            cl.setContentsMargins(12, 10, 12, 10)
            cl.setSpacing(4)

            top = QHBoxLayout()
            t_lbl = QLabel(title_txt, card)
            t_lbl.setStyleSheet("color: #FFFFFF; font-size: 12.5px; font-weight: 700; font-family: 'Segoe UI Variable Display', sans-serif;")
            top.addWidget(t_lbl)
            top.addStretch()

            tag_lbl = QLabel(tag, card)
            tag_lbl.setStyleSheet("color: #A3E635; font-size: 9px; font-weight: 800; background: rgba(163, 230, 53, 0.12); padding: 2px 6px; border-radius: 4px;")
            top.addWidget(tag_lbl)
            cl.addLayout(top)

            d_lbl = QLabel(desc_txt, card)
            d_lbl.setWordWrap(True)
            d_lbl.setStyleSheet("color: #94A3B8; font-size: 11px; font-weight: 500; line-height: 1.4;")
            cl.addWidget(d_lbl)
            scroll_layout.addWidget(card)

        scroll_layout.addStretch()
        scroll.setWidget(scroll_content)
        root.addWidget(scroll)

        btn_open = QPushButton("Open SuperMouse Stories ↗", self)
        btn_open.setFixedHeight(34)
        btn_open.setStyleSheet("""
            QPushButton {
                background: #A3E635; color: #000000; font-size: 12px; font-weight: 800;
                border-radius: 8px; border: none; font-family: 'Segoe UI Variable Display', sans-serif;
            }
            QPushButton:hover { background: #84CC16; }
        """)
        btn_open.clicked.connect(lambda: webbrowser.open("https://getsupermouse.netlify.app/about"))
        root.addWidget(btn_open)

    def _handle_back(self):
        self.switch_out_asmr_animation(on_finished=self.on_back)

    def open_asmr_switch(self):
        scr = (QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()).availableGeometry()
        w, h = self.width(), self.height()
        tx, ty = scr.center().x() - w // 2, scr.center().y() - h // 2
        self.move(tx, ty)
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.activateWindow()
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(120)
        af.setStartValue(0.0)
        af.setEndValue(1.0)
        af.start()
        self.anim_in = af

    def switch_out_asmr_animation(self, on_finished=None):
        if not self.isVisible():
            if on_finished: on_finished()
            return
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(110)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        def _done():
            self.hide()
            if on_finished: on_finished()
        af.finished.connect(_done)
        self.anim_out = af
        af.start()

    def close_with_pull_animation(self):
        self.switch_out_asmr_animation()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        path = QPainterPath()
        path.addRoundedRect(QRectF(0.5, 0.5, self.width() - 1, self.height() - 1), 14, 14)
        p.fillPath(path, QColor(6, 7, 9, 252))
        p.setPen(QPen(QColor(255, 255, 255, 25), 1.0))
        p.drawPath(path)
        p.end()


class _DropdownHeaderRow(QWidget):
    """Expandable Dropdown Header: 'Read and Settings' with continuous rotating chevron."""
    toggled = Signal(bool)

    def __init__(self, expanded=False, has_orange_alert=False, parent=None):
        super().__init__(parent)
        self.setFixedHeight(38)
        self.expanded = bool(expanded)
        self.has_orange_alert = bool(has_orange_alert)
        self._hover = 0.0
        self._target_hover = 0.0
        self._expand_ratio = 1.0 if self.expanded else 0.0
        self._anim = QTimer(self)
        self._anim.setInterval(16)
        self._anim.timeout.connect(self._step)
        self.setCursor(Qt.PointingHandCursor)
        self.setMouseTracking(True)
        self.setAttribute(Qt.WA_Hover, True)

    def set_has_orange_alert(self, val: bool):
        self.has_orange_alert = bool(val)
        self.update()

    def set_expand_ratio(self, ratio: float):
        self._expand_ratio = max(0.0, min(1.0, float(ratio)))
        self.update()

    def _step(self):
        if abs(self._target_hover - self._hover) < 0.01:
            self._hover = self._target_hover
            self._anim.stop()
        else:
            self._hover += (self._target_hover - self._hover) * 0.25
        self.update()

    def enterEvent(self, e):
        self._target_hover = 1.0
        if not self._anim.isActive():
            self._anim.start()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._target_hover = 0.0
        if not self._anim.isActive():
            self._anim.start()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.expanded = not self.expanded
            self.toggled.emit(self.expanded)
            self.update()
            e.accept()
            return
        super().mousePressEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        w, h = float(self.width()), float(self.height())
        hv = self._hover

        pill = QPainterPath()
        pill.addRoundedRect(QRectF(10.0, 1.5, w - 20.0, h - 3.0), 8.5, 8.5)
        if hv > 0.01 or self._expand_ratio > 0.05:
            bg_a = int(32 if self._expand_ratio > 0.5 else 24 * hv)
            p.fillPath(pill, QColor(255, 255, 255, bg_a))
            if hv > 0.05:
                p.setPen(QPen(QColor(255, 255, 255, int(40 * hv)), 0.9))
                p.drawPath(pill)

        # Crisp Sliders-Horizontal icon for READ AND SETTINGS (distinct from Access cog)
        col_hex = "#FFFFFF" if hv > 0.3 else "#EDEDEF"
        svg_code = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><line x1="21" x2="14" y1="4" y2="4"/><line x1="10" x2="3" y1="4" y2="4"/><line x1="21" x2="12" y1="12" y2="12"/><line x1="8" x2="3" y1="12" y2="12"/><line x1="21" x2="16" y1="20" y2="20"/><line x1="12" x2="3" y1="20" y2="20"/><line x1="14" x2="14" y1="2" y2="6"/><line x1="8" x2="8" y1="10" y2="14"/><line x1="16" x2="16" y1="18" y2="22"/></g></svg>'
        QSvgRenderer(QByteArray(svg_code.replace("{col}", col_hex).encode("utf-8"))).render(p, QRectF(18.0, (h - 16.0) * 0.5, 16.0, 16.0))

        # Title: Read and Settings (matching menu row standard typography)
        f = QFont()
        f.setFamilies(["Segoe UI Variable Display", "Segoe UI Variable Text", "Segoe UI", "Arial", "sans-serif"])
        wt = QFont.Weight.Bold if (hv >= 0.45 or self._expand_ratio > 0.5) else QFont.Weight.DemiBold
        f.setWeight(wt)
        f.setBold(hv >= 0.45 or self._expand_ratio > 0.5)
        f.setPointSizeF(9.6)
        f.setHintingPreference(QFont.PreferNoHinting)
        p.setFont(f)
        text_color = QColor("#FFFFFF") if (hv > 0.3 or self._expand_ratio > 0.5) else QColor("#EDEDEF")
        p.setPen(text_color)
        _draw_crisp_text(p, QRectF(44.0, 0.0, w - 70.0, h), False, f, text_color, "Read and Settings")

        # Dynamic alert dot: neon lime green (#A3E635) displayed when a server update is pending
        if self.has_orange_alert:
            rx = w - 46.0
            green_dot = QPainterPath()
            green_dot.addEllipse(QPointF(rx, h * 0.5), 3.5, 3.5)
            p.fillPath(green_dot, QColor("#A3E635"))
            p.setPen(QPen(QColor(163, 230, 53, 140), 1.0))
            p.drawPath(green_dot)

        # Chevron arrow that smoothly rotates continuously based on _expand_ratio
        p.setPen(QPen(QColor(255, 255, 255, int(150 + 60 * hv)), 1.6, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        cy = h * 0.5
        cx = w - 24.0
        dy = 2.0 * (1.0 - 2.0 * self._expand_ratio)
        p.drawLine(QPointF(cx - 4.0, cy - dy), QPointF(cx, cy + dy))
        p.drawLine(QPointF(cx, cy + dy), QPointF(cx + 4.0, cy - dy))
        p.end()


class _FollowCursorRow(QWidget):
    """Sleek row inside Quick Menu to toggle smooth cursor-following mode, perfectly matching _MenuItemRow aesthetics."""
    toggled = Signal(bool)

    _SVG_FOLLOW = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><path d="m14 4.1 1.2 1.2M5.1 8l-2.9-.8M6 12l-1.9 2M7.2 2.2 8 5.1m1.037 4.59a.498.498 0 0 1 .653-.653l11 4.5a.5.5 0 0 1-.074.949l-4.35 1.04a1 1 0 0 0-.74.74l-1.04 4.35a.5.5 0 0 1-.95.074z"/></g></svg>'

    def __init__(self, checked=False, parent=None):
        super().__init__(parent)
        self.setFixedHeight(38)
        self.setMouseTracking(True)
        self.setAttribute(Qt.WA_Hover, True)
        self._h = 0.0
        self._target = 0.0
        self._tm = QTimer(self)
        self._tm.setInterval(16)
        self._tm.timeout.connect(self._step)

        self.switch = _IosSwitch(bool(checked), self)
        self.switch.setFixedSize(36, 20)
        self.switch.toggled.connect(self._on_switch)

    def _on_switch(self, val):
        self.toggled.emit(bool(val))
        self.update()

    def set_checked(self, val):
        self.switch.setChecked(bool(val), animate=True)
        self.update()

    def resizeEvent(self, e):
        self.switch.move(int(self.width() - 18 - self.switch.width()), int((self.height() - self.switch.height()) * 0.5))
        super().resizeEvent(e)

    def _step(self):
        if abs(self._target - self._h) < 0.008:
            self._h = self._target
            self._tm.stop()
        else:
            self._h += (self._target - self._h) * 0.24
        self.update()

    def enterEvent(self, e):
        self._target = 1.0
        if not self._tm.isActive():
            self._tm.start()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._target = 0.0
        if not self._tm.isActive():
            self._tm.start()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.switch.setChecked(not self.switch.isChecked(), animate=True)
            self._on_switch(self.switch.isChecked())
            e.accept()
            return
        super().mousePressEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        w, h = float(self.width()), float(self.height())
        hv = self._h
        on = self.switch.isChecked()

        pill_rect = QRectF(10.0, 1.5, w - 20.0, h - 3.0)
        pill = QPainterPath()
        pill.addRoundedRect(pill_rect, 8.5, 8.5)

        if hv > 0.008:
            p.fillPath(pill, QColor(255, 255, 255, int(15 * hv)))
            p.setPen(QPen(QColor(255, 255, 255, int(30 * hv)), 0.9))
            p.drawPath(pill)

        col_hex = "#a3e635" if on else ("#FFFFFF" if hv > 0.3 else "#EDEDEF")
        QSvgRenderer(QByteArray(self._SVG_FOLLOW.replace("{col}", col_hex).encode("utf-8"))).render(
            p, QRectF(18.0, (h - 16.0) * 0.5, 16.0, 16.0)
        )

        f = QFont("Segoe UI Variable")
        f.setStyleName("Text Semibold")
        f.setPointSizeF(9.4)
        t_col = QColor("#FFFFFF") if hv > 0.3 else QColor("#EDEDEF")
        _draw_crisp_text(p, QRectF(44.0, 0.0, w - 104.0, h), False, f, t_col, "Follow Cursor")
        p.end()


SuperInfoAccessWindow = SuperInfoReadOnlyWindow


class SuperMouseQuickMenu(QWidget):
    """
    Seamless Open-Canvas Obsidian Quick Menu (288x400).
    """
    option_selected = Signal(str)

    # Genuine Official Lucide 24x24 Outline SVG Icons matching SuperMouseHUD (Image 1)
    PRIMARY_ITEMS = [
        {
            "id": "superedit",
            "label": "Super Edit",
            "coming_soon": False,
            "svg": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><path d="M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.375 2.625a1 1 0 0 1 3 3l-9.013 9.014a2 2 0 0 1-.853.505l-2.873.84a.5.5 0 0 1-.62-.62l.84-2.873a2 2 0 0 1 .506-.852z"/></g></svg>'
        },
        {
            "id": "super_pin",
            "label": "Super Snap & Pin",
            "coming_soon": False,
            "has_submenu": True,
            "svg": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><circle cx="6" cy="6" r="3"/><path d="M8.12 8.12L12 12m8-8L8.12 15.88"/><circle cx="6" cy="18" r="3"/><path d="M14.8 14.8L20 20"/></g></svg>'
        },
        {
            "id": "super_share",
            "label": "Super Share",
            "coming_soon": False,
            "has_submenu": True,
            "svg": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><path d="M18 8V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h8m-2 4v-3.96v3.15M7 19h5"/><rect width="6" height="10" x="16" y="12" rx="2"/></g></svg>'
        },
        {
            "id": "mouse",
            "label": "Super Mouse",
            "coming_soon": True,
            "svg": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0" d="M4.037 4.688a.495.495 0 0 1 .651-.651l16 6.5a.5.5 0 0 1-.063.947l-6.124 1.58a2 2 0 0 0-1.438 1.435l-1.579 6.126a.5.5 0 0 1-.947.063z"/></svg>'
        },
        {
            "id": "get_design",
            "label": "Super Get Design",
            "coming_soon": False,
            "svg": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0" d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/></svg>'
        },
        {
            "id": "super_dynamic_island",
            "label": "Super Dynamic Island",
            "coming_soon": True,
            "svg": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><rect width="20" height="14" x="2" y="5" rx="3"/><path d="M8 9h8"/></g></svg>'
        },
        {
            "id": "super_lock",
            "label": "Super Lock",
            "coming_soon": True,
            "svg": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><rect width="15" height="11" x="4.5" y="10.5" rx="2.5"/><path d="M8.5 10.5V7a3.5 3.5 0 0 1 7 0v3.5"/><path d="M12 14.5v3"/></g></svg>'
        },
        {
            "id": "super_freeze_octive",
            "label": "Super Freeze & Octive",
            "coming_soon": True,
            "svg": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><path d="M2 12h20M12 2v20m8-6-4-4 4-4M4 8l4 4-4 4m12-12-4 4-4-4M8 20l4-4 4 4"/></g></svg>'
        },
    ]

    SECONDARY_ITEMS = [
        {
            "id": "access_settings",
            "label": "Access",
            "coming_soon": False,
            "svg": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><path d="M9.671 4.136a2.34 2.34 0 0 1 4.659 0a2.34 2.34 0 0 0 3.319 1.915a2.34 2.34 0 0 1 2.33 4.033a2.34 2.34 0 0 0 0 3.831a2.34 2.34 0 0 1-2.33 4.033a2.34 2.34 0 0 0-3.319 1.915a2.34 2.34 0 0 1-4.659 0a2.34 2.34 0 0 0-3.32-1.915a2.34 2.34 0 0 1-2.33-4.033a2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915"/><circle cx="12" cy="12" r="3"/></g></svg>'
        },
        {
            "id": "info_version",
            "label": "Info",
            "version_badge": "v1.0",
            "coming_soon": False,
            "svg": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4m0-4h.01"/></g></svg>'
        },
        {
            "id": "notifications",
            "label": "Notification",
            "coming_soon": False,
            "svg": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></g></svg>'
        },
        {
            "id": "update_checker",
            "label": "Update",
            "coming_soon": False,
            "svg": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"/><path d="M16 16h5v5"/></g></svg>'
        },
        {
            "id": "read_explore",
            "label": "Read & Explore",
            "coming_soon": False,
            "svg": '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g fill="none" stroke="{col}" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.0"><path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1-2.5-2.5Z"/><path d="M6 6h10m-10 4h10m-10 4h6"/></g></svg>'
        },
    ]

    def __init__(
        self,
        on_open_hud=None,
        on_open_clipboard=None,
        on_open_design=None,
        on_open_snap=None,
        on_open_box=None,
        on_open_share_menu=None,
        on_open_share_device=None,
        on_open_share_stored=None,
        on_open_share_settings=None,
        get_box_count=None,
        get_share_count=None,
        on_settings_changed=None,
        parent=None,
    ):
        super().__init__(parent)
        self.on_open_hud = on_open_hud
        self.on_open_clipboard = on_open_clipboard
        self.on_open_design = on_open_design
        self.on_open_snap = on_open_snap
        self.on_open_box = on_open_box
        self.on_open_share_menu = on_open_share_menu
        self.on_open_share_device = on_open_share_device
        self.on_open_share_stored = on_open_share_stored
        self.on_open_share_settings = on_open_share_settings
        self.get_box_count = get_box_count
        self.get_share_count = get_share_count
        self.on_settings_changed = on_settings_changed
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_Hover, True)
        self.setMouseTracking(True)
        self.setFixedSize(320, 490)
        self._is_dropdown_expanded = False

        self._hover_watchdog = QTimer(self)
        self._hover_watchdog.setInterval(80)
        self._hover_watchdog.timeout.connect(self._watchdog_hover_check)
        self._hover_watchdog.start()

        self._dragging = False
        self._is_animating = False
        self._drag_offset = QPoint()
        try:
            from global_triggers import load_access_settings
            self._follow_enabled = bool(load_access_settings().get("follow_cursor", False))
        except Exception:
            self._follow_enabled = False
        self._fx = 0.0
        self._fy = 0.0
        self._follow_timer = QTimer(self)
        self._follow_timer.setInterval(16)
        self._follow_timer.timeout.connect(self._step_follow_cursor)
        self.coming_soon_popup = ComingSoonPopup(self)
        self.access_window = SuperAccessSettingsWindow(
            on_back=self.open_asmr_switch,
            on_settings_changed=self._handle_settings_changed,
        )
        self.info_window = SuperInfoReadOnlyWindow(on_back=self.open_asmr_switch)
        self.notification_window = SuperNotificationWindow(on_back=self.open_asmr_switch)
        self.read_explore_window = SuperReadExploreWindow(on_back=self.open_asmr_switch)
        from features.patch_checker import get_patch_checker, SuperUpdateWindow
        self.patch_checker = get_patch_checker()
        self.update_window = SuperUpdateWindow(self.patch_checker, on_back=self.open_asmr_switch)
        self._update_row = None
        self.patch_checker.status_changed.connect(self._on_patch_status_changed)
        self.pin_submenu = _PinSubMenuPopup(self)
        self.pin_submenu.action_triggered.connect(self._on_submenu_action)
        self.pin_submenu.hovered_changed.connect(self._on_submenu_hovered)
        self.share_submenu = _ShareSubMenuPopup(self)
        self.share_submenu.action_triggered.connect(self._on_submenu_action)
        self.share_submenu.hovered_changed.connect(self._on_submenu_hovered)
        self._rows = []
        self._pin_row = None
        self._share_row = None
        self._pin_row_hovered = False
        self._share_row_hovered = False
        self._pending_submenu_kind = None
        self._active_submenu_kind = None
        self._submenu_hovered = False

        self._sub_open_timer = QTimer(self)
        self._sub_open_timer.setSingleShot(True)
        self._sub_open_timer.timeout.connect(self._show_pin_submenu_now)

        self._sub_hide_timer = QTimer(self)
        self._sub_hide_timer.setSingleShot(True)
        self._sub_hide_timer.timeout.connect(self._maybe_hide_pin_submenu)

        base_assets = ASSETS_DIR
        logo_fp = os.path.join(base_assets, "supermouse_app_logo_cropped.png")
        if not os.path.exists(logo_fp):
            logo_fp = os.path.join(base_assets, "supermouse_app_logo_trans.png")
        self._raw_logo = QPixmap(logo_fp) if os.path.exists(logo_fp) else None
        if self._raw_logo and not self._raw_logo.isNull():
            ldpr = _native_dpr(self)
            li = self._raw_logo.toImage().scaledToHeight(max(20, int(round(20 * ldpr))), Qt.SmoothTransformation)
            self.logo_pix = QPixmap.fromImage(li)
            self.logo_pix.setDevicePixelRatio(ldpr)
        else:
            self.logo_pix = None

        self._build_ui()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # 1. Header Bar (y_c = 26.0) - seamless directly into Menu section (no divider line!)
        header = QWidget(self)
        header.setFixedHeight(52)
        header.setCursor(Qt.OpenHandCursor)
        hdr_lay = QHBoxLayout(header)
        hdr_lay.setContentsMargins(16, 0, 14, 0)
        hdr_lay.setAlignment(Qt.AlignVCenter | Qt.AlignRight)

        hdr_lay.addStretch()
        self.btn_close = _TopCloseButton(header)
        self.btn_close.clicked.connect(self.close_with_pull_animation)
        hdr_lay.addWidget(self.btn_close, alignment=Qt.AlignVCenter)
        root.addWidget(header)

        # Eyebrow row: MENU left + subtle hotkey badge right
        eyebrow = QWidget(self)
        eyebrow.setFixedHeight(18)
        eb_lay = QHBoxLayout(eyebrow)
        eb_lay.setContentsMargins(18, 0, 18, 0)

        lbl_sec = QLabel("MENU", eyebrow)
        lbl_sec.setStyleSheet(
            "color: rgba(255, 255, 255, 0.42); font-size: 8px; font-weight: 700; "
            "letter-spacing: 1.4px; background: transparent; "
            "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        eb_lay.addWidget(lbl_sec)
        eb_lay.addStretch()
        self.lbl_hk = None
        root.addWidget(eyebrow)
        root.addSpacing(4)

        # 2. Primary Boxless Items
        idx = 0
        for item in self.PRIMARY_ITEMS:
            row = _MenuItemRow(item, idx=idx, parent=self)
            row.clicked.connect(self._on_item_clicked)
            row.hovered_in.connect(self._on_row_hovered_in)
            row.hovered_out.connect(self._on_row_hovered_out)
            if item["id"] == "super_pin":
                self._pin_row = row
            elif item["id"] == "super_share":
                self._share_row = row
            root.addWidget(row)
            self._rows.append(row)
            idx += 1

        root.addSpacing(2)

        div2 = QFrame(self)
        div2.setFixedHeight(1)
        div2.setStyleSheet("background-color: rgba(255, 255, 255, 0.08); margin: 0px 18px;")
        root.addWidget(div2)

        root.addSpacing(2)

        # 3. Expandable Dropdown Header: "Read and Settings"
        self.dropdown_header = _DropdownHeaderRow(expanded=False, has_orange_alert=False, parent=self)
        self.dropdown_header.toggled.connect(self._on_dropdown_toggled)
        root.addWidget(self.dropdown_header)

        # 4. Expandable Dropdown Container for All 6 Options (Exact spacing as main menu)
        self.MAX_DROPDOWN_H = 228
        self.BASE_COLLAPSED_H = 490

        self._dropdown_container = QWidget(self)
        self._drop_layout = QVBoxLayout(self._dropdown_container)
        self._drop_layout.setContentsMargins(0, 0, 0, 0)
        self._drop_layout.setSpacing(0)

        for item in self.SECONDARY_ITEMS:
            row = _MenuItemRow(item, idx=idx, parent=self)
            row.clicked.connect(self._on_item_clicked)
            row.hovered_in.connect(self._on_row_hovered_in)
            row.hovered_out.connect(self._on_row_hovered_out)
            if item["id"] == "update_checker":
                self._update_row = row
                row._update_pending_count = int(self.patch_checker.get_status().get("pending_count") or 0)
            self._drop_layout.addWidget(row)
            self._rows.append(row)
            idx += 1

        self.follow_row = _FollowCursorRow(checked=self._follow_enabled, parent=self)
        self.follow_row.toggled.connect(self._on_follow_toggled)
        self._drop_layout.addWidget(self.follow_row)

        self._dropdown_container.setFixedHeight(0)
        self._dropdown_container.setVisible(True)
        self._current_drop_h = 0.0
        self._target_drop_h = 0.0
        root.addWidget(self._dropdown_container)

        root.addSpacing(2)

        div3 = QFrame(self)
        div3.setFixedHeight(1)
        div3.setStyleSheet("background-color: rgba(255, 255, 255, 0.07); margin: 0px 18px;")
        root.addWidget(div3)
        root.addSpacing(2)

        self.footer = _ProfileFooterButton(self._raw_logo, self)
        self.footer.clicked.connect(self._open_studio_website)
        root.addWidget(self.footer)
        root.addSpacing(2)

        lbl_ver_foot = QLabel("THE SUPERMOUSE v1.0", self)
        lbl_ver_foot.setAlignment(Qt.AlignCenter)
        lbl_ver_foot.setFixedHeight(16)
        lbl_ver_foot.setStyleSheet(
            "color: rgba(255, 255, 255, 0.34); font-size: 8px; font-weight: 600; "
            "letter-spacing: 0.9px; background: transparent; "
            "font-family: 'Segoe UI Variable', 'Segoe UI', sans-serif;"
        )
        root.addWidget(lbl_ver_foot)
        root.addSpacing(4)
        self._update_dropdown_alert_icon()

    def _update_dropdown_alert_icon(self):
        if not hasattr(self, "dropdown_header") or not self.dropdown_header:
            return
        pending_n = 0
        if hasattr(self, "patch_checker") and self.patch_checker:
            try:
                pending_n = int(self.patch_checker.get_status().get("pending_count") or 0)
            except Exception:
                pending_n = 0
        has_alert = (pending_n > 0)
        self.dropdown_header.set_has_orange_alert(has_alert)

    def _on_dropdown_toggled(self, expanded: bool):
        self._is_dropdown_expanded = bool(expanded)
        self._target_drop_h = float(self.MAX_DROPDOWN_H if self._is_dropdown_expanded else 0)

        if not hasattr(self, "_drop_anim_timer") or self._drop_anim_timer is None:
            self._drop_anim_timer = QTimer(self)
            self._drop_anim_timer.setInterval(16)
            self._drop_anim_timer.timeout.connect(self._step_dropdown_anim)

        if not self._drop_anim_timer.isActive():
            self._drop_anim_timer.start()

    def _step_dropdown_anim(self):
        curr = getattr(self, "_current_drop_h", 0.0)
        target = getattr(self, "_target_drop_h", 0.0)
        diff = target - curr

        if abs(diff) < 0.8:
            curr = target
            self._drop_anim_timer.stop()
        else:
            curr += diff * 0.28

        self._current_drop_h = curr
        ch = int(round(curr))
        self._dropdown_container.setFixedHeight(ch)
        new_win_h = self.BASE_COLLAPSED_H + ch
        self.setFixedSize(320, new_win_h)

        try:
            cur_pos = self.pos()
            screen = QApplication.screenAt(cur_pos) or QApplication.primaryScreen()
            if screen:
                avail = screen.availableGeometry()
                if cur_pos.y() + new_win_h > avail.bottom() - 10:
                    new_y = max(avail.top() + 10, avail.bottom() - 10 - new_win_h)
                    self.move(cur_pos.x(), new_y)
        except Exception:
            pass

        ratio = max(0.0, min(1.0, curr / float(self.MAX_DROPDOWN_H)))
        if hasattr(self, "dropdown_header") and self.dropdown_header:
            self.dropdown_header.set_expand_ratio(ratio)

    def _refresh_hotkey_label(self):
        try:
            if hasattr(self, "lbl_hk") and self.lbl_hk:
                from global_triggers import load_access_settings
                cfg = load_access_settings()
                txt = cfg.get("master_hotkey", "Win+Shift+M") if cfg.get("hotkey_enabled", True) else "Hotkey Off"
                self.lbl_hk.setText(txt)
        except Exception:
            pass

    def _handle_settings_changed(self, cfg):
        self._refresh_hotkey_label()
        if callable(self.on_settings_changed):
            self.on_settings_changed(cfg)

    def _on_follow_toggled(self, enabled: bool):
        self._follow_enabled = bool(enabled)
        try:
            from global_triggers import load_access_settings, save_access_settings
            cfg = load_access_settings()
            cfg["follow_cursor"] = self._follow_enabled
            save_access_settings(cfg)
        except Exception:
            pass
        if self._follow_enabled:
            self._fx, self._fy = float(self.x()), float(self.y())
            if self.isVisible() and not self._is_animating and not self._follow_timer.isActive():
                self._follow_timer.start()
        else:
            self._follow_timer.stop()

    def _sync_follow_timer(self):
        if self._follow_enabled and self.isVisible() and not self._is_animating:
            self._fx, self._fy = float(self.x()), float(self.y())
            if not self._follow_timer.isActive():
                self._follow_timer.start()
        else:
            self._follow_timer.stop()

    def _step_follow_cursor(self):
        if not self._follow_enabled or not self.isVisible() or self._is_animating or self._dragging:
            return
        cur = QCursor.pos()
        # Pause gracefully when cursor enters the menu (or open submenu) so buttons click effortlessly
        if self.geometry().adjusted(-8, -8, 8, 8).contains(cur):
            return
        if self.pin_submenu.isVisible() and self.pin_submenu.geometry().adjusted(-8, -8, 8, 8).contains(cur):
            return
        if self.share_submenu.isVisible() and self.share_submenu.geometry().adjusted(-8, -8, 8, 8).contains(cur):
            return

        screen = QApplication.screenAt(cur) or QApplication.primaryScreen()
        avail = screen.availableGeometry()
        w, h = self.width(), self.height()

        tx = cur.x() + 24
        if tx + w > avail.right() - 10:
            tx = cur.x() - w - 24
        tx = max(avail.left() + 10, min(avail.right() - w - 10, tx))

        ty = cur.y() + 18
        if ty + h > avail.bottom() - 10:
            ty = cur.y() - h - 18
        ty = max(avail.top() + 10, min(avail.bottom() - h - 10, ty))

        dx = float(tx) - self._fx
        dy = float(ty) - self._fy
        if abs(dx) < 0.35 and abs(dy) < 0.35:
            return
        # Ultra-smooth exponential glide (14% step per 16ms tick)
        self._fx += dx * 0.14
        self._fy += dy * 0.14
        self.move(int(round(self._fx)), int(round(self._fy)))

    def _open_studio_website(self):
        self.close_with_pull_animation(on_finished=self._launch_website_url)

    def _launch_website_url(self):
        if os.path.exists(STUDIO_WEBSITE_LOCAL):
            QDesktopServices.openUrl(QUrl.fromLocalFile(STUDIO_WEBSITE_LOCAL))
        else:
            webbrowser.open("https://github.com/trending")

    def _resolve_box_count(self) -> int:
        if callable(self.get_box_count):
            try:
                return int(self.get_box_count())
            except Exception:
                return 0
        try:
            from super_clipboard import count_box_items
            return int(count_box_items())
        except Exception:
            return 0

    def _resolve_share_count(self) -> int:
        if callable(self.get_share_count):
            try:
                return int(self.get_share_count())
            except Exception:
                pass
        try:
            from super_share import count_stored_share_items
            return int(count_stored_share_items())
        except Exception:
            return 0

    def _submenu_pair(self, kind: str):
        if kind == "super_pin":
            return self.pin_submenu, self._pin_row, self._resolve_box_count()
        if kind == "super_share":
            return self.share_submenu, self._share_row, self._resolve_share_count()
        return None, None, 0

    def _on_row_hovered_in(self, item):
        oid = item.get("id")
        if oid in ("super_pin", "super_share"):
            if self._active_submenu_kind and self._active_submenu_kind != oid:
                self._hide_pin_submenu()
            self._pin_row_hovered = (oid == "super_pin")
            self._share_row_hovered = (oid == "super_share")
            self._pending_submenu_kind = oid
            self._sub_hide_timer.stop()
            popup, _, _ = self._submenu_pair(oid)
            if popup and not popup.isVisible() and not self._is_animating:
                self._sub_open_timer.start(140)
        else:
            self._pin_row_hovered = False
            self._share_row_hovered = False
            self._sub_open_timer.stop()
            if (self.pin_submenu.isVisible() or self.share_submenu.isVisible()) and not self._submenu_hovered:
                self._hide_pin_submenu()

    def _on_row_hovered_out(self, item):
        oid = item.get("id")
        if oid == "super_pin":
            self._pin_row_hovered = False
            self._sub_open_timer.stop()
            self._sub_hide_timer.start(220)
        elif oid == "super_share":
            self._share_row_hovered = False
            self._sub_open_timer.stop()
            self._sub_hide_timer.start(220)

    def _on_submenu_hovered(self, hovering: bool):
        self._submenu_hovered = bool(hovering)
        if hovering:
            self._sub_hide_timer.stop()
            _, row, _ = self._submenu_pair(self._active_submenu_kind or self._pending_submenu_kind)
            if row:
                row.set_force_active(True)
        else:
            self._sub_hide_timer.start(220)

    def _show_pin_submenu_now(self):
        kind = self._pending_submenu_kind
        popup, row, count = self._submenu_pair(kind)
        if not self.isVisible() or self._is_animating or not row or not popup:
            return
        self._active_submenu_kind = kind
        row.set_force_active(True)
        popup.open_for_row(row, self, item_count=count)

    def _maybe_hide_pin_submenu(self):
        if not self._pin_row_hovered and not self._share_row_hovered and not self._submenu_hovered:
            self._hide_pin_submenu()

    def _hide_pin_submenu(self):
        self._sub_open_timer.stop()
        self._sub_hide_timer.stop()
        self._submenu_hovered = False
        self._active_submenu_kind = None
        if self.pin_submenu.isVisible():
            self.pin_submenu.hide()
        if self.share_submenu.isVisible():
            self.share_submenu.hide()
        if self._pin_row:
            self._pin_row.set_force_active(False)
        if self._share_row:
            self._share_row.set_force_active(False)

    def _on_submenu_action(self, oid: str):
        self._hide_pin_submenu()
        if oid == "take_snap":
            if self.on_open_snap:
                self.switch_out_asmr_animation(on_finished=lambda: QTimer.singleShot(35, self.on_open_snap))
            elif self.on_open_clipboard:
                self.switch_out_asmr_animation(on_finished=self.on_open_clipboard)
        elif oid == "my_box":
            if self.on_open_box:
                self.switch_out_asmr_animation(on_finished=self.on_open_box)
            elif self.on_open_clipboard:
                self.switch_out_asmr_animation(on_finished=self.on_open_clipboard)
        elif oid in ("share_device_hub", "share_device_window"):
            if self.on_open_share_device:
                self.switch_out_asmr_animation(on_finished=self.on_open_share_device)
        elif oid in ("share_memory_space", "share_stored_window"):
            if self.on_open_share_stored:
                self.switch_out_asmr_animation(on_finished=self.on_open_share_stored)
        elif oid == "share_settings":
            if self.on_open_share_settings:
                self.switch_out_asmr_animation(on_finished=self.on_open_share_settings)
        else:
            center_pos = self.mapToGlobal(QPoint(self.width() // 2, self.height() // 2))
            all_sub = list(self.pin_submenu.SUB_ITEMS) + list(self.share_submenu.SUB_ITEMS)
            match = next((it for it in all_sub if it["id"] == oid), None)
            if match is not None:
                self.switch_out_asmr_animation(
                    on_finished=lambda m=match: self.coming_soon_popup.show_option(
                        m["label"].upper(), m["svg"], center_pos
                    )
                )
            elif self.on_open_clipboard:
                self.switch_out_asmr_animation(on_finished=self.on_open_clipboard)
        self.option_selected.emit(oid)

    def open_at_cursor(self):
        self._update_dropdown_alert_icon()
        self.open_with_spring_animation()

    def open_asmr_switch(self):
        """Quick, silky normal fade-in at cursor when returning from any window (no going-down/coming-up slide)."""
        self._update_dropdown_alert_icon()
        self._hide_pin_submenu()
        if hasattr(self, "anim_out") and getattr(self.anim_out, "state", lambda: 0)() == QPropertyAnimation.Running:
            self.anim_out.stop()

        cur = QCursor.pos()
        screen = QApplication.screenAt(cur) or QApplication.primaryScreen()
        avail = screen.availableGeometry()
        w, h = self.width(), self.height()
        tx = max(avail.left() + 12, min(avail.right() - w - 12, cur.x() - w // 2))
        ty = max(avail.top() + 14, min(avail.bottom() - h - 14, cur.y() - h // 2))

        for r in self._rows:
            r._reveal = 1.0
            r.update()

        self.setGeometry(QRect(tx, ty, w, h))
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.activateWindow()
        try:
            ctypes.windll.user32.SetForegroundWindow(int(self.winId()))
        except Exception:
            pass

        self._is_animating = True
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(135)
        af.setStartValue(0.0)
        af.setEndValue(1.0)
        af.setEasingCurve(QEasingCurve.OutCubic)
        af.finished.connect(lambda: (setattr(self, "_is_animating", False), self._sync_follow_timer()))
        self.anim_in = af
        self.anim_in.start()

    def open_at_share_submenu(self):
        """Open Super Share Sub Menu cleanly without opening cursor window."""
        if callable(getattr(self, "on_open_share_menu", None)):
            self.on_open_share_menu()
            return
        self.open_asmr_switch()
        self._pending_submenu_kind = "super_share"
        QTimer.singleShot(110, self._show_pin_submenu_now)

    def switch_out_asmr_animation(self, on_finished=None):
        """Quick, silky normal fade-out when switching to another option (no vertical travel)."""
        self._follow_timer.stop()
        self._hide_pin_submenu()
        if not self.isVisible():
            if on_finished:
                on_finished()
            return
        if hasattr(self, "anim_in") and getattr(self.anim_in, "state", lambda: 0)() == QPropertyAnimation.Running:
            self.anim_in.stop()

        self._is_animating = True
        af = QPropertyAnimation(self, b"windowOpacity")
        af.setDuration(110)
        af.setStartValue(self.windowOpacity())
        af.setEndValue(0.0)
        af.setEasingCurve(QEasingCurve.OutCubic)

        def _done():
            self._is_animating = False
            self.hide()
            if on_finished:
                on_finished()

        af.finished.connect(_done)
        self.anim_out = af
        self.anim_out.start()

    def open_with_spring_animation(self):
        self._hide_pin_submenu()
        if hasattr(self, "anim_out") and self.anim_out.state() == QParallelAnimationGroup.Running:
            self.anim_out.stop()

        cur = QCursor.pos()
        screen = QApplication.screenAt(cur) or QApplication.primaryScreen()
        avail = screen.availableGeometry()
        full = screen.geometry()

        w, h = self.width(), self.height()
        target_x = max(avail.left() + 12, min(avail.right() - w - 12, cur.x() - w // 2))
        target_y = max(avail.top() + 14, min(avail.bottom() - h - 14, cur.y() - h // 2))

        target_geom = QRect(target_x, target_y, w, h)
        start_geom = QRect(target_x, full.bottom() + 15, w, h)

        for r in self._rows:
            r.start_reveal_animation()

        self.setGeometry(start_geom)
        self.setWindowOpacity(0.0)
        self.show()
        self.raise_()
        self.activateWindow()
        try:
            hwnd = int(self.winId())
            ctypes.windll.user32.SetForegroundWindow(hwnd)
        except Exception:
            pass

        self._is_animating = True

        anim_geom = QPropertyAnimation(self, b"geometry")
        anim_geom.setDuration(380)
        anim_geom.setStartValue(start_geom)
        anim_geom.setEndValue(target_geom)
        anim_geom.setEasingCurve(QEasingCurve.OutCubic)

        anim_fade = QPropertyAnimation(self, b"windowOpacity")
        anim_fade.setDuration(320)
        anim_fade.setStartValue(0.0)
        anim_fade.setEndValue(1.0)
        anim_fade.setEasingCurve(QEasingCurve.OutCubic)

        self.anim_in = QParallelAnimationGroup(self)
        self.anim_in.addAnimation(anim_geom)
        self.anim_in.addAnimation(anim_fade)
        self.anim_in.finished.connect(lambda: (setattr(self, "_is_animating", False), self._sync_follow_timer()))
        self.anim_in.start()

    def close_with_pull_animation(self, on_finished=None):
        self._follow_timer.stop()
        self._hide_pin_submenu()
        if not self.isVisible():
            if on_finished:
                on_finished()
            return
        if hasattr(self, "anim_in") and self.anim_in.state() == QParallelAnimationGroup.Running:
            self.anim_in.stop()

        screen = QApplication.screenAt(self.pos()) or QApplication.primaryScreen()
        full = screen.geometry()

        curr_geom = self.geometry()
        end_geom = QRect(curr_geom.x(), full.bottom() + 15, curr_geom.width(), curr_geom.height())

        self._is_animating = True

        anim_geom = QPropertyAnimation(self, b"geometry")
        anim_geom.setDuration(330)
        anim_geom.setStartValue(curr_geom)
        anim_geom.setEndValue(end_geom)
        anim_geom.setEasingCurve(QEasingCurve.InCubic)

        anim_fade = QPropertyAnimation(self, b"windowOpacity")
        anim_fade.setDuration(290)
        anim_fade.setStartValue(self.windowOpacity())
        anim_fade.setEndValue(0.0)
        anim_fade.setEasingCurve(QEasingCurve.InCubic)

        self.anim_out = QParallelAnimationGroup(self)
        self.anim_out.addAnimation(anim_geom)
        self.anim_out.addAnimation(anim_fade)

        def _done():
            self._is_animating = False
            self.hide()
            if on_finished:
                on_finished()

        self.anim_out.finished.connect(_done)
        self.anim_out.start()

    def toggle_at_cursor(self):
        if self.isVisible() and not self._is_animating:
            self.close_with_pull_animation()
        else:
            self.open_with_spring_animation()

    def _launch_supermouse_hud(self):
        self.switch_out_asmr_animation(on_finished=self.on_open_hud)

    def _on_item_clicked(self, item):
        oid = item["id"]
        center_pos = self.mapToGlobal(QPoint(self.width() // 2, self.height() // 2))
        if oid in ("supermouse", "superedit"):
            self._launch_supermouse_hud()
        elif oid in ("super_pin", "super_clipboard"):
            if self.on_open_clipboard:
                self.switch_out_asmr_animation(on_finished=self.on_open_clipboard)
            else:
                self.switch_out_asmr_animation(
                    on_finished=lambda: self.coming_soon_popup.show_option(
                        item["label"].upper(), item["svg"], center_pos
                    )
                )
        elif oid in ("supersupdesign", "get_design"):
            if self.on_open_design:
                self.switch_out_asmr_animation(on_finished=self.on_open_design)
            else:
                self.switch_out_asmr_animation(
                    on_finished=lambda: self.coming_soon_popup.show_option(
                        item["label"].upper(), item["svg"], center_pos
                    )
                )
        elif oid == "super_share":
            if self.on_open_share_menu:
                self.switch_out_asmr_animation(on_finished=self.on_open_share_menu)
            elif self.on_open_share_device:
                self.switch_out_asmr_animation(on_finished=self.on_open_share_device)
            elif self.on_open_share_stored:
                self.switch_out_asmr_animation(on_finished=self.on_open_share_stored)
            else:
                self.switch_out_asmr_animation(
                    on_finished=lambda: self.coming_soon_popup.show_option(
                        item["label"].upper(), item["svg"], center_pos
                    )
                )
        elif oid in ("access_settings", "settings_shortcuts", "the_settings"):
            self.switch_out_asmr_animation(on_finished=self.access_window.open_asmr_switch)
        elif oid in ("info_version", "informations"):
            self.switch_out_asmr_animation(on_finished=self.info_window.open_asmr_switch)
        elif oid in ("notifications", "notification"):
            self.switch_out_asmr_animation(on_finished=self.notification_window.open_asmr_switch)
        elif oid == "update_checker":
            self.switch_out_asmr_animation(on_finished=self.update_window.open_asmr_switch)
        elif oid == "read_explore":
            self.switch_out_asmr_animation(on_finished=self.read_explore_window.open_asmr_switch)
        else:
            self.switch_out_asmr_animation(
                on_finished=lambda: self.coming_soon_popup.show_option(
                    item["label"].upper(),
                    item["svg"],
                    center_pos
                )
            )
        self.option_selected.emit(oid)

    def _on_patch_status_changed(self, st: dict):
        if self._update_row is not None:
            self._update_row._update_pending_count = int(st.get("pending_count") or 0)
            self._update_row.update()
        self._update_dropdown_alert_icon()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton and e.position().y() <= 52.0:
            self._hide_pin_submenu()
            self._dragging = True
            self._drag_offset = e.globalPosition().toPoint() - self.pos()
            self.setCursor(Qt.ClosedHandCursor)
            e.accept()
            return
        elif e.button() == Qt.RightButton:
            self.close_with_pull_animation()
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        if self._dragging:
            self.move(e.globalPosition().toPoint() - self._drag_offset)
            e.accept()
            return

        # Real-time self-healing hover sync: immune to fast or erratic cursor movement
        pos = e.position().toPoint()

        # Update primary & secondary menu rows
        for r in self._rows:
            if not r.isVisible():
                continue
            r_box = r.geometry()
            if r.parent() == self._dropdown_container:
                c_pos = self._dropdown_container.mapFrom(self, pos)
                under = self._dropdown_container.geometry().contains(pos) and r_box.contains(c_pos)
            else:
                under = r_box.contains(pos)

            if under:
                if not getattr(r, "_mouse_over", False):
                    r._mouse_over = True
                    r._target = 1.0
                    if not r._timer.isActive():
                        r._timer.start()
                    r.hovered_in.emit(r.item)
            elif getattr(r, "_mouse_over", False):
                r._mouse_over = False
                r._target = 1.0 if getattr(r, "_force_active", False) else 0.0
                if not r._timer.isActive():
                    r._timer.start()
                r.hovered_out.emit(r.item)

        # Dropdown header
        if hasattr(self, "dropdown_header") and self.dropdown_header.isVisible():
            dh = self.dropdown_header
            under_dh = dh.geometry().contains(pos)
            if under_dh:
                if dh._target_hover != 1.0:
                    dh._target_hover = 1.0
                    if not dh._anim.isActive():
                        dh._anim.start()
            else:
                if dh._target_hover != 0.0:
                    dh._target_hover = 0.0
                    if not dh._anim.isActive():
                        dh._anim.start()

        # Follow cursor row
        if hasattr(self, "follow_row") and self.follow_row.isVisible():
            fr = self.follow_row
            c_pos = self._dropdown_container.mapFrom(self, pos)
            under_fr = self._dropdown_container.geometry().contains(pos) and fr.geometry().contains(c_pos)
            if under_fr:
                if fr._target != 1.0:
                    fr._target = 1.0
                    if not fr._tm.isActive():
                        fr._tm.start()
            else:
                if fr._target != 0.0:
                    fr._target = 0.0
                    if not fr._tm.isActive():
                        fr._tm.start()

        # Footer
        if hasattr(self, "footer") and self.footer.isVisible():
            ft = self.footer
            under_ft = ft.geometry().contains(pos)
            if under_ft:
                if ft._target != 1.0:
                    ft._target = 1.0
                    if not ft._timer.isActive():
                        ft._timer.start()
            else:
                if ft._target != 0.0:
                    ft._target = 0.0
                    if not ft._timer.isActive():
                        ft._timer.start()

        super().mouseMoveEvent(e)

    def leaveEvent(self, e):
        for r in self._rows:
            r._mouse_over = False
            r._target = 1.0 if getattr(r, "_force_active", False) else 0.0
            if not r._timer.isActive():
                r._timer.start()
        if hasattr(self, "dropdown_header"):
            self.dropdown_header._target_hover = 0.0
            if not self.dropdown_header._anim.isActive():
                self.dropdown_header._anim.start()
        if hasattr(self, "follow_row"):
            self.follow_row._target = 0.0
            if not self.follow_row._tm.isActive():
                self.follow_row._tm.start()
        if hasattr(self, "footer"):
            self.footer._target = 0.0
            if not self.footer._timer.isActive():
                self.footer._timer.start()
        super().leaveEvent(e)

    def _watchdog_hover_check(self):
        if not self.isVisible() or self._is_animating:
            return
        cur = QCursor.pos()
        if not self.geometry().contains(cur):
            for r in self._rows:
                if getattr(r, "_mouse_over", False):
                    r._mouse_over = False
                    r._target = 1.0 if getattr(r, "_force_active", False) else 0.0
                    if not r._timer.isActive():
                        r._timer.start()
            if hasattr(self, "dropdown_header") and self.dropdown_header._target_hover != 0.0:
                self.dropdown_header._target_hover = 0.0
                if not self.dropdown_header._anim.isActive():
                    self.dropdown_header._anim.start()
            if hasattr(self, "follow_row") and self.follow_row._target != 0.0:
                self.follow_row._target = 0.0
                if not self.follow_row._tm.isActive():
                    self.follow_row._tm.start()
            if hasattr(self, "footer") and self.footer._target != 0.0:
                self.footer._target = 0.0
                if not self.footer._timer.isActive():
                    self.footer._timer.start()

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self._dragging:
            self._dragging = False
            self.setCursor(Qt.ArrowCursor)
            e.accept()
            return
        super().mouseReleaseEvent(e)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.close_with_pull_animation()
            e.accept()
        else:
            super().keyPressEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        w, h = float(self.width()), float(self.height())
        rect = QRectF(0.6, 0.6, w - 1.2, h - 1.2)
        card = QPainterPath()
        card.addRoundedRect(rect, 14.0, 14.0)

        p.fillPath(card, QColor(4, 4, 5, 253))
        p.setPen(QPen(QColor(255, 255, 255, 26), 1.0))
        p.drawPath(card)

        # Vector-Crisp QPainterPath Logo Typography ('THE' white + 'SUPERMOUSE' #FFFF00->#00FF85)
        bx = 16.0
        by_c = 26.0
        if self.logo_pix and not self.logo_pix.isNull():
            ldpr = max(1.0, float(self.logo_pix.devicePixelRatio() or 1.0))
            lw = self.logo_pix.width() / ldpr
            lh = self.logo_pix.height() / ldpr
            p.drawPixmap(int(round(bx)), int(round(by_c - lh * 0.5)), self.logo_pix)
            bx += lw + 8.0

        f_logo = QFont()
        f_logo.setFamilies(["Segoe UI Variable Display", "Segoe UI Variable Text", "Segoe UI", "Arial", "sans-serif"])
        f_logo.setBold(True)
        f_logo.setWeight(QFont.Weight.ExtraBold)
        f_logo.setPointSizeF(11.4)
        f_logo.setLetterSpacing(QFont.AbsoluteSpacing, 0.35)
        f_logo.setHintingPreference(QFont.PreferNoHinting)

        probe = QPainterPath()
        probe.addText(0.0, 0.0, f_logo, "THE SUPERMOUSE")
        br = probe.boundingRect()
        baseline_y = by_c - (br.top() + br.height() * 0.5)

        p1 = QPainterPath()
        p1.addText(bx, baseline_y, f_logo, "THE")
        p.fillPath(p1, QColor("#FFFFFF"))

        w1 = p1.boundingRect().width()
        smx = bx + w1 + 5.5
        p2 = QPainterPath()
        p2.addText(smx, baseline_y, f_logo, "SUPERMOUSE")
        b2 = p2.boundingRect()
        g_sm = QLinearGradient(b2.left(), 0.0, b2.right(), 0.0)
        g_sm.setColorAt(0.0, QColor("#FFFF00"))
        g_sm.setColorAt(1.0, QColor("#00FF85"))
        p.fillPath(p2, g_sm)

        p.end()
