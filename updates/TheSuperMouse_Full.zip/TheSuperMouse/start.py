import subprocess, sys, os

creationflags = 0x00000008 | 0x00000200  # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
p = subprocess.Popen(
    [r"C:\Users\mytre\AppData\Local\Programs\Python\Python313\pythonw.exe", "main_app.py", "--supershare"],
    cwd=r"D:\THESUPERMOUSE\VERSION 1.0",
    creationflags=creationflags,
    close_fds=True
)
print("Started Detached PID:", p.pid)
