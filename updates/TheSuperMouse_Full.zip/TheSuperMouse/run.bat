@echo off
cd /d "%~dp0"
start "" "C:\Users\mytre\AppData\Local\Programs\Python\Python313\python.exe" main_app.py --supershare
exit
